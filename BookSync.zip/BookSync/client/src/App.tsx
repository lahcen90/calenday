import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import { TimezoneProvider } from "@/contexts/TimezoneContext";
import { useScrollToTop } from "@/hooks/useScrollToTop";
import { useEffect } from "react";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Register from "@/pages/register";
import SignIn from "@/pages/sign-in";
import VerifyEmail from "@/pages/verify-email";
import ResetPassword from "@/pages/reset-password";
import ForgotPassword from "@/pages/forgot-password";
import AdminUsers from "@/pages/admin-users";

import ProviderDashboard from "@/pages/provider-dashboard";
import AppointmentsManagement from "@/pages/appointments-management";
import MyBookings from "@/pages/my-bookings";
import GuestBooking from "@/pages/guest-booking";
import ServicesManagement from "@/pages/services-management";
import Profile from "@/pages/profile";
import Upgrade from "@/pages/upgrade";

// Public pages
import Pricing from "@/pages/pricing";
import AboutUs from "@/pages/about-us";
import TermsOfUse from "@/pages/terms-of-use";
import PrivacyPolicy from "@/pages/privacy-policy";
import FAQ from "@/pages/faq";
import ContactUs from "@/pages/contact-us";
import HelpCenter from "@/pages/help-center";

function AuthRedirect() {
  const [, setLocation] = useLocation();
  
  useEffect(() => {
    setLocation('/dashboard');
  }, [setLocation]);
  
  return null;
}

function Router() {
  const { isAuthenticated, isLoading } = useAuth();
  useScrollToTop();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      {/* Public booking routes - accessible without authentication */}
      <Route path="/booking" component={GuestBooking} />
      <Route path="/book" component={GuestBooking} />
      <Route path="/guest-booking" component={GuestBooking} />
      <Route path="/book/:userId" component={GuestBooking} />
      
      {/* Public pages - accessible without authentication */}
      <Route path="/pricing" component={Pricing} />
      <Route path="/about-us" component={AboutUs} />
      <Route path="/terms-of-use" component={TermsOfUse} />
      <Route path="/privacy-policy" component={PrivacyPolicy} />
      <Route path="/faq" component={FAQ} />
      <Route path="/contact-us" component={ContactUs} />
      <Route path="/help-center" component={HelpCenter} />
      
      {/* Upgrade route - accessible to both authenticated and unauthenticated users */}
      <Route path="/upgrade" component={Upgrade} />
      
      {isLoading || !isAuthenticated ? (
        <>
          <Route path="/" component={Landing} />
          <Route path="/register" component={Register} />
          <Route path="/sign-in" component={SignIn} />
          <Route path="/verify-email" component={VerifyEmail} />
          <Route path="/forgot-password" component={ForgotPassword} />
          <Route path="/reset-password" component={ResetPassword} />
          <Route path="/privat-all" component={AdminUsers} />
        </>
      ) : (
        <>
          <Route path="/" component={ProviderDashboard} />
          <Route path="/dashboard" component={ProviderDashboard} />
          <Route path="/provider" component={ProviderDashboard} />
          <Route path="/appointments" component={AppointmentsManagement} />
          <Route path="/services" component={ServicesManagement} />
          <Route path="/services-management" component={ServicesManagement} />
          <Route path="/my-bookings" component={MyBookings} />
          <Route path="/profile" component={Profile} />
          {/* Redirect authenticated users from auth pages to dashboard */}
          <Route path="/register" component={AuthRedirect} />
          <Route path="/sign-in" component={AuthRedirect} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TimezoneProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </TimezoneProvider>
    </QueryClientProvider>
  );
}

export default App;
