import Navigation from "@/components/navigation";
import DashboardStats from "@/components/dashboard-stats";
import ProviderCalendar from "@/components/provider-calendar";
import UpcomingAppointments from "@/components/upcoming-appointments";
import AvailabilityManager from "@/components/availability-manager";
import Meta from "@/components/meta";
import NewAppointmentDialog from "@/components/new-appointment-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Clock, Settings, Copy, Link, Check, Code } from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import type { Service } from "@shared/schema";

export default function ProviderDashboard() {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedEmbed, setCopiedEmbed] = useState(false);
  const [showEmbedCode, setShowEmbedCode] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: services = [] } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const generateBookingLink = () => {
    if (!user || !(user as any).id) return "";
    const baseUrl = window.location.origin;
    return `${baseUrl}/book/${encodeURIComponent((user as any).id)}`;
  };

  const generateEmbedCode = () => {
    const bookingLink = generateBookingLink();
    if (!bookingLink) return "";
    
    return `<iframe 
  src="${bookingLink}" 
  width="100%" 
  height="600" 
  frameborder="0" 
  style="border: none; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
</iframe>`;
  };

  const copyToClipboard = async () => {
    const link = generateBookingLink();
    if (!link) {
      toast({
        title: "User Not Found",
        description: "Unable to generate booking link.",
        variant: "destructive",
      });
      return;
    }

    try {
      await navigator.clipboard.writeText(link);
      setCopiedLink(true);
      toast({
        title: "Link Copied!",
        description: "The booking link has been copied to your clipboard.",
      });
      setTimeout(() => setCopiedLink(false), 2000);
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy link. Please copy it manually.",
        variant: "destructive",
      });
    }
  };

  const copyEmbedCode = async () => {
    const embedCode = generateEmbedCode();
    if (!embedCode) {
      toast({
        title: "User Not Found",
        description: "Unable to generate embed code.",
        variant: "destructive",
      });
      return;
    }

    try {
      await navigator.clipboard.writeText(embedCode);
      setCopiedEmbed(true);
      toast({
        title: "Embed Code Copied!",
        description: "The embed code has been copied to your clipboard.",
      });
      setTimeout(() => setCopiedEmbed(false), 2000);
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy embed code. Please copy it manually.",
        variant: "destructive",
      });
    }
  };



  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Meta 
        title="Dashboard - Calenday Provider Portal"
        description="Manage your appointments, availability, and business settings from your Calenday dashboard. View analytics, handle bookings, and grow your business."
        keywords="dashboard, provider portal, appointment management, business analytics, scheduling dashboard"
      />
      <Navigation />
      
      <div className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8">
        {/* Dashboard Header */}
        <div className="mb-6 sm:mb-8">
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold text-slate-900 mb-2">Provider Dashboard</h2>
          <p className="text-sm sm:text-base text-slate-600">Manage your appointments and availability</p>
        </div>

        {/* Dashboard Stats */}
        <DashboardStats />

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 lg:gap-8 mt-6 sm:mt-8">
          {/* Calendar View */}
          <div className="xl:col-span-2 order-2 xl:order-1">
            <ProviderCalendar />
          </div>

          {/* Appointments List & Controls */}
          <div className="xl:col-span-1 order-1 xl:order-2 space-y-4 sm:space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Settings className="h-5 w-5 text-primary mr-2" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <NewAppointmentDialog>
                  <Button variant="outline" className="w-full justify-start">
                    <Calendar className="h-4 w-4 mr-2" />
                    New Appointment
                  </Button>
                </NewAppointmentDialog>
                <AvailabilityManager>
                  <Button variant="outline" className="w-full justify-start">
                    <Clock className="h-4 w-4 mr-2" />
                    Manage Availability
                  </Button>
                </AvailabilityManager>
              </CardContent>
            </Card>

            {/* Booking Link Generator */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Link className="h-5 w-5 text-primary mr-2" />
                  Booking Link
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="booking-link" className="text-sm font-semibold">Your Unique Booking Link</Label>
                  <div className="flex gap-2">
                    <Input
                      id="booking-link"
                      value={generateBookingLink()}
                      readOnly
                      className="flex-1"
                    />
                    <Button
                      onClick={copyToClipboard}
                      variant="outline"
                      size="icon"
                    >
                      {copiedLink ? (
                        <Check className="h-4 w-4 text-green-600" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  <p className="text-sm text-slate-500 mt-2">
                    Share this link with customers to let them book any of your services directly. No account required for customers.
                  </p>
                </div>

                <div className="border-t pt-4">
                  <div className="flex items-center justify-between mb-3">
                    <Label className="text-sm font-semibold">Embed Code</Label>
                    <Button
                      onClick={() => setShowEmbedCode(!showEmbedCode)}
                      variant="outline"
                      size="sm"
                      className="h-8"
                    >
                      <Code className="h-4 w-4 mr-2" />
                      {showEmbedCode ? "Hide Code" : "Show Code"}
                    </Button>
                  </div>
                  
                  {showEmbedCode && (
                    <div className="space-y-3">
                      <div className="relative">
                        <textarea
                          value={generateEmbedCode()}
                          readOnly
                          className="w-full h-32 p-3 text-xs font-mono bg-slate-50 border rounded-md resize-none"
                        />
                        <Button
                          onClick={copyEmbedCode}
                          variant="outline"
                          size="sm"
                          className="absolute top-2 right-2 h-8 px-2"
                        >
                          {copiedEmbed ? (
                            <Check className="h-3 w-3 text-green-600" />
                          ) : (
                            <Copy className="h-3 w-3" />
                          )}
                        </Button>
                      </div>
                      <p className="text-xs text-slate-500">
                        Place this code in your HTML where you want your Calenday widget to appear. The iframe will display your booking page directly on your website.
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Upcoming Appointments */}
            <UpcomingAppointments />
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-auto">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center">
            <p className="text-slate-600 text-sm">© 2025 Calenday. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
