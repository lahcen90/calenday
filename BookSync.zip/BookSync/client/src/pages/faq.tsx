import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import PublicHeader from "@/components/public-header";
import Meta from "@/components/meta";
import Calenday from "@assets/Clenday.png";

interface FAQItem {
  question: string;
  answer: string;
}

const faqData: FAQItem[] = [
  {
    question: "What is Calenday?",
    answer: "Calenday is a comprehensive appointment scheduling platform that helps businesses and individuals manage their bookings efficiently. It offers features like calendar integration, automated reminders, payment processing, and customizable booking pages."
  },
  {
    question: "How do I get started with Calenday?",
    answer: "Getting started is easy! Simply sign up for a free account, set up your services and availability, and share your booking link with clients. You can be taking appointments within minutes."
  },
  {
    question: "Is Calenday free to use?",
    answer: "Calenday offers a free plan with basic features including unlimited appointments and calendar sync. For advanced features like custom branding, analytics, and payment processing, we offer a Pro plan at $4/month."
  },
  {
    question: "Can I integrate Calenday with my existing calendar?",
    answer: "Yes! Calenday integrates seamlessly with Google Calendar and Outlook. All your appointments sync automatically, preventing double-bookings and keeping your schedule organized."
  },
  {
    question: "How do clients book appointments?",
    answer: "Clients can book appointments through your personalized booking link. They'll see your available time slots, select a service, provide their details, and receive instant confirmation with calendar invites."
  },
  {
    question: "Can I accept payments through Calenday?",
    answer: "Yes, with our Pro plan you can integrate PayPal to accept payments at the time of booking. This helps reduce no-shows and ensures you're compensated for your time."
  },
  {
    question: "What happens if I need to cancel or reschedule?",
    answer: "You can easily manage appointments from your dashboard. Clients receive automatic notifications of any changes, and calendar events are updated across all connected calendars."
  },
  {
    question: "Can I customize my booking page?",
    answer: "Absolutely! Pro users can customize their booking pages with their own branding, colors, and messaging to match their business identity."
  },
  {
    question: "How secure is my data?",
    answer: "We take security seriously. All data is encrypted in transit and at rest, and we comply with industry-standard security practices to protect your information and your clients' privacy."
  },
  {
    question: "What support is available?",
    answer: "We offer comprehensive support through our help center, FAQ section, and email support. Pro users receive priority support with faster response times."
  }
];

export default function FAQ() {
  const [openItem, setOpenItem] = useState<number | null>(null);

  const toggleItem = (index: number) => {
    setOpenItem(openItem === index ? null : index);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <Meta 
        title="FAQ - Calenday Help & Support"
        description="Find answers to frequently asked questions about Calenday appointment scheduling. Learn about features, pricing, integrations, and how to get the most from our platform."
        keywords="FAQ, help, support, questions, Calenday features, appointment scheduling help"
      />
      <PublicHeader />
      
      <div className="container mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">
            Frequently Asked Questions
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Find quick answers to common questions about Calenday. Can't find what you're looking for? Contact our support team.
          </p>
        </div>

        {/* FAQ Items */}
        <div className="max-w-4xl mx-auto space-y-4">
          {faqData.map((item, index) => (
            <Card key={index} className="border-2 hover:border-[#3C83F6] transition-colors">
              <CardContent className="p-0">
                <button
                  onClick={() => toggleItem(index)}
                  className="w-full p-6 text-left flex justify-between items-center"
                >
                  <h3 className="text-lg font-semibold text-slate-900 pr-4">
                    {item.question}
                  </h3>
                  {openItem === index ? (
                    <ChevronUp className="w-5 h-5 text-[#3C83F6] flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-slate-400 flex-shrink-0" />
                  )}
                </button>
                {openItem === index && (
                  <div className="px-6 pb-6">
                    <p className="text-slate-600 leading-relaxed">
                      {item.answer}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Contact Support */}
        <div className="text-center mt-12">
          <h2 className="text-2xl font-bold mb-4">Still have questions?</h2>
          <p className="text-slate-600 mb-6">
            Our support team is here to help you get the most out of Calenday.
          </p>
          <div className="space-x-4">
            <Link href="/contact-us">
              <Button className="bg-[#3C83F6] hover:bg-[#2563eb]">
                Contact Support
              </Button>
            </Link>
            <Link href="/help-center">
              <Button variant="outline">
                Visit Help Center
              </Button>
            </Link>
          </div>
        </div>

        {/* Back to Home */}
        <div className="text-center mt-8">
          <Link href="/">
            <Button variant="ghost">
              ← Back to Home
            </Button>
          </Link>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-24">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand */}
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img 
                  src={Calenday} 
                  alt="Calenday Logo" 
                  className="h-8 w-8"
                />
                <span className="text-xl font-bold text-slate-900">Calenday</span>
              </div>
              <p className="text-slate-600 mb-4">
                Calenday - Professional appointment scheduling made simple. Streamline your business with Calenday's powerful booking system.
              </p>
            </div>

            {/* Product */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Calenday Product</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/pricing" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Pricing
                  </Link>
                </li>
                <li>
                  <span className="text-slate-400">Calenday Mobile App (Coming Soon)</span>
                </li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">About Calenday</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/about-us" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    About Calenday
                  </Link>
                </li>
                <li>
                  <Link href="/contact-us" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Contact Calenday
                  </Link>
                </li>
              </ul>
            </div>

            {/* Support & Legal */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Calenday Support</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/help-center" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday FAQ
                  </Link>
                </li>
                <li>
                  <Link href="/privacy-policy" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms-of-use" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Terms of Use
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Footer */}
          <div className="border-t border-slate-200 mt-8 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-slate-600 text-sm">© 2025 Calenday. All rights reserved.</p>
              <div className="flex space-x-6 mt-4 md:mt-0">
                <span className="text-slate-400 text-sm">Follow Calenday:</span>
                <a 
                  href="https://x.com/Calenday_io" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-[#3C83F6] text-sm transition-colors"
                >
                  Calenday Twitter
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}