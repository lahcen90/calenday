import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Clock, Users, Shield } from "lucide-react";
import { Link } from "wouter";

import Clenday from "@assets/Clenday.png";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-primary flex items-center">
                <img 
                  src={Clenday} 
                  alt="Calenday Logo" 
                  className="h-8 w-8 mr-2"
                />
                Calenday
              </h1>
            </div>
            <div className="flex items-center space-x-3">
              <Link href="/sign-in">
                <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
                  Sign In
                </Button>
              </Link>
              <Link href="/register">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Register
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Professional Appointment Scheduling Made Simple
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Streamline your business with our powerful appointment booking system. 
            Let customers book online while you manage everything from one dashboard.
          </p>

          <div className="flex justify-center space-x-4 mb-12">
            <Link href="/register">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                Get Started Free
              </Button>
            </Link>
            <Link href="/sign-in">
              <Button size="lg" variant="outline">
                Sign In
              </Button>
            </Link>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mt-16">
          <Card className="text-center">
            <CardHeader>
              <Calendar className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <CardTitle className="text-lg">Easy Scheduling</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Customers can book appointments 24/7 with your custom booking page
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Clock className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <CardTitle className="text-lg">Time Management</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Set availability, block times, and manage your schedule effortlessly
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Users className="h-12 w-12 text-purple-600 mx-auto mb-4" />
              <CardTitle className="text-lg">Customer Management</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Track appointments, send reminders, and manage customer relationships
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Shield className="h-12 w-12 text-orange-600 mx-auto mb-4" />
              <CardTitle className="text-lg">Secure & Reliable</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Enterprise-grade security with email verification and data protection
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="md:col-span-1">
              <div className="flex items-center mb-4">
                <img 
                  src={Clenday} 
                  alt="Clenday Logo" 
                  className="h-8 w-8 mr-2"
                />
                <h3 className="text-xl font-bold text-slate-900">Clenday</h3>
              </div>
              <p className="text-slate-600 mb-4">
                Professional appointment scheduling made simple. Streamline your business with our powerful booking system.
              </p>
              <div className="flex space-x-4">
                <Link href="/register">
                  <Button className="bg-[#9433EA] hover:bg-[#7c2bb8]">
                    Get Started Free
                  </Button>
                </Link>
              </div>
            </div>

            {/* Product */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Product</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/pricing" className="text-slate-600 hover:text-[#9433EA] transition-colors">
                    Pricing
                  </Link>
                </li>
                
                
                <li>
                  <span className="text-slate-400">Mobile App (Coming Soon)</span>
                </li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Company</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/about-us" className="text-slate-600 hover:text-[#9433EA] transition-colors">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/contact-us" className="text-slate-600 hover:text-[#9433EA] transition-colors">
                    Contact Us
                  </Link>
                </li>
                
              </ul>
            </div>

            {/* Support & Legal */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Support & Legal</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/help-center" className="text-slate-600 hover:text-[#9433EA] transition-colors">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="text-slate-600 hover:text-[#9433EA] transition-colors">
                    FAQ
                  </Link>
                </li>
                <li>
                  <Link href="/privacy-policy" className="text-slate-600 hover:text-[#9433EA] transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms-of-use" className="text-slate-600 hover:text-[#9433EA] transition-colors">
                    Terms of Use
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Footer */}
          <div className="border-t border-slate-200 mt-8 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-slate-600 text-sm">
                © 2025 Clenday. All rights reserved.
              </p>
              <div className="flex space-x-6 mt-4 md:mt-0">
                <span className="text-slate-400 text-sm">Follow us:</span>
                <span className="text-slate-400 text-sm">Twitter (Coming Soon)</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}