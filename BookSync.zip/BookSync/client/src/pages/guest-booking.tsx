import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Calendar, Clock, Mail, Phone, MessageSquare, Building2, User, CalendarPlus } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import ServiceSelector from "@/components/service-selector";
import CalendarTimeSelector from "@/components/calendar-time-selector";
import Meta from "@/components/meta";

import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { getUserTimezone } from "@/lib/timezone";
import { useTimezone, TimezoneProvider } from "@/contexts/TimezoneContext";
import type { Service, InsertAppointment } from "@shared/schema";
import TimezoneSelector from "@/components/timezone-selector";

import Clenday from "@assets/Clenday.png";

import google_calendar_icon from "@assets/google calendar icon.png";

import calendar_google from "@assets/calendar google.png";

import icons8_outlook_50 from "@assets/icons8-outlook-50.png";

import icons8_google_calendar_50 from "@assets/icons8-google-calendar-50.png";

import google_calenday from "@assets/google calenday.png";

function GuestBookingContent() {
  const params = useParams();
  const providerId = params.userId; // Get provider ID from URL
  const { timezone, setTimezone } = useTimezone();
  
  const [currentStep, setCurrentStep] = useState(1);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [notes, setNotes] = useState("");

  const queryClient = useQueryClient();

  // Generate Google Calendar URL
  const generateGoogleCalendarUrl = () => {
    if (!selectedService || !selectedDate || !selectedTime) return "";

    const [hours, minutes] = selectedTime.split(':').map(Number);
    const startDate = new Date(selectedDate);
    startDate.setHours(hours, minutes, 0, 0);
    
    const endDate = new Date(startDate);
    endDate.setMinutes(endDate.getMinutes() + (selectedService.duration || 60));

    const formatDate = (date: Date) => {
      return date.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
    };

    const title = encodeURIComponent(`${selectedService.name} - Appointment`);
    const details = encodeURIComponent(
      `Service: ${selectedService.name}\n` +
      `Duration: ${selectedService.duration} minutes\n` +
      `Client: ${clientName}\n` +
      `Email: ${clientEmail}\n` +
      (clientPhone ? `Phone: ${clientPhone}\n` : '') +
      (notes ? `Notes: ${notes}\n` : '') +
      (profileData?.companyName ? `Provider: ${profileData.companyName}` : '')
    );

    const startTime = formatDate(startDate);
    const endTime = formatDate(endDate);

    return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${startTime}/${endTime}&details=${details}&sf=true&output=xml`;
  };

  // Generate Outlook Calendar URL
  const generateOutlookCalendarUrl = () => {
    if (!selectedService || !selectedDate || !selectedTime) return "";

    const [hours, minutes] = selectedTime.split(':').map(Number);
    const startDate = new Date(selectedDate);
    startDate.setHours(hours, minutes, 0, 0);
    
    const endDate = new Date(startDate);
    endDate.setMinutes(endDate.getMinutes() + (selectedService.duration || 60));

    const title = encodeURIComponent(`${selectedService.name} - Appointment`);
    const body = encodeURIComponent(
      `Service: ${selectedService.name}\n` +
      `Duration: ${selectedService.duration} minutes\n` +
      `Client: ${clientName}\n` +
      `Email: ${clientEmail}\n` +
      (clientPhone ? `Phone: ${clientPhone}\n` : '') +
      (notes ? `Notes: ${notes}\n` : '') +
      (profileData?.companyName ? `Provider: ${profileData.companyName}` : '')
    );

    // Format dates for Outlook (YYYY-MM-DDTHH:MM:SS format without timezone conversion)
    const formatOutlookDate = (date: Date) => {
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      const hour = String(date.getHours()).padStart(2, '0');
      const minute = String(date.getMinutes()).padStart(2, '0');
      const second = String(date.getSeconds()).padStart(2, '0');
      return `${year}-${month}-${day}T${hour}:${minute}:${second}`;
    };

    const startTime = formatOutlookDate(startDate);
    const endTime = formatOutlookDate(endDate);

    return `https://outlook.live.com/calendar/0/deeplink/compose?subject=${title}&startdt=${startTime}&enddt=${endTime}&body=${body}`;
  };

  // Get provider profile for company branding
  const { data: providerProfile, isLoading: profileLoading } = useQuery({
    queryKey: [`/api/provider/${providerId}/profile`],
    enabled: !!providerId,
  });

  // Type-safe access to provider profile data
  const profileData = providerProfile as {
    id: string;
    email: string | null;
    firstName: string | null;
    lastName: string | null;
    companyName: string | null;
    companyLogoUrl: string | null;
    companyWebsite: string | null;
    companyWebsiteEnabled: boolean | null;
    whatsNextMessage: string | null;
    subscriptionPlan: string | null;
    allowTimezoneSelection: boolean | null;
    defaultTimezone: string | null;
  } | undefined;

  // Handle timezone based on provider settings
  useEffect(() => {
    if (profileData) {
      if (profileData.allowTimezoneSelection === false) {
        // When timezone selection is disabled, use client's detected timezone
        try {
          const detectedTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
          setTimezone(detectedTimezone);
        } catch {
          setTimezone('UTC');
        }
      } else if (profileData.allowTimezoneSelection === true) {
        // When timezone selection is enabled, inherit provider's current timezone
        // Check if there's a saved timezone from provider's dashboard
        const savedProviderTimezone = localStorage.getItem('user-timezone');
        if (savedProviderTimezone) {
          setTimezone(savedProviderTimezone);
        } else if (profileData.defaultTimezone) {
          setTimezone(profileData.defaultTimezone);
        }
      }
    }
  }, [profileData, setTimezone]);

  // Listen for timezone changes from the provider's dashboard
  useEffect(() => {
    if (profileData?.allowTimezoneSelection === true) {
      const handleStorageChange = (e: StorageEvent) => {
        if (e.key === 'user-timezone' && e.newValue) {
          setTimezone(e.newValue);
        }
      };

      window.addEventListener('storage', handleStorageChange);
      return () => window.removeEventListener('storage', handleStorageChange);
    }
  }, [profileData?.allowTimezoneSelection, setTimezone]);

  const createAppointmentMutation = useMutation({
    mutationFn: async (appointment: InsertAppointment) => {
      return await apiRequest("/api/appointments", "POST", appointment);
    },
    onSuccess: (data) => {
      toast({
        title: "Booking Confirmed!",
        description: "Your appointment has been successfully booked. You will receive a confirmation email shortly.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      
      // Move to confirmation step instead of resetting
      setCurrentStep(4);
      setCompletedSteps([1, 2, 3]);
    },
    onError: (error: Error) => {
      // Check if this is a blocked time error
      const errorMessage = error.message;
      if (errorMessage.includes("not available") || errorMessage.includes("blocked time")) {
        toast({
          title: "That time slot is reserved by the provider. Please pick a different time.",
          description: errorMessage,
          variant: "destructive",
        });
      } else if (errorMessage.includes("already booked") || errorMessage.includes("time slot")) {
        toast({
          title: "The reserved time slot is already booked. Please select a different time.",
          description: errorMessage,
          variant: "destructive",
        });
      } else {
        toast({
          title: "The reserved time slot is already booked. Please select a different time.",
          description: errorMessage || "Something went wrong. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  const handleServiceSelect = (service: Service) => {
    setSelectedService(service);
    setCurrentStep(2);
    setCompletedSteps([1]);
  };

  const handleDateTimeSelect = (date: Date, time: string) => {
    setSelectedDate(date);
    setSelectedTime(time);
    setCurrentStep(3);
    setCompletedSteps([1, 2]);
  };

  const handleBookingSubmit = () => {
    if (!selectedService || !selectedDate || !selectedTime || !clientName || !clientEmail) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    // Create appointment date in the selected timezone
    const [hours, minutes] = selectedTime.split(':').map(Number);
    const year = selectedDate.getFullYear();
    const month = selectedDate.getMonth();
    const day = selectedDate.getDate();
    
    // Create date string in timezone-aware format
    const dateTimeStr = `${year}-${(month + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}T${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:00`;
    const appointmentDateTime = new Date(dateTimeStr);

    const appointmentData: InsertAppointment = {
      serviceId: selectedService.id,
      clientName,
      clientEmail,
      clientPhone: clientPhone || "Not provided",
      appointmentDate: appointmentDateTime,
      duration: selectedService.duration,
      price: 100.00, // Default price - can be customized per service
      timezone: timezone, // Store the timezone used when booking
      status: "pending",
      notes: notes || undefined,
      providerId: providerId || selectedService.userId, // Link to specific provider
    };

    createAppointmentMutation.mutate(appointmentData);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8">
      {/* Calenday Branding Badge - Only show for free plan users */}
      {profileData && profileData.subscriptionPlan !== 'pro' && (
        <div className="mb-4 flex justify-center">
          <div className="bg-white border border-gray-200 rounded-full px-4 py-2 shadow-sm flex items-center gap-2">
            <img 
              src={Clenday} 
              alt="Calenday" 
              className="h-4 w-4"
            />
            <span className="text-sm text-gray-600">
              Powered by <span className="font-semibold text-blue-600">Calenday</span>
            </span>
          </div>
        </div>
      )}
      
      {/* Strong Company Branding Header */}
      {profileData && (
        <div className="mb-8">
          <Card className="border-2 border-blue-100 shadow-xl bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10"></div>
            <CardContent className="p-8 relative">
              <div className="flex flex-col sm:flex-row items-center sm:items-start space-y-6 sm:space-y-0 sm:space-x-8">
                <div className="relative flex-shrink-0">
                  <Avatar className="h-24 w-24 ring-4 ring-white shadow-xl">
                    <AvatarImage
                      src={profileData.companyLogoUrl || ""}
                      alt={`${profileData.companyName || 'Company'} logo`}
                      className="object-cover"
                    />
                    <AvatarFallback className="text-3xl bg-gradient-to-br from-blue-100 to-indigo-100 text-blue-700 font-bold">
                      {profileData.companyName?.charAt(0)?.toUpperCase() || 
                       profileData.firstName?.charAt(0)?.toUpperCase() || 
                       <Building2 className="h-12 w-12" />}
                    </AvatarFallback>
                  </Avatar>
                  <div className="absolute -bottom-1 -right-1 h-7 w-7 bg-green-500 rounded-full border-3 border-white flex items-center justify-center">
                    <div className="h-3 w-3 bg-white rounded-full"></div>
                  </div>
                </div>
                <div className="text-center sm:text-left flex-1">
                  <div className="mb-4">
                    <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-2 leading-tight">
                      {profileData.companyName || 
                       `${profileData.firstName || ''} ${profileData.lastName || ''}`.trim() || 
                       'Professional Services'}
                    </h1>
                    <p className="text-xl text-gray-600 font-medium">
                      {profileData.companyName 
                        ? `Welcome to ${profileData.companyName}` 
                        : `Book your appointment with ${profileData.firstName || 'our team'}`}
                    </p>
                  </div>
                  <div className="flex flex-wrap justify-center sm:justify-start gap-3">
                    <Badge variant="secondary" className="bg-blue-100 text-blue-800 px-4 py-2 text-sm font-semibold">
                      <Calendar className="h-4 w-4 mr-2" />
                      Professional Scheduling
                    </Badge>
                    <Badge variant="secondary" className="bg-green-100 text-green-800 px-4 py-2 text-sm font-semibold">
                      <Clock className="h-4 w-4 mr-2" />
                      Instant Booking
                    </Badge>
                    <Badge variant="secondary" className="bg-purple-100 text-purple-800 px-4 py-2 text-sm font-semibold">
                      <Building2 className="h-4 w-4 mr-2" />
                      Trusted Service
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      {/* Loading state for company branding */}
      {profileLoading && (
        <div className="mb-8">
          <Card className="border-2 border-gray-100 shadow-lg">
            <CardContent className="p-8">
              <div className="flex items-center space-x-6">
                <div className="h-24 w-24 bg-gray-200 rounded-full animate-pulse"></div>
                <div className="flex-1">
                  <div className="h-8 bg-gray-200 rounded-lg mb-2 animate-pulse"></div>
                  <div className="h-4 bg-gray-200 rounded-lg mb-4 animate-pulse"></div>
                  <div className="flex gap-2">
                    <div className="h-6 w-20 bg-gray-200 rounded-full animate-pulse"></div>
                    <div className="h-6 w-20 bg-gray-200 rounded-full animate-pulse"></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      <div className="mb-6 sm:mb-8">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4 mb-4">
          <div>
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold mb-2">Book an Appointment</h1>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" />
              <span>Times shown in {timezone}</span>
            </div>
          </div>
          {profileData?.allowTimezoneSelection === true && <TimezoneSelector />}
        </div>
      </div>
      <div className="mt-6 sm:mt-8">
        {currentStep === 1 && (
          <div>
            
            <ServiceSelector
              selectedService={selectedService}
              onServiceSelect={handleServiceSelect}
              queryKey={providerId ? `/api/services/provider/${providerId}` : "/api/services"}
            />
          </div>
        )}

        {currentStep === 2 && selectedService && (
          <div>
            <h2 className="text-lg sm:text-xl lg:text-2xl font-semibold mb-4 sm:mb-6">Select Date & Time</h2>
            <div className="mb-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <Badge variant="outline" className="text-sm">
                      Selected Service
                    </Badge>
                    <div>
                      <span className="font-medium">{selectedService.name}</span>
                      <span className="text-muted-foreground ml-2">
                        ({selectedService.duration} minutes)
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            <CalendarTimeSelector
              selectedDate={selectedDate}
              selectedTime={selectedTime}
              providerId={providerId}
              onDateSelect={(date) => setSelectedDate(date)}
              onTimeSelect={(time) => setSelectedTime(time)}
            />
            {selectedDate && selectedTime && (
              <div className="mt-6 flex flex-col sm:flex-row gap-3">
                <Button 
                  variant="outline"
                  onClick={() => {
                    setSelectedService(null);
                    setSelectedDate(null);
                    setSelectedTime(null);
                    setCurrentStep(1);
                    setCompletedSteps([]);
                  }}
                  className="w-full sm:flex-1"
                >
                  Back
                </Button>
                <Button 
                  onClick={() => handleDateTimeSelect(selectedDate, selectedTime)}
                  className="w-full sm:flex-1"
                >
                  Continue to Contact Information
                </Button>
              </div>
            )}
          </div>
        )}

        {currentStep === 3 && selectedService && selectedDate && selectedTime && (
          <div>
            <h2 className="text-2xl font-semibold mb-6">Contact Information</h2>
            
            {/* Booking Summary */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="text-lg">Booking Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{selectedService.name}</span>
                    <Badge variant="outline">{selectedService.duration} min</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>{selectedDate.toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>{selectedTime} ({timezone})</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Contact Form */}
            <Card>
              <CardHeader>
                <CardTitle>Your Information</CardTitle>
                <CardDescription>
                  Please provide your contact details for the appointment
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="clientName">Full Name *</Label>
                    <Input
                      id="clientName"
                      value={clientName}
                      onChange={(e) => setClientName(e.target.value)}
                      placeholder="Enter your full name"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="clientEmail">Email Address *</Label>
                    <Input
                      id="clientEmail"
                      type="email"
                      value={clientEmail}
                      onChange={(e) => setClientEmail(e.target.value)}
                      placeholder="Enter your email"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="clientPhone">Phone Number</Label>
                  <Input
                    id="clientPhone"
                    type="tel"
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    placeholder="Enter your phone number (optional)"
                  />
                </div>
                
                <div>
                  <Label htmlFor="notes">Additional Notes</Label>
                  <Textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Any additional information or special requests (optional)"
                    rows={3}
                  />
                </div>

                <div className="flex gap-4 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setCurrentStep(2);
                      setCompletedSteps([1]);
                    }}
                    className="flex-1"
                  >
                    Back
                  </Button>
                  <Button
                    onClick={handleBookingSubmit}
                    disabled={createAppointmentMutation.isPending}
                    className="flex-1"
                  >
                    {createAppointmentMutation.isPending ? "Booking..." : "Confirm Booking"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {currentStep === 4 && (
          <div>
            
            
            <Card className="max-w-2xl mx-auto">
              <CardHeader className="text-center">
                <CardTitle className="text-xl text-green-600">Your Appointment is Confirmed</CardTitle>
                <CardDescription>
                  We've successfully booked your appointment. Here are the details:
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Service Details */}
                <div className="border rounded-lg p-4">
                  <h3 className="font-semibold mb-3 flex items-center">
                    <User className="h-4 w-4 mr-2" />
                    Service Details
                  </h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Service:</span>
                      <span className="font-medium">{selectedService?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Duration:</span>
                      <span className="font-medium">{selectedService?.duration} minutes</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Description:</span>
                      <span className="font-medium">{selectedService?.description}</span>
                    </div>
                  </div>
                </div>

                {/* Appointment Details */}
                <div className="border rounded-lg p-4">
                  <h3 className="font-semibold mb-3 flex items-center">
                    <Calendar className="h-4 w-4 mr-2" />
                    Appointment Details
                  </h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Date:</span>
                      <span className="font-medium">{selectedDate?.toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Time:</span>
                      <span className="font-medium">{selectedTime} {timezone}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Status:</span>
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        Confirmed
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* Contact Details */}
                <div className="border rounded-lg p-4">
                  <h3 className="font-semibold mb-3 flex items-center">
                    <Mail className="h-4 w-4 mr-2" />
                    Contact Information
                  </h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Name:</span>
                      <span className="font-medium">{clientName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Email:</span>
                      <span className="font-medium">{clientEmail}</span>
                    </div>
                    {clientPhone && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Phone:</span>
                        <span className="font-medium">{clientPhone}</span>
                      </div>
                    )}
                    {notes && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Notes:</span>
                        <span className="font-medium">{notes}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Next Steps - Only show if custom message exists */}
                {profileData?.whatsNextMessage && profileData.whatsNextMessage.trim() && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h3 className="font-semibold mb-2 text-blue-800">What's Next?</h3>
                    <div className="text-sm text-blue-700 whitespace-pre-line">
                      {profileData.whatsNextMessage}
                    </div>
                  </div>
                )}

                <div className="text-center space-y-3">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <Button 
                      onClick={() => {
                        const googleCalendarUrl = generateGoogleCalendarUrl();
                        if (googleCalendarUrl) {
                          window.open(googleCalendarUrl, '_blank', 'noopener,noreferrer');
                        } else {
                          toast({
                            title: "Error",
                            description: "Unable to generate calendar event. Please ensure all booking details are complete.",
                            variant: "destructive",
                          });
                        }
                      }}
                      className="w-full bg-blue-600 hover:bg-blue-700 flex items-center justify-center"
                    >
                      <img 
                        src={google_calenday}
                        alt="Google Calendar" 
                        className="h-4 w-4 mr-2"
                      />
                      Add to Google Calendar
                    </Button>

                    <Button 
                      onClick={() => {
                        const outlookCalendarUrl = generateOutlookCalendarUrl();
                        if (outlookCalendarUrl) {
                          window.open(outlookCalendarUrl, '_blank', 'noopener,noreferrer');
                        } else {
                          toast({
                            title: "Error",
                            description: "Unable to generate calendar event. Please ensure all booking details are complete.",
                            variant: "destructive",
                          });
                        }
                      }}
                      className="w-full bg-blue-600 hover:bg-blue-700 flex items-center justify-center"
                    >
                      <img 
                        src={icons8_outlook_50}
                        alt="Outlook" 
                        className="h-4 w-4 mr-2"
                      />
                      Add to Outlook
                    </Button>
                  </div>

                  <Button 
                    onClick={() => {
                      window.location.reload();
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    Book Another Appointment
                  </Button>
                  
                  {profileData?.companyWebsite && profileData?.companyWebsiteEnabled && (
                    <Button 
                      variant="outline"
                      onClick={() => {
                        if (profileData.companyWebsite) {
                          window.open(profileData.companyWebsite, '_blank', 'noopener,noreferrer');
                        }
                      }}
                      className="w-full"
                    >
                      Back to Website
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
      {/* Footer - Only show for free plan users */}
      {profileData && profileData.subscriptionPlan !== 'pro' && (
        <footer className="mt-12 py-6 border-t border-gray-200">
          <div className="text-center">
            <p className="text-sm text-gray-500 flex items-center justify-center gap-2">
              Made with 
              <img 
                src={Clenday} 
                alt="Calenday" 
                className="h-4 w-4"
              />
              <a 
                href="/" 
                className="font-medium text-blue-600 hover:text-blue-800 transition-colors duration-200"
                target="_blank"
                rel="noopener noreferrer"
              >
                Calenday
              </a>
            </p>
          </div>
        </footer>
      )}
    </div>
  );
}

export default function GuestBooking() {
  return <GuestBookingContent />;
}