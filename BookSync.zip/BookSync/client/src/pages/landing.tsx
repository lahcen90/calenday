import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Calendar, Clock, Users, Shield, Star, CheckCircle, ArrowRight, Phone, Mail, MapPin, Zap, Globe, Smartphone, BarChart3, Lock, HeartHandshake, Award } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import Calenday from "@assets/Clenday.png";
import PublicHeader from "@/components/public-header";
import Meta from "@/components/meta";

export default function Landing() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const { toast } = useToast();

  const loginMutation = useMutation({
    mutationFn: async (data: { email: string; name: string }) => {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error(await response.text());
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "You have been logged in successfully!",
      });
      window.location.reload();
    },
    onError: (error: any) => {
      toast({
        title: "Login Failed",
        description: error.message || "Failed to log in. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast({
        title: "Email Required",
        description: "Please enter your email address.",
        variant: "destructive",
      });
      return;
    }
    loginMutation.mutate({ email, name });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <Meta 
        title="Calenday - Professional Appointment Scheduling Platform"
        description="Transform your business with Calenday's intelligent appointment scheduling. Trusted by 10,000+ businesses worldwide with 99.9% uptime. Free and Pro plans available."
        keywords="appointment scheduling, booking system, calendar management, business scheduling, online appointments, Calenday"
      />
      <PublicHeader />
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center relative">
          {/* Multiple Calendar Background Icons */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
            {/* Large center calendar */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 opacity-5">
              <div className="animate-pulse">
                <Calendar className="w-96 h-96 text-slate-400" />
              </div>
            </div>
            
            {/* Top left calendar */}
            <div className="absolute top-16 left-16 opacity-30">
              <div className="animate-bounce" style={{ animationDelay: '1s', animationDuration: '3s' }}>
                <Calendar className="w-24 h-24 text-slate-300" />
              </div>
            </div>
            
            {/* Top right calendar */}
            <div className="absolute top-20 right-20 opacity-30">
              <div className="animate-pulse" style={{ animationDelay: '2s' }}>
                <Calendar className="w-32 h-32 text-slate-300" />
              </div>
            </div>
            
            {/* Bottom left calendar */}
            <div className="absolute bottom-32 left-12 opacity-30">
              <div className="animate-pulse" style={{ animationDelay: '0.5s', animationDuration: '4s' }}>
                <Calendar className="w-28 h-28 text-slate-300" />
              </div>
            </div>
            
            {/* Bottom right calendar */}
            <div className="absolute bottom-24 right-16 opacity-30">
              <div className="animate-bounce" style={{ animationDelay: '1.5s', animationDuration: '2.5s' }}>
                <Calendar className="w-20 h-20 text-slate-300" />
              </div>
            </div>
            
            {/* Middle left calendar */}
            <div className="absolute top-1/3 left-8 opacity-20">
              <div className="animate-pulse" style={{ animationDelay: '3s', animationDuration: '5s' }}>
                <Calendar className="w-16 h-16 text-slate-200" />
              </div>
            </div>
            
            {/* Middle right calendar */}
            <div className="absolute top-2/3 right-8 opacity-20">
              <div className="animate-bounce" style={{ animationDelay: '2.5s', animationDuration: '3.5s' }}>
                <Calendar className="w-20 h-20 text-slate-200" />
              </div>
            </div>
          </div>
          <h1 className="text-5xl font-bold text-slate-900 mb-6 relative z-10">
            Welcome to <span className="text-[#3C83F6]">Calenday</span> - The Future of Appointment Scheduling
          </h1>
          <p className="text-xl text-slate-600 mb-8 max-w-4xl mx-auto relative z-10">
            Calenday transforms business scheduling with its advanced platform, offering powerful tools, seamless customer experiences, and full control. Trusted by thousands of professionals globally, Calenday is the #1 choice for innovative, comprehensive solutions. Experience it today!
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12 relative z-10">
            <Link href="/register">
              <Button size="lg" className="bg-[#3C83F6] hover:bg-[#2563EB] px-8 py-3 text-lg">
                Start with Calenday Today
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16 relative z-10">
            <div className="text-center">
              <div className="text-3xl font-bold text-[#3C83F6] mb-2">10,000+</div>
              <div className="text-slate-600">Businesses Trust Calenday Worldwide</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-[#3C83F6] mb-2">200K+</div>
              <div className="text-slate-600">Appointments Booked via Calenday Platform</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-[#3C83F6] mb-2">100%</div>
              <div className="text-slate-600">Calenday Reliability & Uptime</div>
            </div>
          </div>
        </div>

        {/* Why Choose Calenday Section */}
        <div className="mt-24">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-4">
            Why Choose <span className="text-[#3C83F6]">Calenday</span> for Your Business?
          </h2>
          <p className="text-xl text-center text-slate-600 mb-16 max-w-3xl mx-auto">
            Calenday offers everything you need to streamline appointments. From Calenday's intuitive booking interface 
            to Calenday's powerful analytics, discover how Calenday transforms your business operations.
          </p>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
            <Card className="border-2 hover:border-[#3C83F6] transition-colors">
              <CardHeader className="text-center">
                <Calendar className="h-12 w-12 text-[#3C83F6] mx-auto mb-4" />
                <CardTitle className="text-slate-900">Smart Calenday Booking</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 text-center">
                  Calenday's intelligent booking system prevents double-bookings and optimizes your schedule automatically. 
                  Experience the power of Calenday's smart scheduling.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-[#3C83F6] transition-colors">
              <CardHeader className="text-center">
                <Clock className="h-12 w-12 text-[#3C83F6] mx-auto mb-4" />
                <CardTitle className="text-slate-900">Calenday Time Management</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 text-center">
                  Maximize productivity with Calenday's advanced time management features. Calenday helps you 
                  manage availability and reduce no-shows effectively.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-[#3C83F6] transition-colors">
              <CardHeader className="text-center">
                <Users className="h-12 w-12 text-[#3C83F6] mx-auto mb-4" />
                <CardTitle className="text-slate-900">Calenday Customer Hub</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 text-center">
                  Manage all customer relationships through Calenday's comprehensive customer management system. 
                  Calenday stores history, preferences, and contact details.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-[#3C83F6] transition-colors">
              <CardHeader className="text-center">
                <Globe className="h-12 w-12 text-[#3C83F6] mx-auto mb-4" />
                <CardTitle className="text-slate-900">Calenday Multi-Platform</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 text-center">
                  Access Calenday from anywhere - desktop, tablet, or mobile. Calenday's responsive design 
                  ensures perfect experience across all devices.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-[#3C83F6] transition-colors">
              <CardHeader className="text-center">
                <BarChart3 className="h-12 w-12 text-[#3C83F6] mx-auto mb-4" />
                <CardTitle className="text-slate-900">Calenday Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 text-center">
                  Get insights into your business with Calenday's powerful analytics dashboard. 
                  Calenday tracks performance, revenue, and customer satisfaction metrics.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-[#3C83F6] transition-colors">
              <CardHeader className="text-center">
                <Lock className="h-12 w-12 text-[#3C83F6] mx-auto mb-4" />
                <CardTitle className="text-slate-900">Calenday Security</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 text-center">
                  Your data is safe with Calenday's enterprise-grade security. Calenday uses bank-level 
                  encryption to protect all information stored in Calenday.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* How Calenday Works Section */}
        <div className="mt-24 bg-white rounded-2xl p-12 shadow-lg">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-4">
            How <span className="text-[#3C83F6]">Calenday</span> Works
          </h2>
          <p className="text-xl text-center text-slate-600 mb-16">
            Getting started with Calenday is simple. Follow these steps to transform your appointment booking with Calenday.
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-[#3C83F6] rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-6">1</div>
              <h3 className="text-xl font-bold text-slate-900 mb-4">Set Up Your Calenday Account</h3>
              <p className="text-slate-600">
                Create your Calenday profile in minutes. Configure your services, availability, and preferences 
                to personalize your Calenday experience.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-[#3C83F6] rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-6">2</div>
              <h3 className="text-xl font-bold text-slate-900 mb-4">Share Your Calenday Link or Embed Code</h3>
              <p className="text-slate-600">
                Get your unique Calenday booking link and share it with customers. They can book appointments 
                through your personalized Calenday page instantly.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-[#3C83F6] rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-6">3</div>
              <h3 className="text-xl font-bold text-slate-900 mb-4">Manage with Calenday Dashboard</h3>
              <p className="text-slate-600">
                Use Calenday's powerful dashboard to manage appointments, track revenue, and grow your business. 
                Calenday handles the rest automatically.
              </p>
            </div>
          </div>
        </div>

        {/* Testimonials Section */}
        <div className="mt-24">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-4">
            What Our Customers Say About <span className="text-[#3C83F6]">Calenday</span>
          </h2>
          <p className="text-xl text-center text-slate-600 mb-16">
            Thousands of businesses have transformed their operations with Calenday. Here's what they say about Calenday.
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-2">
              <CardContent className="p-6">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-slate-600 mb-4">
                  "Calenday has completely transformed our salon operations. Before Calenday, we struggled with 
                  double bookings. Now with Calenday, everything runs smoothly."
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-[#3C83F6] rounded-full flex items-center justify-center text-white font-bold mr-3">
                    S
                  </div>
                  <div>
                    <div className="font-semibold text-slate-900">Adrian Fowler</div>
                    <div className="text-sm text-slate-500">Beauty Salon Owner</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardContent className="p-6">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-slate-600 mb-4">
                  "As a therapist, Calenday has been a game-changer. My clients love booking through Calenday, 
                  and I love how Calenday manages my entire schedule."
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-[#3C83F6] rounded-full flex items-center justify-center text-white font-bold mr-3">
                    M
                  </div>
                  <div>
                    <div className="font-semibold text-slate-900">Michael Chen</div>
                    <div className="text-sm text-slate-500">Licensed Therapist</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardContent className="p-6">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-slate-600 mb-4">
                  "Calenday is an easy to use scheduling tool that helps keep me organized and makes it even easier 
                  for clients to schedule time with me."
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-[#3C83F6] rounded-full flex items-center justify-center text-white font-bold mr-3">
                    L
                  </div>
                  <div>
                    <div className="font-semibold text-slate-900">Lisa Rodriguez</div>
                    <div className="text-sm text-slate-500">Fitness Studio Manager</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-24">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-4">
            Frequently Asked Questions About <span className="text-[#3C83F6]">Calenday</span>
          </h2>
          <p className="text-xl text-center text-slate-600 mb-16">
            Get answers to common questions about Calenday's appointment scheduling platform.
          </p>

          <div className="max-w-4xl mx-auto">
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger className="text-left text-lg font-semibold text-slate-900">
                  What is Calenday and how does it work?
                </AccordionTrigger>
                <AccordionContent>
                  <p className="text-slate-600">
                    Calenday is a comprehensive appointment scheduling platform that streamlines booking for businesses of all sizes. 
                    With Calenday, you can create custom booking pages, manage availability, send automated reminders, and track 
                    your business performance. Customers can book appointments 24/7 through your personalized Calenday booking link.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2">
                <AccordionTrigger className="text-left text-lg font-semibold text-slate-900">
                  How much does Calenday cost?
                </AccordionTrigger>
                <AccordionContent>
                  <p className="text-slate-600">
                    Calenday offers a free plan with basic features and a Pro plan at $4.00/month with advanced features including 
                    unlimited appointments, custom branding, analytics, and priority support. You can start with Calenday's free 
                    plan and upgrade anytime as your business grows.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3">
                <AccordionTrigger className="text-left text-lg font-semibold text-slate-900">
                  Can I customize my Calenday booking page?
                </AccordionTrigger>
                <AccordionContent>
                  <p className="text-slate-600">
                    Yes! Calenday Pro users can fully customize their booking pages with custom branding, logos, and 
                    messaging. You can make your Calenday booking page match your brand perfectly. Free Calenday users get 
                    basic customization options to personalize their booking experience.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4">
                <AccordionTrigger className="text-left text-lg font-semibold text-slate-900">
                  Does Calenday integrate with Google Calendar?
                </AccordionTrigger>
                <AccordionContent>
                  <p className="text-slate-600">
                    Absolutely! Calenday seamlessly integrates with Google Calendar to sync all your appointments. When someone 
                    books through Calenday, the appointment automatically appears in your Google Calendar. This ensures you never 
                    miss an appointment and can manage your schedule from anywhere.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5">
                <AccordionTrigger className="text-left text-lg font-semibold text-slate-900">
                  Can customers book appointments without creating an account?
                </AccordionTrigger>
                <AccordionContent>
                  <p className="text-slate-600">
                    Yes! Calenday supports both guest bookings and registered user bookings. Customers can quickly book 
                    appointments through your Calenday page by simply providing their contact information. For returning 
                    customers, Calenday can remember their preferences for even faster booking.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-6">
                <AccordionTrigger className="text-left text-lg font-semibold text-slate-900">
                  Does Calenday send appointment reminders?
                </AccordionTrigger>
                <AccordionContent>
                  <p className="text-slate-600">
                    Yes! Calenday automatically sends email reminders to both you and your customers before appointments. 
                    You can customize when reminders are sent and what they say. This feature helps reduce no-shows and 
                    keeps everyone informed about upcoming appointments.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-7">
                <AccordionTrigger className="text-left text-lg font-semibold text-slate-900">
                  Is my data secure with Calenday?
                </AccordionTrigger>
                <AccordionContent>
                  <p className="text-slate-600">
                    Security is a top priority for Calenday. We use bank-level encryption to protect all data stored in 
                    Calenday. Your customer information, appointment details, and business data are completely secure. 
                    Calenday complies with industry security standards and regularly updates our security measures.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-8">
                <AccordionTrigger className="text-left text-lg font-semibold text-slate-900">
                  Can I accept payments through Calenday?
                </AccordionTrigger>
                <AccordionContent>
                  <p className="text-slate-600">
                    Yes! Calenday integrates with PayPal for secure payment processing. You can require payment at booking 
                    or collect payments later. Calenday Pro users get access to advanced payment features and detailed 
                    revenue tracking to help grow their business.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-9">
                <AccordionTrigger className="text-left text-lg font-semibold text-slate-900">
                  What types of businesses use Calenday?
                </AccordionTrigger>
                <AccordionContent>
                  <p className="text-slate-600">
                    Calenday is perfect for any business that schedules appointments: salons, spas, healthcare providers, 
                    consultants, therapists, fitness trainers, tutors, and many more. Whether you're a solo practitioner 
                    or manage a team, Calenday scales to meet your needs.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-10">
                <AccordionTrigger className="text-left text-lg font-semibold text-slate-900">
                  How do I get started with Calenday?
                </AccordionTrigger>
                <AccordionContent>
                  <p className="text-slate-600">
                    Getting started with Calenday is simple! Just sign up for a free account, set up your services and 
                    availability, customize your booking page, and share your unique Calenday link with customers. 
                    You can start accepting bookings in minutes with Calenday.
                  </p>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-24 bg-gradient-to-r from-[#3C83F6] to-[#2563EB] rounded-2xl p-12 text-center text-white">
          <h2 className="text-4xl font-bold mb-4">
            Ready to Experience Calenday?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of businesses already using Calenday. Start your free Calenday trial today 
            and discover why Calenday is the preferred choice for appointment scheduling.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/register">
              <Button size="lg" className="bg-white hover:bg-slate-100 px-8 py-3 text-lg text-[#2b3245]">
                Start Free Calenday Trial
              </Button>
            </Link>
            <Link href="/pricing">
              <Button size="lg" variant="outline" className="border-white hover:bg-white hover:text-[#3C83F6] px-8 py-3 text-lg text-[#2b3245]">
                View Calenday Pricing
              </Button>
            </Link>
          </div>
        </div>
      </div>
      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-24">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand */}
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img 
                  src={Calenday} 
                  alt="Calenday Logo" 
                  className="h-8 w-8"
                />
                <span className="text-xl font-bold text-slate-900">Calenday</span>
              </div>
              <p className="text-slate-600 mb-4">
                Calenday - Professional appointment scheduling made simple. Streamline your business with Calenday's powerful booking system.
              </p>
              
            </div>

            {/* Product */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Calenday Product</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/pricing" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Pricing
                  </Link>
                </li>
                <li>
                  <span className="text-slate-400">Mobile App (Coming Soon)</span>
                </li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">About Calenday</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/about-us" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    About Calenday
                  </Link>
                </li>
                <li>
                  <Link href="/contact-us" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Contact Calenday
                  </Link>
                </li>
              </ul>
            </div>

            {/* Support & Legal */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Calenday Support</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/help-center" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday FAQ
                  </Link>
                </li>
                <li>
                  <Link href="/privacy-policy" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms-of-use" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Terms of Use
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Footer */}
          <div className="border-t border-slate-200 mt-8 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-slate-600 text-sm">© 2025 Calenday. All rights reserved.</p>
              <div className="flex space-x-6 mt-4 md:mt-0">
                <span className="text-slate-400 text-sm">Follow Calenday:</span>
                <a 
                  href="https://x.com/Calenday_io" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-[#3C83F6] text-sm transition-colors"
                >
                  Calenday Twitter
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}