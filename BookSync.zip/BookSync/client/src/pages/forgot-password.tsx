import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { resetPasswordSchema } from "@shared/schema";
import { Link } from "wouter";
import { KeyRound, Mail, CheckCircle } from "lucide-react";
import { z } from "zod";

import Clenday from "@assets/Clenday.png";

type ForgotPasswordForm = z.infer<typeof resetPasswordSchema>;

export default function ForgotPassword() {
  const [isEmailSent, setIsEmailSent] = useState(false);
  const [emailAddress, setEmailAddress] = useState("");

  const form = useForm<ForgotPasswordForm>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      email: "",
    },
  });

  const forgotPasswordMutation = useMutation({
    mutationFn: async (data: ForgotPasswordForm) => {
      return await apiRequest("/api/auth/forgot-password", "POST", data);
    },
    onSuccess: (data) => {
      setEmailAddress(form.getValues("email"));
      setIsEmailSent(true);
    },
    onError: (error: Error) => {
      toast({
        title: "Request Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ForgotPasswordForm) => {
    forgotPasswordMutation.mutate(data);
  };

  if (isEmailSent) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold flex items-center justify-center gap-2">
              <CheckCircle className="h-6 w-6 text-green-600" />
              Check Your Email
            </CardTitle>
            <CardDescription>
              Password reset instructions sent
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <Mail className="h-12 w-12 text-blue-600 mx-auto mb-3" />
              <h3 className="font-semibold text-blue-800 mb-2">Reset Link Sent</h3>
              <p className="text-sm text-blue-700">
                If an account exists with this email, you'll receive a password reset link at:
              </p>
              <p className="font-medium text-blue-800 mt-1">
                {emailAddress}
              </p>
            </div>

            <div className="text-sm text-gray-600 space-y-2">
              <p>
                <strong>Next steps:</strong>
              </p>
              <ol className="text-left space-y-1 ml-4">
                <li>1. Check your email inbox</li>
                <li>2. Click the reset password link</li>
                <li>3. Create your new password</li>
                <li>4. Sign in with new password</li>
              </ol>
            </div>

            <div className="space-y-3 pt-4">
              <Link href="/sign-in">
                <Button variant="outline" className="w-full">
                  Back to Sign In
                </Button>
              </Link>
              <Link href="/">
                <Button variant="ghost" className="w-full">
                  Back to Home
                </Button>
              </Link>
            </div>

            <p className="text-xs text-gray-500 mt-4">
              Didn't receive the email? Check your spam folder. The reset link expires in 1 hour.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <img 
              src={Clenday} 
              alt="Calenday Logo" 
              className="h-12 w-12"
            />
          </div>
          <CardTitle className="text-2xl font-bold">
            Reset Your Password
          </CardTitle>
          <CardDescription>
            Enter your email to receive a password reset link
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <Label htmlFor="email">Email Address</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email address"
                  className="pl-10"
                  {...form.register("email")}
                />
              </div>
              {form.formState.errors.email && (
                <p className="text-sm text-red-500 mt-1">
                  {form.formState.errors.email.message}
                </p>
              )}
            </div>

            <Button 
              type="submit" 
              className="w-full" 
              disabled={forgotPasswordMutation.isPending}
            >
              {forgotPasswordMutation.isPending ? "Sending Reset Link..." : "Send Reset Link"}
            </Button>
          </form>

          <div className="text-center mt-6 space-y-2">
            <Link href="/sign-in">
              <Button variant="ghost" className="text-sm">
                Back to Sign In
              </Button>
            </Link>
            <div className="text-sm text-gray-600">
              Don't have an account?{" "}
              <Link href="/register">
                <span className="text-blue-600 hover:underline cursor-pointer">
                  Create one here
                </span>
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}