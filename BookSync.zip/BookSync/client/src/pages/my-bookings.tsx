import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Calendar, Clock, MapPin, User } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatAppointmentTime } from "@/lib/timezone";
import type { Appointment, Service } from "@shared/schema";

export default function MyBookings() {
  const { data: appointments = [], isLoading } = useQuery<Appointment[]>({
    queryKey: ["/api/my-appointments"],
  });

  const { data: services = [] } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const serviceMap = new Map(services.map(service => [service.id, service]));

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">Loading your bookings...</div>
      </div>
    );
  }

  const upcomingAppointments = appointments
    .filter(apt => new Date(apt.appointmentDate) > new Date() && apt.status !== "cancelled")
    .sort((a, b) => new Date(a.appointmentDate).getTime() - new Date(b.appointmentDate).getTime());

  const pastAppointments = appointments
    .filter(apt => new Date(apt.appointmentDate) <= new Date() || apt.status === "completed")
    .sort((a, b) => new Date(b.appointmentDate).getTime() - new Date(a.appointmentDate).getTime());

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-green-100 text-green-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const AppointmentCard = ({ appointment }: { appointment: Appointment }) => {
    const service = serviceMap.get(appointment.serviceId);
    const appointmentDate = new Date(appointment.appointmentDate);
    const endTime = new Date(appointmentDate.getTime() + (appointment.duration * 60 * 1000));

    return (
      <Card className="mb-4">
        <CardContent className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div className="flex-1">
              <h3 className="font-semibold text-lg mb-2">
                {service?.name || 'Service'}
              </h3>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  {format(appointmentDate, "EEEE, MMMM d, yyyy")}
                </div>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-2" />
                  {formatAppointmentTime(appointmentDate, appointment.timezone || 'UTC')} - {formatAppointmentTime(endTime, appointment.timezone || 'UTC')} {appointment.timezone || 'UTC'}
                  <span className="ml-2 text-gray-500">({appointment.duration} min)</span>
                </div>
                {service?.description && (
                  <div className="flex items-start">
                    <MapPin className="h-4 w-4 mr-2 mt-0.5" />
                    <span>{service.description}</span>
                  </div>
                )}
              </div>
            </div>
            <Badge className={getStatusColor(appointment.status)}>
              {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
            </Badge>
          </div>
          
          {appointment.notes && (
            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-700">
                <strong>Notes:</strong> {appointment.notes}
              </p>
            </div>
          )}
          
          <div className="mt-4 text-xs text-gray-500">
            Booked on {format(new Date(appointment.createdAt), "MMM d, yyyy 'at' h:mm a")}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">My Bookings</h1>
        <p className="text-gray-600">View and manage your appointment history</p>
      </div>

      {appointments.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <User className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium mb-2">No bookings yet</h3>
            <p className="text-gray-600 mb-4">
              You haven't made any appointments yet. Book your first appointment to get started!
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-8">
          {upcomingAppointments.length > 0 && (
            <div>
              <h2 className="text-2xl font-semibold mb-4">
                Upcoming Appointments ({upcomingAppointments.length})
              </h2>
              {upcomingAppointments.map(appointment => (
                <AppointmentCard key={appointment.id} appointment={appointment} />
              ))}
            </div>
          )}

          {pastAppointments.length > 0 && (
            <div>
              <h2 className="text-2xl font-semibold mb-4">
                Past Appointments ({pastAppointments.length})
              </h2>
              {pastAppointments.map(appointment => (
                <AppointmentCard key={appointment.id} appointment={appointment} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}