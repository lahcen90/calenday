import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Clock, Save, X } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import type { Service, InsertService } from "@shared/schema";
import { Link } from "wouter";
import Calenday from "@assets/Clenday.png";

export default function ServicesManagement() {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [newService, setNewService] = useState({
    name: "",
    description: "",
    duration: 60,
  });

  const queryClient = useQueryClient();
  const { user } = useAuth();
  
  // Check if user has Pro plan
  const isPro = (user as any)?.subscriptionPlan === 'pro';
  const isFreePlan = !isPro;

  const { data: services = [], isLoading } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const createServiceMutation = useMutation({
    mutationFn: async (serviceData: InsertService) => {
      return await apiRequest("/api/services", "POST", serviceData);
    },
    onSuccess: () => {
      toast({
        title: "Service Created",
        description: "New service has been added successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/services"] });
      setIsAddDialogOpen(false);
      setNewService({ name: "", description: "", duration: 60 });
    },
    onError: (error: Error) => {
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create service.",
        variant: "destructive",
      });
    },
  });

  const updateServiceMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertService> }) => {
      return await apiRequest(`/api/services/${id}`, "PATCH", data);
    },
    onSuccess: () => {
      toast({
        title: "Service Updated",
        description: "Service has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/services"] });
      setEditingService(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update service.",
        variant: "destructive",
      });
    },
  });

  const deleteServiceMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/services/${id}`, "DELETE");
    },
    onSuccess: () => {
      toast({
        title: "Service Deleted",
        description: "Service has been removed successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/services"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Deletion Failed",
        description: error.message || "Failed to delete service.",
        variant: "destructive",
      });
    },
  });

  const handleCreateService = () => {
    // Check service limit for free plan users
    if (isFreePlan && services.length >= 1) {
      toast({
        title: "Service Limit Reached",
        description: "Free plan users can only create 1 service. Upgrade to Pro for unlimited services.",
        variant: "destructive",
      });
      return;
    }

    if (!newService.name.trim() || !newService.description.trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    createServiceMutation.mutate({
      name: newService.name.trim(),
      description: newService.description.trim(),
      duration: newService.duration,
      isActive: true,
    });
  };

  const handleUpdateService = (service: Service) => {
    if (!service.name.trim() || !(service.description || "").trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    updateServiceMutation.mutate({
      id: service.id,
      data: {
        name: service.name.trim(),
        description: (service.description || "").trim(),
        duration: service.duration,
        isActive: service.isActive,
      },
    });
  };

  const handleDeleteService = (id: number) => {
    // Check if this is the last active service
    const activeServices = services.filter(service => service.isActive);
    if (activeServices.length <= 1) {
      toast({
        title: "Cannot Delete Service",
        description: "You must have at least one active service. Please create another service before deleting this one.",
        variant: "destructive",
      });
      return;
    }

    if (confirm("Are you sure you want to delete this service? This action cannot be undone.")) {
      deleteServiceMutation.mutate(id);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Navigation />
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">Loading services...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navigation />
      
      <div className="flex-1 max-w-6xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4 mb-6 sm:mb-8">
          <div className="flex-1">
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold text-slate-900 mb-2">Services Management</h2>
            <p className="text-sm sm:text-base text-slate-600">Manage your services and their durations</p>
            {services.filter(s => s.isActive).length <= 1 && services.length > 0 && (
              <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-md">
                <p className="text-sm text-amber-800">
                  <strong>Note:</strong> At least one service is required for your appointment booking system. 
                  Add additional services before deleting your current service.
                </p>
              </div>
            )}
          </div>
          
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                className="w-full sm:w-auto"
                disabled={isFreePlan && services.length >= 1}
                onClick={() => {
                  if (isFreePlan && services.length >= 1) {
                    toast({
                      title: "Upgrade to Pro",
                      description: "Free plan users can only create 1 service. Upgrade to Pro for unlimited services.",
                      variant: "destructive",
                    });
                  }
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Service
                {isFreePlan && services.length >= 1 && (
                  <span className="ml-2 text-xs bg-purple-500 text-white px-2 py-1 rounded">
                    Pro Only
                  </span>
                )}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Service</DialogTitle>
                <DialogDescription>
                  Create a new service with custom duration options.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Service Name</Label>
                  <Input
                    id="name"
                    value={newService.name}
                    onChange={(e) => setNewService({ ...newService, name: e.target.value })}
                    placeholder="e.g., Consultation"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newService.description}
                    onChange={(e) => setNewService({ ...newService, description: e.target.value })}
                    placeholder="Describe your service..."
                  />
                </div>
                <div>
                  <Label htmlFor="duration">Default Duration (minutes)</Label>
                  <Input
                    id="duration"
                    type="number"
                    min="15"
                    max="480"
                    step="15"
                    value={newService.duration}
                    onChange={(e) => setNewService({ ...newService, duration: parseInt(e.target.value) || 60 })}
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleCreateService}
                    disabled={createServiceMutation.isPending}
                  >
                    {createServiceMutation.isPending ? "Creating..." : "Create Service"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Services List */}
        <div className="grid gap-6">
          {services.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center">
                <p className="text-slate-500 mb-4">No services yet. Create your first service to get started.</p>
                <Button onClick={() => setIsAddDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add First Service
                </Button>
              </CardContent>
            </Card>
          ) : (
            services.map((service) => (
              <Card key={service.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      {editingService?.id === service.id ? (
                        <div className="space-y-3">
                          <div>
                            <Label>Service Name</Label>
                            <Input
                              value={editingService.name}
                              onChange={(e) => setEditingService({ ...editingService, name: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label>Description</Label>
                            <Textarea
                              value={editingService.description || ""}
                              onChange={(e) => setEditingService({ ...editingService, description: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label>Default Duration (minutes)</Label>
                            <Input
                              type="number"
                              min="15"
                              max="480"
                              step="15"
                              value={editingService.duration}
                              onChange={(e) => setEditingService({ ...editingService, duration: parseInt(e.target.value) || 60 })}
                            />
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center gap-3">
                            <CardTitle>{service.name}</CardTitle>
                            <Badge variant={service.isActive ? "default" : "secondary"}>
                              {service.isActive ? "Active" : "Inactive"}
                            </Badge>
                          </div>
                          <CardDescription className="mt-2">{service.description || ""}</CardDescription>
                          <div className="flex items-center mt-3 text-sm text-slate-600">
                            <Clock className="h-4 w-4 mr-1" />
                            Default: {service.duration} minutes
                          </div>
                        </>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {editingService?.id === service.id ? (
                        <>
                          <Button
                            size="sm"
                            onClick={() => handleUpdateService(editingService)}
                            disabled={updateServiceMutation.isPending}
                          >
                            <Save className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setEditingService(null)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </>
                      ) : (
                        <>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setEditingService(service)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDeleteService(service.id)}
                            disabled={deleteServiceMutation.isPending || services.filter(s => s.isActive).length <= 1}
                            title={services.filter(s => s.isActive).length <= 1 ? "Cannot delete the last service. At least one service is required." : "Delete service"}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))
          )}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-24">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand */}
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img 
                  src={Calenday} 
                  alt="Calenday Logo" 
                  className="h-8 w-8"
                />
                <span className="text-xl font-bold text-slate-900">Calenday</span>
              </div>
              <p className="text-slate-600 mb-4">
                Calenday - Professional appointment scheduling made simple. Streamline your business with Calenday's powerful booking system.
              </p>
            </div>

            {/* Product */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Calenday Product</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/pricing" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Pricing
                  </Link>
                </li>
                <li>
                  <span className="text-slate-400">Calenday Mobile App (Coming Soon)</span>
                </li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">About Calenday</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/about-us" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    About Calenday
                  </Link>
                </li>
                <li>
                  <Link href="/contact-us" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Contact Calenday
                  </Link>
                </li>
              </ul>
            </div>

            {/* Support & Legal */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Calenday Support</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/help-center" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday FAQ
                  </Link>
                </li>
                <li>
                  <Link href="/privacy-policy" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms-of-use" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Terms of Use
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Footer */}
          <div className="border-t border-slate-200 mt-8 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-slate-600 text-sm">© 2025 Calenday. All rights reserved.</p>
              <div className="flex space-x-6 mt-4 md:mt-0">
                <span className="text-slate-400 text-sm">Follow Calenday:</span>
                <a 
                  href="https://x.com/Calenday_io" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-[#3C83F6] text-sm transition-colors"
                >
                  Calenday Twitter
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}