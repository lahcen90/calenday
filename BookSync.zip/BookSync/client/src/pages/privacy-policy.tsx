import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import PublicHeader from "@/components/public-header";
import Meta from "@/components/meta";
import Calenday from "@assets/Clenday.png";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <Meta 
        title="Privacy Policy - Calenday Data Protection"
        description="Learn how Calenday protects your personal information and data. Our comprehensive privacy policy outlines data collection, usage, and security measures."
        keywords="privacy policy, data protection, personal information, security, GDPR compliance"
      />
      <PublicHeader />
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">
            Privacy Policy
          </h1>
          <p className="text-slate-600">
            Last updated: December 12, 2025
          </p>
        </div>

        {/* Privacy Content */}
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-8 prose prose-lg max-w-none">
              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">1. Information We Collect</h2>
                <p className="text-slate-700 mb-4">
                  We collect information you provide directly to us, such as when you create an account, 
                  schedule appointments, or contact us for support.
                </p>
                <h3 className="text-xl font-medium mb-3">Personal Information:</h3>
                <ul className="list-disc pl-6 text-slate-700 mb-4">
                  <li>Name and contact information (email, phone number)</li>
                  <li>Account credentials and profile information</li>
                  <li>Appointment details and scheduling preferences</li>
                  <li>Payment information (processed securely by third parties)</li>
                  <li>Communications with our support team</li>
                </ul>
                <h3 className="text-xl font-medium mb-3">Automatically Collected Information:</h3>
                <ul className="list-disc pl-6 text-slate-700 mb-4">
                  <li>Device and browser information</li>
                  <li>IP address and location data</li>
                  <li>Usage data and analytics</li>
                  <li>Cookies and similar tracking technologies</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">2. How We Use Your Information</h2>
                <p className="text-slate-700 mb-4">
                  We use the information we collect to provide, maintain, and improve our services:
                </p>
                <ul className="list-disc pl-6 text-slate-700 mb-4">
                  <li>Process and manage your appointments and bookings</li>
                  <li>Send appointment confirmations, reminders, and updates</li>
                  <li>Provide customer support and respond to inquiries</li>
                  <li>Process payments and prevent fraud</li>
                  <li>Improve our services and develop new features</li>
                  <li>Send marketing communications (with your consent)</li>
                  <li>Comply with legal obligations</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">3. Information Sharing and Disclosure</h2>
                <p className="text-slate-700 mb-4">
                  We do not sell, trade, or rent your personal information to third parties. We may share 
                  your information in the following circumstances:
                </p>
                <ul className="list-disc pl-6 text-slate-700 mb-4">
                  <li><strong>Service Providers:</strong> With trusted third-party services that help us operate our platform</li>
                  <li><strong>Business Transfers:</strong> In connection with mergers, acquisitions, or asset sales</li>
                  <li><strong>Legal Requirements:</strong> When required by law or to protect our rights</li>
                  <li><strong>With Your Consent:</strong> When you explicitly agree to share information</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">4. Data Security</h2>
                <p className="text-slate-700 mb-4">
                  We implement appropriate technical and organizational measures to protect your personal information:
                </p>
                <ul className="list-disc pl-6 text-slate-700 mb-4">
                  <li>Encryption of data in transit and at rest</li>
                  <li>Regular security assessments and monitoring</li>
                  <li>Access controls and authentication measures</li>
                  <li>Secure payment processing through certified providers</li>
                  <li>Regular backup and disaster recovery procedures</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">5. Your Rights and Choices</h2>
                <p className="text-slate-700 mb-4">
                  You have certain rights regarding your personal information:
                </p>
                <ul className="list-disc pl-6 text-slate-700 mb-4">
                  <li><strong>Access:</strong> Request access to your personal information</li>
                  <li><strong>Correction:</strong> Update or correct inaccurate information</li>
                  <li><strong>Deletion:</strong> Request deletion of your personal information</li>
                  <li><strong>Portability:</strong> Request a copy of your data in a portable format</li>
                  <li><strong>Opt-out:</strong> Unsubscribe from marketing communications</li>
                  <li><strong>Restriction:</strong> Request limitation of processing</li>
                </ul>
                <p className="text-slate-700 mb-4">
                  To exercise these rights, please contact us at privacy@clenday.com.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">6. Cookies and Tracking Technologies</h2>
                <p className="text-slate-700 mb-4">
                  We use cookies and similar technologies to enhance your experience:
                </p>
                <ul className="list-disc pl-6 text-slate-700 mb-4">
                  <li><strong>Essential Cookies:</strong> Required for basic functionality</li>
                  <li><strong>Analytics Cookies:</strong> Help us understand how you use our service</li>
                  <li><strong>Preference Cookies:</strong> Remember your settings and preferences</li>
                  <li><strong>Marketing Cookies:</strong> Used for targeted advertising (with consent)</li>
                </ul>
                <p className="text-slate-700 mb-4">
                  You can control cookies through your browser settings.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">7. Data Retention</h2>
                <p className="text-slate-700 mb-4">
                  We retain your personal information for as long as necessary to provide our services 
                  and fulfill the purposes outlined in this policy. Specific retention periods include:
                </p>
                <ul className="list-disc pl-6 text-slate-700 mb-4">
                  <li>Account information: Until account deletion</li>
                  <li>Appointment data: 7 years for business records</li>
                  <li>Payment information: As required by law</li>
                  <li>Marketing data: Until you opt-out</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">8. International Transfers</h2>
                <p className="text-slate-700 mb-4">
                  Your information may be transferred to and processed in countries other than your own. 
                  We ensure appropriate safeguards are in place to protect your data during international transfers.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">9. Children's Privacy</h2>
                <p className="text-slate-700 mb-4">
                  Our service is not intended for children under 13. We do not knowingly collect personal 
                  information from children under 13. If you become aware that a child has provided us with 
                  personal information, please contact us.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">10. Changes to This Policy</h2>
                <p className="text-slate-700 mb-4">
                  We may update this Privacy Policy from time to time. We will notify you of any changes 
                  by posting the new policy on this page and updating the "Last updated" date.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">11. Contact Us</h2>
                <p className="text-slate-700 mb-4">
                  If you have questions about this Privacy Policy, please contact us:
                </p>
                <div className="bg-slate-50 p-4 rounded-lg">
                  <p className="text-slate-700">
                    Email: support@calenday.io
                  </p>
                </div>
              </section>
            </CardContent>
          </Card>
        </div>

        {/* Back to Home */}
        <div className="text-center mt-12">
          <Link href="/">
            <Button variant="ghost">
              ← Back to Home
            </Button>
          </Link>
        </div>
      </div>

      
    </div>
  );
}