import { Calendar, Clock, Users, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import PublicHeader from "@/components/public-header";
import Meta from "@/components/meta";
import Calenday from "@assets/Clenday.png";

export default function AboutUs() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <Meta 
        title="About Us - Calenday Team & Mission"
        description="Learn about Calenday's mission to simplify appointment scheduling. Our story, values, and commitment to helping businesses grow through better scheduling solutions."
        keywords="about Calenday, company mission, scheduling platform, team, business values"
      />
      <PublicHeader />
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">
            About Clenday
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            We're building the future of appointment scheduling with intelligent, user-friendly solutions 
            that simplify booking for businesses and their customers.
          </p>
        </div>

        {/* Mission Section */}
        <div className="max-w-4xl mx-auto mb-16">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold text-center mb-6">Our Mission</h2>
              <p className="text-lg text-slate-700 text-center leading-relaxed">
                To eliminate the friction in appointment scheduling by providing businesses with 
                powerful, intuitive tools that enhance customer experience while streamlining operations. 
                We believe that booking an appointment should be as simple as a few clicks.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card className="text-center border-2 hover:border-[#9433EA] transition-colors">
            <CardHeader>
              <Calendar className="h-12 w-12 text-[#9433EA] mx-auto mb-4" />
              <CardTitle className="text-lg">Smart Scheduling</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Intelligent calendar integration that prevents double bookings and optimizes availability.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center border-2 hover:border-[#9433EA] transition-colors">
            <CardHeader>
              <Clock className="h-12 w-12 text-[#9433EA] mx-auto mb-4" />
              <CardTitle className="text-lg">Real-time Updates</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Instant notifications and automated reminders keep everyone informed and on schedule.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center border-2 hover:border-[#9433EA] transition-colors">
            <CardHeader>
              <Users className="h-12 w-12 text-[#9433EA] mx-auto mb-4" />
              <CardTitle className="text-lg">Customer Focus</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Designed with both service providers and customers in mind for seamless experiences.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center border-2 hover:border-[#9433EA] transition-colors">
            <CardHeader>
              <Shield className="h-12 w-12 text-[#9433EA] mx-auto mb-4" />
              <CardTitle className="text-lg">Secure & Reliable</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Enterprise-grade security and 99.9% uptime ensure your data and appointments are safe.
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* Story Section */}
        <div className="max-w-4xl mx-auto mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Our Story</h2>
          <div className="prose prose-lg mx-auto text-slate-700">
            <p className="mb-6">
              Clenday was born from a simple frustration: the complexity of scheduling appointments. 
              Our founders experienced firsthand the challenges businesses face when managing bookings, 
              from double-booked slots to missed appointments and poor customer communication.
            </p>
            <p className="mb-6">
              We envisioned a platform that would make appointment scheduling effortless for both 
              service providers and their customers. After months of research and development, 
              we created Clenday - a comprehensive solution that addresses the real pain points 
              of appointment management.
            </p>
            <p>
              Today, thousands of businesses trust Clenday to manage their scheduling needs, 
              from small independent practitioners to growing enterprises. We're committed to 
              continuously improving our platform based on user feedback and industry best practices.
            </p>
          </div>
        </div>

        {/* Values Section */}
        <div className="max-w-4xl mx-auto mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Our Values</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4 text-[#9433EA]">Simplicity</h3>
              <p className="text-slate-600">
                We believe complex problems should have simple solutions. Every feature is designed 
                with user experience at the forefront.
              </p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4 text-[#9433EA]">Reliability</h3>
              <p className="text-slate-600">
                Your business depends on us, so we've built our platform to be rock-solid reliable 
                with enterprise-grade infrastructure.
              </p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4 text-[#9433EA]">Innovation</h3>
              <p className="text-slate-600">
                We're constantly evolving our platform with cutting-edge features that stay ahead 
                of industry trends and user needs.
              </p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-slate-600 mb-6">
            Join thousands of businesses that trust Clenday for their appointment scheduling needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/register">
              <Button className="bg-[#3C83F6] hover:bg-[#2563eb]">
                Start Free Trial
              </Button>
            </Link>
            <Link href="/contact-us">
              <Button variant="outline">
                Contact Sales
              </Button>
            </Link>
          </div>
        </div>

        {/* Back to Home */}
        <div className="text-center mt-12">
          <Link href="/">
            <Button variant="ghost">
              ← Back to Home
            </Button>
          </Link>
        </div>
      </div>
      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-24">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand */}
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img 
                  src={Calenday} 
                  alt="Calenday Logo" 
                  className="h-8 w-8"
                />
                <span className="text-xl font-bold text-slate-900">Calenday</span>
              </div>
              <p className="text-slate-600 mb-4">
                Calenday - Professional appointment scheduling made simple. Streamline your business with Calenday's powerful booking system.
              </p>
            </div>

            {/* Product */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Calenday Product</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/pricing" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Pricing
                  </Link>
                </li>
                <li>
                  <span className="text-slate-400">Calenday Mobile App (Coming Soon)</span>
                </li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">About Calenday</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/about-us" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    About Calenday
                  </Link>
                </li>
                <li>
                  <Link href="/contact-us" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Contact Calenday
                  </Link>
                </li>
              </ul>
            </div>

            {/* Support & Legal */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Calenday Support</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/help-center" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday FAQ
                  </Link>
                </li>
                <li>
                  <Link href="/privacy-policy" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms-of-use" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Terms of Use
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Footer */}
          <div className="border-t border-slate-200 mt-8 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-slate-600 text-sm">© 2025 Calenday. All rights reserved.</p>
              <div className="flex space-x-6 mt-4 md:mt-0">
                <span className="text-slate-400 text-sm">Follow Calenday:</span>
                <a 
                  href="https://x.com/Calenday_io" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-[#3C83F6] text-sm transition-colors"
                >
                  Calenday Twitter
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}