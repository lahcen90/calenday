import { useState } from "react";
import { Search, Book, Users, Settings, Calendar, CreditCard, Shield, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import PublicHeader from "@/components/public-header";
import Meta from "@/components/meta";
import Calenday from "@assets/Clenday.png";

interface HelpArticle {
  id: string;
  title: string;
  description: string;
  category: string;
  tags: string[];
}

const helpArticles: HelpArticle[] = [
  {
    id: "getting-started",
    title: "Getting Started with Clenday",
    description: "Learn the basics of setting up your account and creating your first service.",
    category: "Getting Started",
    tags: ["setup", "basics", "new-user"]
  },
  {
    id: "create-services",
    title: "How to Create and Manage Services",
    description: "Step-by-step guide to adding services, setting durations, and managing availability.",
    category: "Services",
    tags: ["services", "setup", "management"]
  },
  {
    id: "booking-process",
    title: "Understanding the Booking Process",
    description: "Learn how customers book appointments and how you can manage them.",
    category: "Bookings",
    tags: ["bookings", "customers", "process"]
  },
  {
    id: "calendar-integration",
    title: "Calendar Integration Guide",
    description: "Connect your external calendars to prevent double bookings.",
    category: "Integrations",
    tags: ["calendar", "google", "integration"]
  },
  {
    id: "email-notifications",
    title: "Setting Up Email Notifications",
    description: "Configure automatic emails for bookings, confirmations, and reminders.",
    category: "Notifications",
    tags: ["email", "notifications", "automation"]
  },
  {
    id: "custom-branding",
    title: "Customizing Your Booking Page",
    description: "Add your logo, colors, and branding to create a professional booking experience.",
    category: "Customization",
    tags: ["branding", "customization", "pro"]
  },
  {
    id: "payment-setup",
    title: "Upgrading to Pro",
    description: "Learn about Pro features and how to upgrade your account.",
    category: "Billing",
    tags: ["pro", "upgrade", "payment"]
  },
  {
    id: "troubleshooting",
    title: "Common Issues and Solutions",
    description: "Troubleshoot common problems and find quick solutions.",
    category: "Troubleshooting",
    tags: ["issues", "problems", "solutions"]
  },
  {
    id: "security-privacy",
    title: "Security and Privacy Features",
    description: "Understand how we protect your data and ensure privacy.",
    category: "Security",
    tags: ["security", "privacy", "data"]
  },
  {
    id: "mobile-access",
    title: "Using Clenday on Mobile Devices",
    description: "Access your dashboard and manage appointments from any device.",
    category: "Mobile",
    tags: ["mobile", "responsive", "access"]
  }
];

const categories = [
  { name: "Getting Started", icon: Book, color: "text-blue-600" },
  { name: "Services", icon: Settings, color: "text-green-600" },
  { name: "Bookings", icon: Calendar, color: "text-purple-600" },
  { name: "Notifications", icon: Users, color: "text-orange-600" },
  { name: "Billing", icon: CreditCard, color: "text-red-600" },
  { name: "Security", icon: Shield, color: "text-gray-600" }
];

export default function HelpCenter() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredArticles = helpArticles.filter(article => {
    const matchesSearch = searchTerm === "" || 
      article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = selectedCategory === null || article.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <Meta 
        title="Help Center - Calenday Support & Documentation"
        description="Find answers to common questions about Calenday. Comprehensive help articles, tutorials, and troubleshooting guides for appointment scheduling."
        keywords="help center, support, documentation, tutorials, troubleshooting, Calenday help"
      />
      <PublicHeader />
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">
            Help Center
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Find guides, tutorials, and answers to help you get the most out of Clenday.
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-2xl mx-auto mb-12">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
            <Input
              placeholder="Search for help articles..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 py-3 text-lg"
            />
          </div>
        </div>

        {/* Categories */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-center mb-8">Browse by Category</h2>
          <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-4 max-w-6xl mx-auto">
            {categories.map((category) => {
              const Icon = category.icon;
              return (
                <Card 
                  key={category.name}
                  className={`cursor-pointer border-2 transition-all hover:border-[#9433EA] ${
                    selectedCategory === category.name ? 'border-[#9433EA] bg-purple-50' : ''
                  }`}
                  onClick={() => setSelectedCategory(
                    selectedCategory === category.name ? null : category.name
                  )}
                >
                  <CardContent className="p-4 text-center">
                    <Icon className={`h-8 w-8 mx-auto mb-2 ${category.color}`} />
                    <h3 className="font-medium text-sm">{category.name}</h3>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          {selectedCategory && (
            <div className="text-center mt-4">
              <Button 
                variant="ghost" 
                onClick={() => setSelectedCategory(null)}
                className="text-[#9433EA]"
              >
                Clear filter
              </Button>
            </div>
          )}
        </div>

        {/* Articles */}
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">
              {selectedCategory ? `${selectedCategory} Articles` : 'All Articles'}
            </h2>
            <span className="text-slate-600">
              {filteredArticles.length} article{filteredArticles.length !== 1 ? 's' : ''}
            </span>
          </div>

          {filteredArticles.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <h3 className="text-xl font-semibold mb-2">No articles found</h3>
                <p className="text-slate-600 mb-4">
                  Try adjusting your search terms or browse different categories.
                </p>
                <Button onClick={() => { setSearchTerm(""); setSelectedCategory(null); }}>
                  Clear all filters
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredArticles.map((article) => (
                <Card key={article.id} className="border-2 hover:border-[#9433EA] transition-colors">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-xl font-semibold text-slate-900">
                            {article.title}
                          </h3>
                          <Badge variant="outline" className="text-xs">
                            {article.category}
                          </Badge>
                        </div>
                        <p className="text-slate-600 mb-3">
                          {article.description}
                        </p>
                        <div className="flex gap-2">
                          {article.tags.map((tag) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-slate-400 ml-4 flex-shrink-0" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div className="mt-16 grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <Card className="border-2 hover:border-[#9433EA] transition-colors">
            <CardHeader>
              <CardTitle className="text-center">Still Need Help?</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-slate-600 mb-4">
                Can't find what you're looking for? Contact our support team.
              </p>
              <Link href="/contact-us">
                <Button className="bg-[#3C83F6] hover:bg-[#2563EB]">
                  Contact Support
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-[#9433EA] transition-colors">
            <CardHeader>
              <CardTitle className="text-center">Video Tutorials</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-slate-600 mb-4">
                Watch step-by-step video guides for common tasks.
              </p>
              <Button variant="outline" disabled>
                Coming Soon
              </Button>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-[#9433EA] transition-colors">
            <CardHeader>
              <CardTitle className="text-center">Feature Requests</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-slate-600 mb-4">
                Suggest new features or improvements to Clenday.
              </p>
              <Link href="/contact-us">
                <Button variant="outline">
                  Submit Idea
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Back to Home */}
        <div className="text-center mt-12">
          <Link href="/">
            <Button variant="ghost">
              ← Back to Home
            </Button>
          </Link>
        </div>
      </div>
      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-24">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand */}
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img 
                  src={Calenday} 
                  alt="Calenday Logo" 
                  className="h-8 w-8"
                />
                <span className="text-xl font-bold text-slate-900">Calenday</span>
              </div>
              <p className="text-slate-600 mb-4">
                Calenday - Professional appointment scheduling made simple. Streamline your business with Calenday's powerful booking system.
              </p>
            </div>

            {/* Product */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Calenday Product</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/pricing" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Pricing
                  </Link>
                </li>
                <li>
                  <span className="text-slate-400">Calenday Mobile App (Coming Soon)</span>
                </li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">About Calenday</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/about-us" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    About Calenday
                  </Link>
                </li>
                <li>
                  <Link href="/contact-us" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Contact Calenday
                  </Link>
                </li>
              </ul>
            </div>

            {/* Support & Legal */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Calenday Support</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/help-center" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday FAQ
                  </Link>
                </li>
                <li>
                  <Link href="/privacy-policy" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms-of-use" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Terms of Use
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Footer */}
          <div className="border-t border-slate-200 mt-8 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-slate-600 text-sm">© 2025 Calenday. All rights reserved.</p>
              <div className="flex space-x-6 mt-4 md:mt-0">
                <span className="text-slate-400 text-sm">Follow Calenday:</span>
                <a 
                  href="https://x.com/Calenday_io" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-[#3C83F6] text-sm transition-colors"
                >
                  Calenday Twitter
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}