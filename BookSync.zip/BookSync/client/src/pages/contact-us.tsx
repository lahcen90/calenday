import { useState } from "react";
import { Mail, Phone, MapPin, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { Link } from "wouter";
import PublicHeader from "@/components/public-header";
import Meta from "@/components/meta";
import Calenday from "@assets/Clenday.png";

export default function ContactUs() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    category: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Simulate form submission
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Message Sent",
        description: "Thank you for contacting us. We'll get back to you within 24 hours."
      });
      
      // Reset form
      setFormData({
        name: "",
        email: "",
        subject: "",
        category: "",
        message: ""
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <Meta 
        title="Contact Us - Calenday Support"
        description="Get in touch with Calenday's support team. We're here to help with questions, technical support, and account assistance. 24/7 customer service available."
        keywords="contact Calenday, customer support, help desk, technical support, contact form"
      />
      <PublicHeader />
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16">
        {/* Header */}
        <div className="text-center mb-8 sm:mb-12">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-900 mb-4">
            Contact Us
          </h1>
          <p className="text-base sm:text-lg lg:text-xl text-slate-600 max-w-2xl mx-auto px-4">
            Get in touch with our team. We're here to help with any questions or support you need.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8 max-w-6xl mx-auto">
          {/* Contact Information */}
          <div className="lg:col-span-1">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-[#3C83F6]" />
                    Email Support
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 mb-2 text-sm sm:text-base">General inquiries:</p>
                  <p className="font-medium text-sm sm:text-base">support@calenday.io</p>
                  <p className="text-slate-600 mb-2 mt-4 text-sm sm:text-base">Sales questions:</p>
                  <p className="font-medium text-sm sm:text-base">support@calenday.io</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-[#3C83F6]" />
                    Phone Support
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="font-medium text-sm sm:text-base">WhatsApp: +1(316) 816-0373</p>
                  <p className="text-slate-600 mt-2 text-sm sm:text-base">
                    Available Monday - Friday
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <Clock className="h-5 w-5 text-[#3C83F6]" />
                    Business Hours
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex flex-col sm:flex-row sm:justify-between">
                      <span className="text-sm sm:text-base">Monday - Friday:</span>
                      <span className="text-sm sm:text-base font-medium">9:00 AM - 6:00 PM EST</span>
                    </div>
                    <div className="flex flex-col sm:flex-row sm:justify-between">
                      <span className="text-sm sm:text-base">Saturday:</span>
                      <span className="text-sm sm:text-base font-medium">10:00 AM - 4:00 PM EST</span>
                    </div>
                    <div className="flex flex-col sm:flex-row sm:justify-between">
                      <span className="text-sm sm:text-base">Sunday:</span>
                      <span className="text-sm sm:text-base font-medium">Closed</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <MapPin className="h-5 w-5 text-[#3C83F6]" />
                    Office Location
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="font-medium text-sm sm:text-base">Calenday Headquarters</p>
                  <p className="text-slate-600 text-sm sm:text-base">
                    Unit 116769 Courier Point<br />
                    13 Freeland Park, Wareham Road<br />
                    Poole, Dorset BH16 6FH<br />
                    United Kingdom
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Center Content Blocks */}
          <div className="lg:col-span-2">
            <div className="space-y-6">
              {/* Main Contact Block */}
              <Card className="border-2 border-[#3C83F6]/20">
                <CardHeader>
                  <CardTitle className="text-xl sm:text-2xl text-[#3C83F6]">
                    Get Support for Calenday
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 mb-4 text-sm sm:text-base">
                    Our dedicated support team is here to help you get the most out of Calenday. 
                    Whether you need assistance with setup, have questions about features, or need 
                    technical support, we're committed to providing you with excellent service.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="bg-[#3C83F6]/5 p-4 rounded-lg">
                      <h4 className="font-semibold text-slate-900 mb-2">Response Times</h4>
                      <p className="text-sm text-slate-600">
                        Free users: Within 48 hours<br/>
                        Pro users: Within 12 hours
                      </p>
                    </div>
                    <div className="bg-[#3C83F6]/5 p-4 rounded-lg">
                      <h4 className="font-semibold text-slate-900 mb-2">Support Channels</h4>
                      <p className="text-sm text-slate-600">
                        Email, Phone, Live Chat<br/>
                        Help Center & FAQ
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Common Issues Block */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg sm:text-xl">
                    Common Questions & Quick Solutions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border-l-4 border-[#3C83F6] pl-4">
                      <h4 className="font-semibold text-slate-900 mb-1">Setup Issues</h4>
                      <p className="text-sm text-slate-600">
                        Having trouble setting up your booking page? Check our Setup Guide in the Help Center.
                      </p>
                    </div>
                    <div className="border-l-4 border-[#3C83F6] pl-4">
                      <h4 className="font-semibold text-slate-900 mb-1">Easy ahead</h4>
                      <p className="text-sm text-slate-600">We simplify connecting with others, so you can achieve more.</p>
                    </div>
                    <div className="border-l-4 border-[#3C83F6] pl-4">
                      <h4 className="font-semibold text-slate-900 mb-1">Payment Issues</h4>
                      <p className="text-sm text-slate-600">
                        For billing and payment questions, contact our sales team at sales@calenday.com.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Enterprise Block */}
              <Card className="bg-gradient-to-r from-[#3C83F6]/5 to-[#2563EB]/5">
                <CardHeader>
                  <CardTitle className="text-lg sm:text-xl flex items-center gap-2">
                    <span>🏢</span>
                    Enterprise Solutions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 mb-4 text-sm sm:text-base">
                    Need custom solutions for your organization? Our enterprise team can help with:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-[#3C83F6] rounded-full"></div>
                      <span className="text-sm text-slate-600">Custom integrations</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-[#3C83F6] rounded-full"></div>
                      <span className="text-sm text-slate-600">White-label solutions</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-[#3C83F6] rounded-full"></div>
                      <span className="text-sm text-slate-600">Dedicated support</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-[#3C83F6] rounded-full"></div>
                      <span className="text-sm text-slate-600">Volume pricing</span>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-slate-200">
                    <p className="text-sm text-slate-600">
                      Contact our enterprise team: <span className="font-medium">support@calenday.io</span>
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* Additional Resources */}
        <div className="mt-12 sm:mt-16 text-center">
          <h2 className="text-xl sm:text-2xl font-bold mb-6 sm:mb-8 px-4">Other Ways to Get Help</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 max-w-4xl mx-auto">
            <Card className="border-2 hover:border-[#3C83F6] transition-colors">
              <CardContent className="p-4 sm:p-6 text-center">
                <h3 className="font-semibold text-base sm:text-lg mb-2">Help Center</h3>
                <p className="text-slate-600 mb-4 text-sm sm:text-base">
                  Browse our comprehensive documentation and tutorials.
                </p>
                <Link href="/help-center">
                  <Button variant="outline" className="w-full sm:w-auto">Visit Help Center</Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-[#3C83F6] transition-colors">
              <CardContent className="p-4 sm:p-6 text-center">
                <h3 className="font-semibold text-base sm:text-lg mb-2">FAQ</h3>
                <p className="text-slate-600 mb-4 text-sm sm:text-base">
                  Find quick answers to frequently asked questions.
                </p>
                <Link href="/faq">
                  <Button variant="outline" className="w-full sm:w-auto">View FAQ</Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-[#3C83F6] transition-colors">
              <CardContent className="p-4 sm:p-6 text-center">
                <h3 className="font-semibold text-base sm:text-lg mb-2">Community</h3>
                <p className="text-slate-600 mb-4 text-sm sm:text-base">
                  Connect with other users and share experiences.
                </p>
                <Button variant="outline" disabled className="w-full sm:w-auto">
                  Coming Soon
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Back to Home */}
        <div className="text-center mt-8 sm:mt-12">
          <Link href="/">
            <Button variant="ghost" className="text-sm sm:text-base">
              ← Back to Home
            </Button>
          </Link>
        </div>
      </div>
      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-24">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand */}
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img 
                  src={Calenday} 
                  alt="Calenday Logo" 
                  className="h-8 w-8"
                />
                <span className="text-xl font-bold text-slate-900">Calenday</span>
              </div>
              <p className="text-slate-600 mb-4">
                Calenday - Professional appointment scheduling made simple. Streamline your business with Calenday's powerful booking system.
              </p>
            </div>

            {/* Product */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Calenday Product</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/pricing" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Pricing
                  </Link>
                </li>
                <li>
                  <span className="text-slate-400">Calenday Mobile App (Coming Soon)</span>
                </li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">About Calenday</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/about-us" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    About Calenday
                  </Link>
                </li>
                <li>
                  <Link href="/contact-us" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Contact Calenday
                  </Link>
                </li>
              </ul>
            </div>

            {/* Support & Legal */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Calenday Support</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/help-center" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday FAQ
                  </Link>
                </li>
                <li>
                  <Link href="/privacy-policy" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms-of-use" className="text-slate-600 hover:text-[#3C83F6] transition-colors">
                    Calenday Terms of Use
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Footer */}
          <div className="border-t border-slate-200 mt-8 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-slate-600 text-sm">© 2025 Calenday. All rights reserved.</p>
              <div className="flex space-x-6 mt-4 md:mt-0">
                <span className="text-slate-400 text-sm">Follow Calenday:</span>
                <a 
                  href="https://x.com/Calenday_io" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-[#3C83F6] text-sm transition-colors"
                >
                  Calenday Twitter
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}