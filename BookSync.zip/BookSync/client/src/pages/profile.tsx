import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Building2, Upload, User, Save, Settings, Bell, Calendar } from "lucide-react";
import Navigation from "@/components/navigation";
import Meta from "@/components/meta";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useState, useEffect } from "react";

const profileSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  companyName: z.string().optional(),
  companyLogoUrl: z.string().url().optional().or(z.literal("")),
  companyWebsite: z.string().url().optional().or(z.literal("")),
  companyWebsiteEnabled: z.boolean().default(false),
  whatsNextMessage: z.string().optional(),
  emailNotificationsEnabled: z.boolean().default(true),
  emailReminders: z.boolean().default(true),
  reminderTime: z.coerce.number().min(1, "Reminder time must be at least 1").default(60),
  reminderUnit: z.enum(["minutes", "hours", "days"]).default("minutes"),
  allowMultipleBookings: z.boolean().default(false),
  allowTimezoneSelection: z.boolean().default(true),
  defaultTimezone: z.string().default("America/New_York"),
});

type ProfileFormData = z.infer<typeof profileSchema>;

export default function Profile() {
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string>("");
  const [isFormInitialized, setIsFormInitialized] = useState(false);

  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/user"],
  });
  const { user: authUser } = useAuth();

  // Check if user has Pro plan
  const isPro = (authUser as any)?.subscriptionPlan === 'pro';
  const isFreePlan = !isPro;

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      companyName: "",
      companyLogoUrl: "",
      companyWebsite: "",
      companyWebsiteEnabled: false,
      whatsNextMessage: "",
      emailNotificationsEnabled: true,
      emailReminders: true,
      reminderTime: 60,
      reminderUnit: "minutes",
      allowMultipleBookings: false,
      allowTimezoneSelection: true,
      defaultTimezone: "America/Chicago",
    },
  });

  // Update form when user data loads (only once)
  useEffect(() => {
    if (user && !isFormInitialized) {
      form.reset({
        firstName: (user as any).firstName || "",
        lastName: (user as any).lastName || "",
        companyName: (user as any).companyName || "",
        companyLogoUrl: (user as any).companyLogoUrl || "",
        companyWebsite: (user as any).companyWebsite || "",
        companyWebsiteEnabled: (user as any).companyWebsiteEnabled ?? false,
        whatsNextMessage: (user as any).whatsNextMessage || "",
        emailNotificationsEnabled: (user as any).emailNotificationsEnabled ?? true,
        emailReminders: (user as any).emailReminders ?? true,
        reminderTime: (user as any).reminderTime || 60,
        reminderUnit: (user as any).reminderUnit || "minutes",
        allowMultipleBookings: (user as any).allowMultipleBookings ?? false,
        allowTimezoneSelection: (user as any).allowTimezoneSelection ?? true,
        defaultTimezone: (user as any).defaultTimezone || "America/Chicago",
      });
      setIsFormInitialized(true);
    }
  }, [user, isFormInitialized, form]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormData) => {
      console.log("Sending profile data:", data);
      const response = await fetch("/api/profile", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP ${response.status}`);
      }
      
      return response.json();
    },
    onSuccess: (updatedUser) => {
      toast({
        title: "Profile Updated",
        description: "Your company profile has been updated successfully.",
      });
      // Refresh the page after successful save
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    },
    onError: (error: Error) => {
      console.error("Profile update error:", error);
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({
          title: "File Too Large",
          description: "Please choose an image smaller than 5MB.",
          variant: "destructive",
        });
        return;
      }

      if (!file.type.startsWith("image/")) {
        toast({
          title: "Invalid File Type",
          description: "Please choose an image file.",
          variant: "destructive",
        });
        return;
      }

      setLogoFile(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setLogoPreview(result);
        form.setValue("companyLogoUrl", result);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = (data: ProfileFormData) => {
    updateProfileMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/3 mb-6"></div>
            <div className="space-y-4">
              <div className="h-32 bg-gray-200 rounded"></div>
              <div className="h-20 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navigation />
      {/* Header Section */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-2xl mx-auto">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Settings className="h-8 w-8 text-blue-600" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Company Profile</h1>
                <p className="text-gray-600 mt-1">
                  Manage your company information and branding
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Content Section */}
      <div className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Personal Information Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="h-5 w-5 mr-2" />
                Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    {...form.register("firstName")}
                    placeholder="Enter your first name"
                    className="mt-1"
                  />
                  {form.formState.errors.firstName && (
                    <p className="text-sm text-red-600 mt-1">
                      {form.formState.errors.firstName.message}
                    </p>
                  )}
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    {...form.register("lastName")}
                    placeholder="Enter your last name"
                    className="mt-1"
                  />
                  {form.formState.errors.lastName && (
                    <p className="text-sm text-red-600 mt-1">
                      {form.formState.errors.lastName.message}
                    </p>
                  )}
                </div>
              </div>
              <div>
                <Label>Email</Label>
                <Input value={(user as any)?.email || ""} disabled className="bg-gray-50" />
                <p className="text-sm text-gray-500 mt-1">Email cannot be changed</p>
              </div>
            </CardContent>
          </Card>

          {/* Booking Preferences Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                Booking Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="allowMultipleBookings">Allow Multiple Bookings</Label>
                  <p className="text-sm text-gray-500">
                    Allow multiple clients to book the same time slot. When disabled, reserved times will be hidden from available slots.
                  </p>
                </div>
                <Switch
                  id="allowMultipleBookings"
                  checked={form.watch("allowMultipleBookings")}
                  onCheckedChange={(checked) => form.setValue("allowMultipleBookings", checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="allowTimezoneSelection">Allow Timezone Selection</Label>
                  <p className="text-sm text-gray-500">Allow clients to change their timezone when booking appointments. When disabled, Users will use their browser's detected timezone automatically.</p>
                </div>
                <Switch
                  id="allowTimezoneSelection"
                  checked={form.watch("allowTimezoneSelection")}
                  onCheckedChange={(checked) => form.setValue("allowTimezoneSelection", checked)}
                />
              </div>


            </CardContent>
          </Card>

          {/* Company Information Card */}
          <Card className={isFreePlan ? "opacity-60" : ""}>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center">
                  <Building2 className="h-5 w-5 mr-2" />
                  Company Information
                </div>
                {isFreePlan && (
                  <span className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold px-3 py-1 rounded-full">
                    PRO ONLY
                  </span>
                )}
              </CardTitle>
              {isFreePlan && (
                <p className="text-sm text-gray-600">
                  Upgrade to Pro to customize your company branding and information
                </p>
              )}
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label htmlFor="companyName">Company Name</Label>
                <Input
                  id="companyName"
                  {...form.register("companyName")}
                  placeholder={isFreePlan ? "Upgrade to Pro to set company name" : "Enter your company name"}
                  className="mt-1"
                  disabled={isFreePlan}
                />
                {form.formState.errors.companyName && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.companyName.message}
                  </p>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label htmlFor="companyWebsite">Company Website</Label>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="companyWebsiteEnabled"
                      checked={form.watch("companyWebsiteEnabled")}
                      onCheckedChange={(checked) => form.setValue("companyWebsiteEnabled", checked)}
                      disabled={isFreePlan}
                    />
                    <Label htmlFor="companyWebsiteEnabled" className="text-sm text-gray-600">
                      {form.watch("companyWebsiteEnabled") ? "Enabled" : "Disabled"}
                    </Label>
                  </div>
                </div>
                <Input
                  id="companyWebsite"
                  {...form.register("companyWebsite")}
                  placeholder={isFreePlan ? "Upgrade to Pro to set company website" : "https://www.yourcompany.com"}
                  className="mt-1"
                  disabled={isFreePlan || !form.watch("companyWebsiteEnabled")}
                />
                {form.formState.errors.companyWebsite && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.companyWebsite.message}
                  </p>
                )}
                <p className="text-sm text-gray-500 mt-1">
                  When enabled, a "Back to Website" button will appear after booking completion
                </p>
              </div>

              <div>
                <Label>Company Logo</Label>
                <div className="mt-2 flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <Avatar className="h-20 w-20">
                      <AvatarImage
                        src={logoPreview || form.watch("companyLogoUrl") || ""}
                        alt="Company logo"
                      />
                      <AvatarFallback className="text-2xl">
                        {form.watch("companyName")?.charAt(0)?.toUpperCase() || "C"}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => document.getElementById("logo-upload")?.click()}
                        disabled={isFreePlan}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        {isFreePlan ? "Pro Only" : "Upload Logo"}
                      </Button>
                      <input
                        id="logo-upload"
                        type="file"
                        accept="image/*"
                        onChange={handleLogoUpload}
                        className="hidden"
                      />
                    </div>
                    <p className="text-sm text-gray-500 mt-1">
                      Upload a company logo (PNG, JPG up to 5MB)
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <Label htmlFor="whatsNextMessage">What's Next? Message</Label>
                <Textarea
                  id="whatsNextMessage"
                  {...form.register("whatsNextMessage")}
                  placeholder={isFreePlan ? "Upgrade to Pro to customize post-booking message" : "Enter custom instructions for customers after booking completion"}
                  className="mt-1 min-h-[100px]"
                  disabled={isFreePlan}
                />
                <p className="text-sm text-gray-500 mt-1">
                  This message will appear in the "What's Next?" section after customers complete their booking
                </p>
              </div>


            </CardContent>
          </Card>

          {/* Notification Preferences Card */}
          <Card className={isFreePlan ? "opacity-60" : ""}>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center">
                  <Bell className="h-5 w-5 mr-2" />
                  Notification Preferences
                </div>
                {isFreePlan && (
                  <span className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold px-3 py-1 rounded-full">
                    PRO ONLY
                  </span>
                )}
              </CardTitle>
              {isFreePlan && (
                <p className="text-sm text-gray-600">
                  Upgrade to Pro to enable email reminders and customize notification settings
                </p>
              )}
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="emailNotificationsEnabled">All Email Notifications</Label>
                  <p className="text-sm text-gray-500">
                    Enable or disable all email notifications (booking confirmations, reminders, cancellations)
                  </p>
                </div>
                <Switch
                  id="emailNotificationsEnabled"
                  checked={form.watch("emailNotificationsEnabled")}
                  onCheckedChange={(checked) => form.setValue("emailNotificationsEnabled", checked)}
                  disabled={isFreePlan}
                />
              </div>

              {form.watch("emailNotificationsEnabled") && (
                <div className="flex items-center justify-between pl-4 border-l-2 border-gray-200">
                  <div className="space-y-0.5">
                    <Label htmlFor="emailReminders">Email Reminders</Label>
                    <p className="text-sm text-gray-500">
                      Send email reminders for upcoming appointments
                    </p>
                  </div>
                  <Switch
                    id="emailReminders"
                    checked={form.watch("emailReminders")}
                    onCheckedChange={(checked) => form.setValue("emailReminders", checked)}
                    disabled={isFreePlan}
                  />
                </div>
              )}

              {form.watch("emailNotificationsEnabled") && form.watch("emailReminders") && (
                <div className="space-y-4 pt-4 border-t pl-4 border-l-2 border-gray-200">
                  <Label>Reminder Timing</Label>
                  <div className="flex gap-3 items-center">
                    <div className="flex-1">
                      <Input
                        type="number"
                        min="1"
                        placeholder="Enter number"
                        {...form.register("reminderTime", {
                          valueAsNumber: true,
                          min: { value: 1, message: "Minimum value is 1" }
                        })}
                        className="w-full"
                        disabled={isFreePlan}
                      />
                      {form.formState.errors.reminderTime && (
                        <p className="text-sm text-red-600 mt-1">
                          {form.formState.errors.reminderTime.message}
                        </p>
                      )}
                    </div>
                    <Select
                      value={form.watch("reminderUnit")}
                      onValueChange={(value) => form.setValue("reminderUnit", value as "minutes" | "hours" | "days")}
                      disabled={isFreePlan}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="minutes">Minutes</SelectItem>
                        <SelectItem value="hours">Hours</SelectItem>
                        <SelectItem value="days">Days</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <p className="text-sm text-gray-500">
                    Customers will receive email reminders {form.watch("reminderTime") || 60} {form.watch("reminderUnit") || "minutes"} before their appointment
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Upgrade to Pro Section */}
          {isFreePlan && (
            <Card className="border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50">
              <CardContent className="pt-6">
                <div className="text-center space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">
                    Unlock Pro Features
                  </h3>
                  <p className="text-gray-600">
                    Upgrade to Pro to access company branding, email reminders, and advanced customization options.
                  </p>
                  <Button 
                    type="button"
                    className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-8 py-2"
                    onClick={() => window.location.href = '/api/upgrade'}
                  >
                    Upgrade to Pro
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Save Button */}
          <div className="flex justify-end">
            <Button
              type="submit"
              disabled={updateProfileMutation.isPending}
              className="min-w-32"
            >
              {updateProfileMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Saving...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </>
              )}
            </Button>
          </div>
        </form>
        </div>
      </div>
      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-auto">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center">
            <p className="text-slate-600 text-sm">© 2025 Calenday. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}