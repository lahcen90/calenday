import Navigation from "@/components/navigation";
import ServiceSelector from "@/components/service-selector";
import CalendarTimeSelector from "@/components/calendar-time-selector";
import BookingForm from "@/components/booking-form-new";
import Meta from "@/components/meta";

import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import type { Service } from "@shared/schema";

export default function CustomerBooking() {
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [location] = useLocation();

  const { data: services = [] } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  // Handle pre-selected service from booking link
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const serviceId = urlParams.get('service');
    
    if (serviceId && services) {
      const preSelectedService = services.find((service: Service) => service.id.toString() === serviceId);
      if (preSelectedService) {
        setSelectedService(preSelectedService);
      }
    }
  }, [services]);

  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
    setSelectedTime(null); // Clear selected time when date changes
  };

  const isFormReady = selectedService && selectedDate && selectedTime;



  return (
    <div className="min-h-screen bg-slate-50">
      <Meta 
        title="Book Appointment - Calenday Customer Booking"
        description="Book your appointment easily with Calenday. Choose your preferred service, date, and time. Fast and secure appointment scheduling for customers."
        keywords="book appointment, customer booking, schedule appointment, online booking, appointment reservation"
      />
      <Navigation />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Book Your Appointment</h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Choose your preferred service and time slot. We'll send you a confirmation email with all the details.
          </p>
        </div>

        

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Service Selection */}
          <div className="lg:col-span-1">
            <ServiceSelector
              selectedService={selectedService}
              onServiceSelect={setSelectedService}
            />
          </div>

          {/* Calendar and Time Selection */}
          <div className="lg:col-span-2">
            <CalendarTimeSelector
              selectedDate={selectedDate}
              selectedTime={selectedTime}
              onDateSelect={handleDateSelect}
              onTimeSelect={setSelectedTime}
            />

            {/* Booking Form */}
            {isFormReady && (
              <div className="mt-6">
                <BookingForm
                  selectedService={selectedService!}
                  selectedDate={selectedDate!}
                  selectedTime={selectedTime!}
                  onBookingComplete={() => {
                    setSelectedService(null);
                    setSelectedDate(null);
                    setSelectedTime(null);
                  }}
                />
              </div>
            )}



          </div>
        </div>
      </div>
    </div>
  );
}
