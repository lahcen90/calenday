import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Crown, Zap, Star, Building2, Bell, Palette } from "lucide-react";
import Navigation from "@/components/navigation";
import Meta from "@/components/meta";

import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { useState, useEffect } from "react";

const proFeatures = [
  {
    icon: Zap,
    title: "Unlimited Services",
    description: "Create unlimited services and appointments without restrictions"
  },
  {
    icon: Building2,
    title: "Company Branding",
    description: "Add your company logo, name, and custom website links"
  },
  {
    icon: Bell,
    title: "Email Reminders",
    description: "Automated email reminders for you and your customers"
  },
  {
    icon: Palette,
    title: "Custom Messaging",
    description: "Personalize post-booking messages and instructions"
  },
  {
    icon: Star,
    title: "Remove Branding",
    description: "Remove 'Made with Calenday' footer from guest booking pages"
  },
  {
    icon: Crown,
    title: "Priority Support",
    description: "Get premium support and access to new features first"
  }
];

export default function Upgrade() {
  const { user } = useAuth();
  const [upgradeComplete, setUpgradeComplete] = useState(false);
  const [paypalLoaded, setPaypalLoaded] = useState(false);

  const upgradeMutation = useMutation({
    mutationFn: async (paypalOrderId: string) => {
      // Check if user is authenticated first
      if (!user) {
        throw new Error("Please sign in to upgrade to Pro plan");
      }
      
      try {
        const response = await fetch("/api/upgrade/complete", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          credentials: "include",
          body: JSON.stringify({
            paypalOrderId: paypalOrderId
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Upgrade failed");
        }

        return await response.json();
      } catch (error) {
        console.error("Upgrade error:", error);
        throw error;
      }
    },
    onSuccess: () => {
      setUpgradeComplete(true);
      toast({
        title: "Welcome to Pro!",
        description: "Your account has been successfully upgraded to Pro plan.",
      });
    },
    onError: (error: Error) => {
      console.error("Upgrade mutation error:", error);
      
      // Handle authentication errors specifically
      if (error.message.includes("sign in") || error.message.includes("Unauthorized")) {
        toast({
          title: "Authentication Required",
          description: "Please sign in to upgrade to Pro plan.",
          variant: "destructive",
        });
        // Redirect to sign in page after a delay
        setTimeout(() => {
          window.location.href = "/sign-in";
        }, 2000);
      } else {
        toast({
          title: "Upgrade Failed",
          description: error.message || "Failed to complete the upgrade. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  const handlePayPalSuccess = (orderId: string) => {
    console.log('PayPal success handler called with order ID:', orderId);
    
    // Direct upgrade attempt - let the mutation handle auth errors
    upgradeMutation.mutate(orderId);
  };

  // Initialize PayPal SDK for advanced checkout
  useEffect(() => {
    if (!user || paypalLoaded) return;

    const initializePayPal = async () => {
      try {
        // Load PayPal SDK
        const script = document.createElement('script');
        // Get PayPal client ID from backend
        const clientIdResponse = await fetch('/api/paypal/client-id');
        const { clientId } = await clientIdResponse.json();
        
        script.src = `https://www.paypal.com/sdk/js?client-id=${clientId}&currency=USD&components=buttons,card-fields`;
        script.async = true;
        
        script.onload = () => {
          if ((window as any).paypal) {
            // Initialize PayPal Buttons
            (window as any).paypal.Buttons({
              createOrder: async () => {
                try {
                  const response = await fetch('/api/paypal/order', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      amount: '4.00',
                      currency: 'USD',
                      intent: 'CAPTURE'
                    })
                  });
                  
                  if (!response.ok) {
                    throw new Error(`Order creation failed: ${response.status}`);
                  }
                  
                  const order = await response.json();
                  console.log('PayPal order created:', order);
                  return order.id;
                } catch (error) {
                  console.error('PayPal create order error:', error);
                  toast({
                    title: "Payment Error",
                    description: "Failed to create payment order. Please try again.",
                    variant: "destructive",
                  });
                  throw error;
                }
              },
              onApprove: async (data: any) => {
                try {
                  console.log('PayPal onApprove (Buttons):', data);
                  const response = await fetch(`/api/paypal/order/${data.orderID}/capture`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                  });
                  
                  if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error(`Payment capture failed: ${response.status} - ${errorText}`);
                  }
                  
                  const orderData = await response.json();
                  console.log('PayPal capture success (Buttons):', orderData);
                  handlePayPalSuccess(data.orderID);
                } catch (error) {
                  console.error('PayPal onApprove error (Buttons):', error);
                  // Don't show error toast for successful payments that redirect
                  if (error instanceof Error && !error.message.includes('success') && !error.message.includes('redirect')) {
                    toast({
                      title: "Payment Error",
                      description: "Failed to process payment. Please try again.",
                      variant: "destructive",
                    });
                  }
                }
              },
              onError: (err: any) => {
                console.error('PayPal error (Buttons):', err);
                toast({
                  title: "Payment Error",
                  description: "PayPal payment failed. Please try again.",
                  variant: "destructive",
                });
              }
            }).render('#paypal-button-container');

            // Initialize Card Fields for credit card payments
            const cardFields = (window as any).paypal.CardFields({
              createOrder: async () => {
                try {
                  const response = await fetch('/api/paypal/order', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      amount: '4.00',
                      currency: 'USD',
                      intent: 'CAPTURE'
                    })
                  });
                  
                  if (!response.ok) {
                    throw new Error(`Order creation failed: ${response.status}`);
                  }
                  
                  const order = await response.json();
                  console.log('PayPal order created (CardFields):', order);
                  return order.id;
                } catch (error) {
                  console.error('PayPal create order error (CardFields):', error);
                  toast({
                    title: "Payment Error",
                    description: "Failed to create payment order. Please try again.",
                    variant: "destructive",
                  });
                  throw error;
                }
              },
              onApprove: async (data: any) => {
                try {
                  console.log('PayPal onApprove (CardFields):', data);
                  const response = await fetch(`/api/paypal/order/${data.orderID}/capture`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                  });
                  
                  if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error(`Payment capture failed: ${response.status} - ${errorText}`);
                  }
                  
                  const orderData = await response.json();
                  console.log('PayPal capture success (CardFields):', orderData);
                  handlePayPalSuccess(data.orderID);
                } catch (error) {
                  console.error('PayPal onApprove error (CardFields):', error);
                  // Don't show error toast for successful payments that redirect
                  if (error instanceof Error && !error.message.includes('success') && !error.message.includes('redirect')) {
                    toast({
                      title: "Payment Error",
                      description: "Failed to process payment. Please try again.",
                      variant: "destructive",
                    });
                  }
                }
              },
              onError: (err: any) => {
                console.error('Card payment error:', err);
                toast({
                  title: "Payment Error",
                  description: "Credit card payment failed. Please try again.",
                  variant: "destructive",
                });
              }
            });

            // Render card fields
            if (cardFields.isEligible()) {
              cardFields.NumberField().render('#card-number-field');
              cardFields.ExpiryField().render('#expiry-date-field');
              cardFields.CVVField().render('#cvv-field');
              cardFields.NameField().render('#card-name-field');

              // Add click handler for card payment button
              const cardButton = document.getElementById('card-payment-button');
              if (cardButton) {
                cardButton.addEventListener('click', () => {
                  cardFields.submit().catch((err: any) => {
                    console.error('Card submission error:', err);
                    toast({
                      title: "Payment Error",
                      description: "Credit card payment failed. Please check your card details.",
                      variant: "destructive",
                    });
                  });
                });
              }
            }

            setPaypalLoaded(true);
          }
        };

        script.onerror = () => {
          console.error('Failed to load PayPal SDK');
          toast({
            title: "Payment Error",
            description: "Failed to load payment system. Please refresh the page.",
            variant: "destructive",
          });
        };

        document.head.appendChild(script);
      } catch (error) {
        console.error('PayPal initialization error:', error);
        toast({
          title: "Payment Error",
          description: "Failed to initialize payment system.",
          variant: "destructive",
        });
      }
    };

    initializePayPal();

    return () => {
      // Cleanup script
      const existingScript = document.querySelector('script[src*="paypal.com/sdk"]');
      if (existingScript) {
        document.head.removeChild(existingScript);
      }
    };
  }, [user, paypalLoaded]);

  // Check if user is already Pro
  const isPro = (user as any)?.subscriptionPlan === 'pro';

  // Show sign-in prompt for unauthenticated users
  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <div className="bg-gradient-to-r from-purple-500 to-pink-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Crown className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              Sign In Required
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              Please sign in to your account to upgrade to Pro plan and unlock all premium features.
            </p>
            <div className="space-y-4">
              <Button 
                onClick={() => window.location.href = '/sign-in'}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-8 py-3"
              >
                Sign In to Upgrade
              </Button>
              <div>
                <p className="text-sm text-gray-500">
                  Don't have an account?{" "}
                  <a href="/register" className="text-purple-600 hover:text-purple-700 font-medium">
                    Create one here
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (upgradeComplete || isPro) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <div className="bg-gradient-to-r from-purple-500 to-pink-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Crown className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              {isPro ? "You're Already Pro!" : "Welcome to Pro!"}
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              {isPro 
                ? "You already have access to all Pro features. Enjoy unlimited services, company branding, and email reminders!"
                : "Your account has been successfully upgraded. You now have access to all Pro features!"
              }
            </p>
            <Button 
              onClick={() => window.location.href = '/profile'}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-8 py-3"
            >
              Go to Profile
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Meta 
        title="Upgrade to Pro - Calenday Premium Features"
        description="Upgrade to Calenday Pro for $4/month. Get unlimited appointments, custom branding, analytics, and priority support. Transform your business today."
        keywords="upgrade pro, premium features, subscription, unlimited appointments, custom branding, analytics"
      />
      <Navigation />
      
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex items-center justify-center mb-6">
              <Crown className="h-12 w-12 mr-3" />
              <h1 className="text-4xl md:text-5xl font-bold">
                Upgrade to Pro
              </h1>
            </div>
            <p className="text-xl mb-8 opacity-90">
              Unlock powerful features to grow your business and provide better service to your customers
            </p>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 inline-block">
              <div className="text-3xl font-bold mb-2">$4.00</div>
              <div className="text-lg opacity-90">per month</div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="flex-1 container mx-auto px-4 py-16">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Everything you need to succeed
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {proFeatures.map((feature, index) => (
              <Card key={index} className="border-2 border-gray-100 hover:border-purple-200 transition-colors">
                <CardContent className="p-6">
                  <div className="bg-gradient-to-r from-purple-500 to-pink-500 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                    <feature.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Payment Section */}
          <div className="max-w-md mx-auto">
            <Card className="border-2 border-purple-200">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl font-bold text-gray-900">
                  Complete Your Upgrade
                </CardTitle>
                <p className="text-gray-600">
                  Choose your preferred payment method
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex justify-between items-center text-lg font-semibold">
                    <span>Pro Plan (Monthly)</span>
                    <span>$4.00</span>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="space-y-3">
                    <div id="paypal-button-container" className="w-full min-h-[50px]"></div>
                    
                    
                    
                    
                  </div>
                  
                  {upgradeMutation.isPending && (
                    <div className="text-center text-gray-600">
                      Processing your upgrade...
                    </div>
                  )}
                </div>

                <div className="text-xs text-gray-500 text-center">
                  By upgrading, you agree to our terms of service. You can cancel anytime.
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-auto">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center">
            <p className="text-slate-600 text-sm">© 2025 Calenday. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}