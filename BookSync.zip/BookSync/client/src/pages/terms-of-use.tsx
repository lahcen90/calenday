import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import PublicHeader from "@/components/public-header";
import Meta from "@/components/meta";
import Calenday from "@assets/Clenday.png";

export default function TermsOfUse() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <Meta 
        title="Terms of Use - Calenday Service Agreement"
        description="Read Calenday's terms of use and service agreement. Understand your rights and responsibilities when using our appointment scheduling platform."
        keywords="terms of use, service agreement, user rights, responsibilities, legal terms"
      />
      <PublicHeader />
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">
            Terms of Use
          </h1>
          <p className="text-slate-600">
            Last updated: December 12, 2025
          </p>
        </div>

        {/* Terms Content */}
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-8 prose prose-lg max-w-none">
              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">1. Acceptance of Terms</h2>
                <p className="text-slate-700 mb-4">
                  By accessing and using Clenday ("the Service"), you accept and agree to be bound by the terms 
                  and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">2. Description of Service</h2>
                <p className="text-slate-700 mb-4">
                  Clenday is a web-based appointment scheduling platform that allows businesses to manage bookings, 
                  appointments, and customer communications. The service includes features such as:
                </p>
                <ul className="list-disc pl-6 text-slate-700 mb-4">
                  <li>Online appointment booking</li>
                  <li>Calendar management</li>
                  <li>Email notifications and reminders</li>
                  <li>Customer management tools</li>
                  <li>Integration with third-party services</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">3. User Accounts</h2>
                <p className="text-slate-700 mb-4">
                  To access certain features of the Service, you must register for an account. You agree to:
                </p>
                <ul className="list-disc pl-6 text-slate-700 mb-4">
                  <li>Provide accurate, current, and complete information during registration</li>
                  <li>Maintain and update your account information</li>
                  <li>Maintain the security of your password and account</li>
                  <li>Accept responsibility for all activities under your account</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">4. Acceptable Use</h2>
                <p className="text-slate-700 mb-4">
                  You agree not to use the Service for any unlawful purpose or in any way that could damage, 
                  disable, overburden, or impair the Service. Prohibited activities include:
                </p>
                <ul className="list-disc pl-6 text-slate-700 mb-4">
                  <li>Violating any applicable laws or regulations</li>
                  <li>Transmitting spam, viruses, or other harmful code</li>
                  <li>Attempting to gain unauthorized access to the Service</li>
                  <li>Interfering with other users' use of the Service</li>
                  <li>Using the Service for commercial purposes without authorization</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">5. Privacy and Data Protection</h2>
                <p className="text-slate-700 mb-4">
                  Your privacy is important to us. Our Privacy Policy explains how we collect, use, and protect 
                  your information when you use our Service. By using the Service, you agree to the collection 
                  and use of information in accordance with our Privacy Policy.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">6. Payment Terms</h2>
                <p className="text-slate-700 mb-4">
                  Certain features of the Service require payment. By subscribing to a paid plan:
                </p>
                <ul className="list-disc pl-6 text-slate-700 mb-4">
                  <li>You agree to pay all fees associated with your chosen plan</li>
                  <li>Payments are processed securely through third-party payment processors</li>
                  <li>Subscriptions automatically renew unless cancelled</li>
                  <li>Refunds are provided according to our refund policy</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">7. Intellectual Property</h2>
                <p className="text-slate-700 mb-4">
                  The Service and its original content, features, and functionality are owned by Clenday and are 
                  protected by international copyright, trademark, patent, trade secret, and other intellectual 
                  property laws.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">8. Termination</h2>
                <p className="text-slate-700 mb-4">
                  We may terminate or suspend your account and access to the Service immediately, without prior 
                  notice, if you breach these Terms. You may also terminate your account at any time by contacting 
                  us or using the account settings.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">9. Disclaimers and Limitation of Liability</h2>
                <p className="text-slate-700 mb-4">
                  The Service is provided "as is" without warranties of any kind. To the fullest extent permitted 
                  by law, we disclaim all warranties and shall not be liable for any damages arising from your use 
                  of the Service.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">10. Changes to Terms</h2>
                <p className="text-slate-700 mb-4">
                  We reserve the right to modify these terms at any time. We will notify users of significant 
                  changes via email or through the Service. Continued use of the Service after changes constitutes 
                  acceptance of the new terms.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-slate-900">11. Contact Information</h2>
                <p className="text-slate-700 mb-4">
                  If you have questions about these Terms, please contact us at:
                </p>
                <div className="bg-slate-50 p-4 rounded-lg">
                  <p className="text-slate-700">
                    Email: support@calenday.io
                  </p>
                </div>
              </section>
            </CardContent>
          </Card>
        </div>

        {/* Back to Home */}
        <div className="text-center mt-12">
          <Link href="/">
            <Button variant="ghost">
              ← Back to Home
            </Button>
          </Link>
        </div>
      </div>

      
    </div>
  );
}