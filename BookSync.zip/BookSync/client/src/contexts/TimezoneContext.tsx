import React, { createContext, useContext, useState, useEffect } from 'react';
import { formatInTimeZone } from 'date-fns-tz';

interface TimezoneContextType {
  timezone: string;
  setTimezone: (timezone: string) => void;
  formatDateInTimezone: (date: Date | string, format: string) => string;
  convertToTimezone: (date: Date | string) => Date;
}

const TimezoneContext = createContext<TimezoneContextType | undefined>(undefined);

interface TimezoneProviderProps {
  children: React.ReactNode;
  defaultTimezone?: string;
  locked?: boolean; // When true, prevents timezone changes
}

export function TimezoneProvider({ children, defaultTimezone, locked }: TimezoneProviderProps) {
  const [timezone, setTimezone] = useState<string>(() => {
    // When locked, use client's detected timezone instead of provider's default
    if (locked) {
      try {
        return Intl.DateTimeFormat().resolvedOptions().timeZone;
      } catch {
        return defaultTimezone || 'UTC';
      }
    }
    // Check localStorage first for user preference
    const savedTimezone = localStorage.getItem('user-timezone');
    if (savedTimezone) {
      return savedTimezone;
    }
    // Use provider's default timezone if provided
    if (defaultTimezone) {
      return defaultTimezone;
    }
    // Fall back to browser timezone
    try {
      return Intl.DateTimeFormat().resolvedOptions().timeZone;
    } catch {
      return 'UTC';
    }
  });

  // Update timezone when locked state changes
  useEffect(() => {
    if (locked) {
      // When locked, use client's detected timezone
      try {
        const detectedTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        setTimezone(detectedTimezone);
      } catch {
        setTimezone(defaultTimezone || 'UTC');
      }
    }
  }, [locked, defaultTimezone]);

  // Save timezone to localStorage when it changes (unless locked)
  useEffect(() => {
    if (!locked) {
      localStorage.setItem('user-timezone', timezone);
    }
  }, [timezone, locked]);

  const formatDateInTimezone = (date: Date | string, format: string): string => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return formatInTimeZone(dateObj, timezone, format);
  };

  const convertToTimezone = (date: Date | string): Date => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    // Create a new date that represents the same moment in the selected timezone
    const formatter = new Intl.DateTimeFormat('en', {
      timeZone: timezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    });
    
    const parts = formatter.formatToParts(dateObj);
    const year = parseInt(parts.find(p => p.type === 'year')?.value || '0');
    const month = parseInt(parts.find(p => p.type === 'month')?.value || '0') - 1;
    const day = parseInt(parts.find(p => p.type === 'day')?.value || '0');
    const hour = parseInt(parts.find(p => p.type === 'hour')?.value || '0');
    const minute = parseInt(parts.find(p => p.type === 'minute')?.value || '0');
    const second = parseInt(parts.find(p => p.type === 'second')?.value || '0');
    
    return new Date(year, month, day, hour, minute, second);
  };

  return (
    <TimezoneContext.Provider value={{
      timezone,
      setTimezone,
      formatDateInTimezone,
      convertToTimezone
    }}>
      {children}
    </TimezoneContext.Provider>
  );
}

export function useTimezone() {
  const context = useContext(TimezoneContext);
  if (context === undefined) {
    throw new Error('useTimezone must be used within a TimezoneProvider');
  }
  return context;
}