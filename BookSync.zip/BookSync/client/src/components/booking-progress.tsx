import { Check, Calendar, Clock, User, CheckCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface BookingStep {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
}

interface BookingProgressProps {
  currentStep: number;
  completedSteps: number[];
}

const steps: BookingStep[] = [
  {
    id: "service",
    title: "Select Service",
    description: "Choose your appointment type",
    icon: Calendar,
  },
  {
    id: "datetime",
    title: "Date & Time",
    description: "Pick your preferred slot",
    icon: Clock,
  },
  {
    id: "details",
    title: "Your Details",
    description: "Enter your information",
    icon: User,
  },
  {
    id: "confirmation",
    title: "Confirmed",
    description: "Booking complete",
    icon: CheckCircle,
  },
];

export default function BookingProgress({ currentStep, completedSteps }: BookingProgressProps) {
  return (
    <div className="w-full py-6">
      <div className="mb-4 text-center">
        <h3 className="text-lg font-semibold text-gray-800">Booking Progress</h3>
        <p className="text-sm text-gray-600">Step {currentStep} of {steps.length}</p>
      </div>
      <div className="flex items-center justify-between">
        {steps.map((step, index) => {
          const stepNumber = index + 1;
          const isCompleted = completedSteps.includes(stepNumber);
          const isCurrent = currentStep === stepNumber;
          const isUpcoming = stepNumber > currentStep;

          return (
            <div key={step.id} className="flex items-center flex-1">
              {/* Step Circle */}
              <div className="flex flex-col items-center">
                <div
                  className={cn(
                    "flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all duration-300 ease-in-out",
                    {
                      "bg-green-500 border-green-500 text-white shadow-lg scale-105": isCompleted,
                      "bg-blue-500 border-blue-500 text-white shadow-md animate-pulse": isCurrent,
                      "bg-gray-100 border-gray-300 text-gray-400": isUpcoming,
                    }
                  )}
                >
                  {isCompleted ? (
                    <Check className="w-5 h-5 animate-in fade-in duration-300" />
                  ) : (
                    <step.icon className={cn("w-5 h-5", { "animate-bounce": isCurrent })} />
                  )}
                </div>
                
                {/* Step Info */}
                <div className="mt-3 text-center">
                  <div
                    className={cn("text-sm font-medium", {
                      "text-green-600": isCompleted,
                      "text-blue-600": isCurrent,
                      "text-gray-400": isUpcoming,
                    })}
                  >
                    {step.title}
                  </div>
                  <div
                    className={cn("text-xs mt-1", {
                      "text-green-500": isCompleted,
                      "text-blue-500": isCurrent,
                      "text-gray-400": isUpcoming,
                    })}
                  >
                    {step.description}
                  </div>
                </div>
              </div>

              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="flex-1 mx-4 relative">
                  <div className="h-0.5 bg-gray-300 w-full"></div>
                  <div
                    className={cn(
                      "h-0.5 absolute top-0 left-0 transition-all duration-500 ease-in-out",
                      {
                        "bg-green-500 w-full": isCompleted && completedSteps.includes(stepNumber + 1),
                        "bg-blue-500 w-1/2 animate-pulse": isCompleted && currentStep === stepNumber + 1,
                        "bg-transparent w-0": !isCompleted || stepNumber + 1 > currentStep,
                      }
                    )}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}