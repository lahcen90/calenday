import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Globe, ChevronDown } from "lucide-react";
import { commonTimezones } from "@/lib/timezone";
import { useTimezone } from "@/contexts/TimezoneContext";

interface TimezoneSelectorProps {
  onTimezoneChange?: (timezone: string) => void;
}

export default function TimezoneSelector({ onTimezoneChange }: TimezoneSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { timezone, setTimezone } = useTimezone();

  const handleTimezoneChange = (newTimezone: string) => {
    setTimezone(newTimezone);
    setIsOpen(false);
    if (onTimezoneChange) {
      onTimezoneChange(newTimezone);
    }
  };

  const getCurrentTime = () => {
    const now = new Date();
    return now.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: false,
      timeZone: timezone
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="ghost" 
          className="flex items-center gap-2 px-3 py-2 text-primary hover:bg-primary/10 transition-colors"
        >
          <Globe className="h-4 w-4" />
          <div className="flex items-baseline gap-1">
            <span className="font-medium">{timezone}</span>
            <span className="text-sm text-muted-foreground">({getCurrentTime()})</span>
          </div>
          <ChevronDown className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Select Your Timezone</DialogTitle>
          <DialogDescription>
            Choose your preferred timezone for displaying appointment times.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Select value={timezone} onValueChange={handleTimezoneChange}>
              <SelectTrigger>
                <SelectValue placeholder="Select timezone" />
              </SelectTrigger>
              <SelectContent className="max-h-60">
                {commonTimezones.map((tz) => (
                  <SelectItem key={tz.value} value={tz.value}>
                    {tz.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="text-xs text-slate-500">
            <p>Note: Changing timezone affects new bookings. Existing bookings maintain their original timezone.</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}