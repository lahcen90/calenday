import { useState } from "react";
import { Bell, Clock, User, Mail, Check, X, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { formatInUserTimezone } from "@/lib/timezone";
import { cn } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";

interface NotificationReminder {
  appointmentId: number;
  customerName: string;
  customerEmail: string;
  appointmentDate: string;
  reminderTime: string;
  isOverdue: boolean;
  isRead: boolean;
}

export default function NotificationBell() {
  const [isOpen, setIsOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: reminders = [], isLoading } = useQuery<NotificationReminder[]>({
    queryKey: ["/api/notifications/reminders"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const markAsReadMutation = useMutation({
    mutationFn: async (appointmentId: number) => {
      const response = await fetch(`/api/notifications/${appointmentId}/read`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) throw new Error("Failed to mark as read");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/reminders"] });
    },
  });

  const deleteNotificationMutation = useMutation({
    mutationFn: async (appointmentId: number) => {
      const response = await fetch(`/api/notifications/${appointmentId}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) throw new Error("Failed to delete notification");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/reminders"] });
    },
  });

  const unreadCount = reminders.filter(r => !r.isRead).length;
  const overdueCount = reminders.filter(r => r.isOverdue && !r.isRead).length;
  const totalCount = reminders.length;

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="relative p-2 h-10 w-10"
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge
              variant={overdueCount > 0 ? "destructive" : "default"}
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
            >
              {unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      
      <PopoverContent className="w-80 p-0" align="end">
        <div className="p-4 border-b">
          <h3 className="font-semibold text-sm">Appointment Reminders</h3>
          {totalCount > 0 && (
            <p className="text-xs text-muted-foreground mt-1">
              {overdueCount > 0 
                ? `${overdueCount} overdue, ${unreadCount - overdueCount} upcoming`
                : `${unreadCount} unread reminders`
              }
            </p>
          )}
        </div>
        
        <div className="max-h-80 overflow-y-auto">
          {isLoading ? (
            <div className="p-4 text-center text-sm text-muted-foreground">
              Loading reminders...
            </div>
          ) : reminders.length === 0 ? (
            <div className="p-4 text-center text-sm text-muted-foreground">
              No upcoming reminders
            </div>
          ) : (
            <div className="divide-y">
              {reminders.map((reminder) => (
                <div
                  key={reminder.appointmentId}
                  className={cn(
                    "p-4 hover:bg-muted/50 transition-colors",
                    reminder.isOverdue && !reminder.isRead && "bg-red-50 border-l-4 border-l-red-500",
                    reminder.isRead && "opacity-60 bg-slate-50"
                  )}
                >
                  <div className="flex items-start space-x-3">
                    <div className={cn(
                      "flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center",
                      reminder.isOverdue && !reminder.isRead
                        ? "bg-red-100 text-red-600" 
                        : reminder.isRead
                        ? "bg-gray-100 text-gray-600"
                        : "bg-blue-100 text-blue-600"
                    )}>
                      <Clock className="h-4 w-4" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center space-x-2">
                          <User className="h-3 w-3 text-muted-foreground" />
                          <p className="text-sm font-medium truncate">
                            {reminder.customerName}
                            {reminder.isRead && (
                              <span className="ml-2 text-xs text-muted-foreground">(read)</span>
                            )}
                          </p>
                        </div>
                        
                        <div className="flex items-center space-x-1">
                          {!reminder.isRead && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0"
                              onClick={(e) => {
                                e.stopPropagation();
                                markAsReadMutation.mutate(reminder.appointmentId);
                              }}
                              disabled={markAsReadMutation.isPending}
                            >
                              <Eye className="h-3 w-3" />
                            </Button>
                          )}
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteNotificationMutation.mutate(reminder.appointmentId);
                            }}
                            disabled={deleteNotificationMutation.isPending}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2 mb-2">
                        <Mail className="h-3 w-3 text-muted-foreground" />
                        <p className="text-xs text-muted-foreground truncate">
                          {reminder.customerEmail}
                        </p>
                      </div>
                      
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">
                          <span className="font-medium">Appointment:</span>{" "}
                          {formatInUserTimezone(
                            new Date(reminder.appointmentDate),
                            "MMM d, yyyy 'at' h:mm a"
                          )}
                        </p>
                        
                        <p className={cn(
                          "text-xs font-medium",
                          reminder.isOverdue && !reminder.isRead
                            ? "text-red-600" 
                            : reminder.isRead
                            ? "text-gray-500"
                            : "text-blue-600"
                        )}>
                          {reminder.isOverdue 
                            ? "Reminder overdue"
                            : `Reminder due: ${formatInUserTimezone(
                                new Date(reminder.reminderTime),
                                "MMM d 'at' h:mm a"
                              )}`
                          }
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {totalCount > 0 && (
          <div className="p-3 border-t bg-muted/30">
            <p className="text-xs text-muted-foreground text-center">
              Reminders are sent automatically via email
            </p>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}