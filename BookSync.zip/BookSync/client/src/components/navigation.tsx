import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Calendar, LogOut, User, Menu } from "lucide-react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useState } from "react";
import NotificationBell from "./notification-bell";

import Clenday from "@assets/Clenday.png";

export default function Navigation() {
  const [location] = useLocation();
  const { user } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="bg-white shadow-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link href="/">
                <h1 className="text-lg sm:text-xl font-bold text-primary flex items-center cursor-pointer">
                  <img 
                    src={Clenday} 
                    alt="Calenday Logo" 
                    className="h-6 w-6 sm:h-8 sm:w-8 mr-2"
                  />
                  <span className="hidden xs:inline">Calenday</span>
                  <span className="xs:hidden">Calenday</span>
                  {user && (user as any).subscriptionPlan === 'pro' && (
                    <span className="ml-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                      PRO
                    </span>
                  )}
                </h1>
              </Link>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-4">
            <Link href="/">
              <Button 
                variant={location === "/" || location === "/provider" ? "default" : "ghost"}
                size="sm"
              >
                Dashboard
              </Button>
            </Link>
            
            <Link href="/appointments">
              <Button 
                variant={location === "/appointments" ? "default" : "ghost"}
                size="sm"
              >
                Manage Appointments
              </Button>
            </Link>
            <Link href="/services">
              <Button 
                variant={location === "/services" ? "default" : "ghost"}
                size="sm"
              >
                Manage Services
              </Button>
            </Link>
            <Link href="/profile">
              <Button 
                variant={location === "/profile" ? "default" : "ghost"}
                size="sm"
              >
                Profile
              </Button>
            </Link>
            
            <Link href="/contact-us">
              <Button 
                variant={location === "/contact-us" ? "default" : "ghost"}
                size="sm"
              >Contact us</Button>
            </Link>
            
            {/* Pro Upgrade Button for Free Plan Users */}
            {user && (user as any).subscriptionPlan !== 'pro' && (
              <Link href="/upgrade">
                <Button 
                  variant="outline"
                  size="sm"
                  className="text-[#9433EA] border-[#9433EA] hover:bg-[#9433EA] hover:text-white"
                >Calenday Pro</Button>
              </Link>
            )}
          </div>
          {/* User Menu & Mobile Toggle */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            {user && (
              <>
                {/* Notification Bell */}
                <NotificationBell />
                
                {/* Desktop User Menu */}
                <div className="hidden sm:flex items-center space-x-3">
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-slate-500" />
                    <span className="text-sm text-slate-700">
                      {(user as any).firstName || ''} {(user as any).lastName || ''}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={async () => {
                      try {
                        await fetch('/api/auth/logout', { method: 'POST' });
                        window.location.href = '/';
                      } catch (error) {
                        console.error('Logout failed:', error);
                      }
                    }}
                    className="text-slate-600 hover:text-slate-900"
                  >
                    <LogOut className="h-4 w-4 mr-1" />
                    Logout
                  </Button>
                </div>
                
                {/* Mobile Menu Toggle */}
                <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                  <SheetTrigger asChild>
                    <Button variant="ghost" size="sm" className="md:hidden">
                      <Menu className="h-5 w-5" />
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="right" className="w-80">
                    <div className="flex flex-col space-y-4 mt-8">
                      {/* Mobile User Info */}
                      <div className="flex items-center justify-between p-4 border-b">
                        <div className="flex items-center space-x-3">
                          <User className="h-8 w-8 text-slate-500" />
                          <div>
                            <p className="font-medium text-slate-900">
                              {(user as any).firstName || ''} {(user as any).lastName || ''}
                            </p>
                            <p className="text-sm text-slate-500">{(user as any).email}</p>
                          </div>
                        </div>
                        {/* Mobile Notification Bell */}
                        <NotificationBell />
                      </div>
                      
                      {/* Mobile Navigation Links */}
                      <div className="flex flex-col space-y-2 px-4">
                        <Link href="/">
                          <Button 
                            variant={location === "/" || location === "/provider" ? "default" : "ghost"}
                            className="w-full justify-start"
                            onClick={() => setMobileMenuOpen(false)}
                          >
                            Dashboard
                          </Button>
                        </Link>
                        
                        <Link href="/appointments">
                          <Button 
                            variant={location === "/appointments" ? "default" : "ghost"}
                            className="w-full justify-start"
                            onClick={() => setMobileMenuOpen(false)}
                          >
                            Manage Appointments
                          </Button>
                        </Link>
                        <Link href="/services">
                          <Button 
                            variant={location === "/services" ? "default" : "ghost"}
                            className="w-full justify-start"
                            onClick={() => setMobileMenuOpen(false)}
                          >
                            Manage Services
                          </Button>
                        </Link>
                        <Link href="/profile">
                          <Button 
                            variant={location === "/profile" ? "default" : "ghost"}
                            className="w-full justify-start"
                            onClick={() => setMobileMenuOpen(false)}
                          >
                            Profile
                          </Button>
                        </Link>
                        
                        <Link href="/contact-us">
                          <Button 
                            variant={location === "/contact-us" ? "default" : "ghost"}
                            className="w-full justify-start"
                            onClick={() => setMobileMenuOpen(false)}
                          >
                            Contact Us
                          </Button>
                        </Link>
                        
                        {/* Mobile Pro Upgrade Button for Free Plan Users */}
                        {(user as any).subscriptionPlan !== 'pro' && (
                          <Link href="/upgrade">
                            <Button 
                              variant="outline"
                              className="w-full justify-start text-[#9433EA] border-[#9433EA] hover:bg-[#9433EA] hover:text-white"
                              onClick={() => setMobileMenuOpen(false)}
                            >
                              Upgrade to Pro
                            </Button>
                          </Link>
                        )}
                      </div>
                      
                      {/* Mobile Logout */}
                      <div className="px-4 pt-4 border-t">
                        <Button
                          variant="outline"
                          className="w-full justify-start"
                          onClick={async () => {
                            try {
                              await fetch('/api/auth/logout', { method: 'POST' });
                              window.location.href = '/';
                            } catch (error) {
                              console.error('Logout failed:', error);
                            }
                          }}
                        >
                          <LogOut className="h-4 w-4 mr-2" />
                          Logout
                        </Button>
                      </div>
                    </div>
                  </SheetContent>
                </Sheet>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
