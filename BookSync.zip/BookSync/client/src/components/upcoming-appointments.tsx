import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { List, Check, Edit, X, Clock } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format, startOfDay, addDays } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatInUserTimezone, getTimezoneDisplay } from "@/lib/timezone";
import type { Appointment, Service } from "@shared/schema";

export default function UpcomingAppointments() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const today = startOfDay(new Date());
  const tomorrow = addDays(today, 1);

  const { data: appointments } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments", format(today, 'yyyy-MM-dd'), format(tomorrow, 'yyyy-MM-dd')],
    queryFn: async () => {
      const response = await fetch(
        `/api/appointments?startDate=${format(today, 'yyyy-MM-dd')}&endDate=${format(tomorrow, 'yyyy-MM-dd')}`
      );
      return response.json();
    },
  });

  const { data: services } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const serviceMap = new Map(services?.map(s => [s.id, s]) || []);

  const updateAppointmentMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      return await apiRequest("PATCH", `/api/appointments/${id}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Appointment status updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update appointment status.",
        variant: "destructive",
      });
    },
  });

  const deleteAppointmentMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/appointments/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Appointment deleted successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete appointment.",
        variant: "destructive",
      });
    },
  });

  const todayAppointments = appointments?.filter(appointment => {
    const appointmentDate = new Date(appointment.appointmentDate);
    return appointmentDate >= today && appointmentDate < tomorrow && appointment.status !== "cancelled";
  }).sort((a, b) => {
    // Sort by newest to oldest (descending order)
    return new Date(b.appointmentDate).getTime() - new Date(a.appointmentDate).getTime();
  }) || [];

  const formatTime = (date: string | Date) => {
    const appointmentDate = typeof date === 'string' ? new Date(date) : date;
    return formatInUserTimezone(appointmentDate, 'h:mm a');
  };

  const getEndTime = (startDate: string | Date, serviceId: number) => {
    const service = serviceMap.get(serviceId);
    if (!service) return '';
    
    const start = typeof startDate === 'string' ? new Date(startDate) : startDate;
    const end = new Date(start.getTime() + service.duration * 60 * 1000);
    return formatInUserTimezone(end, 'h:mm a');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-amber-100 text-amber-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <List className="h-5 w-5 text-primary mr-2" />
          Today's Appointments
        </CardTitle>
      </CardHeader>
      <CardContent>
        {todayAppointments.length === 0 ? (
          <p className="text-slate-500 text-center py-4">
            No appointments scheduled for today.
          </p>
        ) : (
          <div className="space-y-4">
            {todayAppointments.map((appointment) => {
              const service = serviceMap.get(appointment.serviceId);
              
              return (
                <div key={appointment.id} className="border border-slate-200 rounded-lg p-3">
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex-1">
                      <div className="font-medium text-slate-900">{appointment.clientName}</div>
                      <div className="text-sm text-slate-500">{appointment.clientEmail}</div>
                      <div className="text-sm text-slate-500">{service?.name || 'Unknown Service'}</div>
                      <div className="text-sm text-slate-500">
                        {formatTime(appointment.appointmentDate)} - {getEndTime(appointment.appointmentDate, appointment.serviceId)}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={getStatusColor(appointment.status)}>
                        {appointment.status}
                      </Badge>
                    </div>
                  </div>
                  
                  {appointment.notes && (
                    <div className="text-sm text-slate-600 mb-2">
                      <strong>Notes:</strong> {appointment.notes}
                    </div>
                  )}
                  
                  
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
