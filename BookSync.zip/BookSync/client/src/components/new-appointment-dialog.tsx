import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, User } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useTimezone } from "@/contexts/TimezoneContext";
import { format } from "date-fns";
import type { Service } from "@shared/schema";

interface NewAppointmentDialogProps {
  children: React.ReactNode;
}

export default function NewAppointmentDialog({ children }: NewAppointmentDialogProps) {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    serviceId: "",
    firstName: "",
    lastName: "",
    clientEmail: "",
    clientPhone: "",
    notes: "",
    appointmentDate: "",
    appointmentTime: "",
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { timezone } = useTimezone();

  const { data: services = [] } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  const createAppointmentMutation = useMutation({
    mutationFn: async (data: any) => {
      if (!data.serviceId || !data.firstName || !data.lastName || !data.clientEmail || !data.clientPhone || !data.appointmentDate || !data.appointmentTime) {
        throw new Error("Please fill in all required fields");
      }

      const appointmentDateTime = new Date(`${data.appointmentDate}T${data.appointmentTime}`);
      
      // Get service details to extract duration and price
      const selectedService = services?.find(s => s.id === parseInt(data.serviceId));
      if (!selectedService) {
        throw new Error("Selected service not found");
      }

      const appointmentData = {
        serviceId: parseInt(data.serviceId),
        clientName: `${data.firstName} ${data.lastName}`,
        clientEmail: data.clientEmail,
        clientPhone: data.clientPhone,
        notes: data.notes || "",
        appointmentDate: appointmentDateTime.toISOString(),
        duration: selectedService.duration,
        price: 0, // Default price for now
        timezone: timezone,
        status: "confirmed",
        providerId: (user as any)?.id, // Add current user as provider
      };

      const response = await fetch("/api/appointments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(appointmentData),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "Failed to create appointment");
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Appointment Created",
        description: "The appointment has been successfully created.",
      });
      setFormData({
        serviceId: "",
        firstName: "",
        lastName: "",
        clientEmail: "",
        clientPhone: "",
        notes: "",
        appointmentDate: "",
        appointmentTime: "",
      });
      setOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create appointment",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createAppointmentMutation.mutate(formData);
  };

  const generateTimeSlots = () => {
    const slots = [];
    for (let hour = 9; hour <= 17; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const timeString = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
        const displayTime = new Date(`1970-01-01T${timeString}`).toLocaleTimeString('en-US', {
          hour: 'numeric',
          minute: '2-digit',
          hour12: true
        });
        slots.push({ value: timeString, label: displayTime });
      }
    }
    return slots;
  };

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Calendar className="h-5 w-5 text-primary mr-2" />
            Create New Appointment
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Service Selection */}
          <div className="space-y-2">
            <Label htmlFor="service">Service *</Label>
            <Select value={formData.serviceId} onValueChange={(value) => updateFormData("serviceId", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select a service" />
              </SelectTrigger>
              <SelectContent>
                {services.map((service) => (
                  <SelectItem key={service.id} value={service.id.toString()}>
                    {service.name} ({service.duration} min)
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Timezone Display */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-900">
                Timezone: {timezone}
              </span>
            </div>
            <p className="text-xs text-blue-700 mt-1">
              All appointment times will be scheduled in this timezone
            </p>
          </div>

          {/* Date and Time */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Date *</Label>
              <Input 
                id="date"
                type="date" 
                value={formData.appointmentDate}
                onChange={(e) => updateFormData("appointmentDate", e.target.value)}
                min={format(new Date(), 'yyyy-MM-dd')}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="time">Time * ({timezone})</Label>
              <Select value={formData.appointmentTime} onValueChange={(value) => updateFormData("appointmentTime", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select time" />
                </SelectTrigger>
                <SelectContent>
                  {generateTimeSlots().map((slot) => (
                    <SelectItem key={slot.value} value={slot.value}>
                      {slot.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Client Information */}
          <div className="space-y-4">
            <div className="flex items-center mb-2">
              <User className="h-4 w-4 text-primary mr-2" />
              <span className="font-medium">Client Information</span>
            </div>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name *</Label>
                <Input 
                  id="firstName"
                  placeholder="John" 
                  value={formData.firstName}
                  onChange={(e) => updateFormData("firstName", e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name *</Label>
                <Input 
                  id="lastName"
                  placeholder="Doe" 
                  value={formData.lastName}
                  onChange={(e) => updateFormData("lastName", e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input 
                  id="email"
                  type="email" 
                  placeholder="john@example.com" 
                  value={formData.clientEmail}
                  onChange={(e) => updateFormData("clientEmail", e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number *</Label>
                <Input 
                  id="phone"
                  placeholder="+1 (555) 123-4567" 
                  value={formData.clientPhone}
                  onChange={(e) => updateFormData("clientPhone", e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                placeholder="Additional notes or special requirements..."
                rows={3}
                value={formData.notes}
                onChange={(e) => updateFormData("notes", e.target.value)}
              />
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={createAppointmentMutation.isPending}
              className="flex-1"
            >
              {createAppointmentMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Creating...
                </>
              ) : (
                <>
                  <Calendar className="h-4 w-4 mr-2" />
                  Create Appointment
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}