import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Clock, Plus, Trash2, Calendar as CalendarIcon, AlertCircle, CheckCircle } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { format, addDays, isSameDay, isAfter, startOfDay } from "date-fns";

interface AvailabilityManagerProps {
  children: React.ReactNode;
}

const DAYS_OF_WEEK = [
  { value: 0, label: "Sunday" },
  { value: 1, label: "Monday" },
  { value: 2, label: "Tuesday" },
  { value: 3, label: "Wednesday" },
  { value: 4, label: "Thursday" },
  { value: 5, label: "Friday" },
  { value: 6, label: "Saturday" },
];

const TIME_SLOTS = Array.from({ length: 48 }, (_, i) => {
  const hour = Math.floor(i / 2).toString().padStart(2, '0');
  const minute = (i % 2) * 30;
  const minuteStr = minute.toString().padStart(2, '0');
  return `${hour}:${minuteStr}`;
});

export default function AvailabilityManager({ children }: AvailabilityManagerProps) {
  const [open, setOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [newBlockStart, setNewBlockStart] = useState("");
  const [newBlockEnd, setNewBlockEnd] = useState("");
  const [blockReason, setBlockReason] = useState("Blocked by provider");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const formatTimeString = (time: string) => {
    if (!time) return time;
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const { data: availability = [] } = useQuery<any[]>({
    queryKey: ["/api/availability"],
  });

  const { data: blockedTimes = [] } = useQuery<any[]>({
    queryKey: ["/api/blocked-times"],
  });

  const createAvailabilityMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/availability", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error(await response.text());
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/availability"] });
      toast({
        title: "Success",
        description: "Availability updated successfully!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update availability",
        variant: "destructive",
      });
    },
  });

  const createBlockedTimeMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/blocked-times", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error(await response.text());
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blocked-times"] });
      setNewBlockStart("");
      setNewBlockEnd("");
      setBlockReason("Blocked by provider");
      toast({
        title: "Success",
        description: "Time slot blocked successfully!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to block time slot",
        variant: "destructive",
      });
    },
  });

  const updateAvailabilityMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: number; [key: string]: any }) => {
      const response = await fetch(`/api/availability/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error(await response.text());
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/availability"] });
      toast({
        title: "Success",
        description: "Schedule updated successfully!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update schedule",
        variant: "destructive",
      });
    },
  });

  const deleteAvailabilityMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/availability/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        throw new Error(await response.text());
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/availability"] });
      toast({
        title: "Success",
        description: "Day availability removed!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to remove availability",
        variant: "destructive",
      });
    },
  });

  const deleteBlockedTimeMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/blocked-times/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        throw new Error(await response.text());
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blocked-times"] });
      toast({
        title: "Success",
        description: "Blocked time slot removed!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to remove blocked time",
        variant: "destructive",
      });
    },
  });

  const handleAvailabilityToggle = (dayOfWeek: number, enabled: boolean) => {
    if (enabled) {
      createAvailabilityMutation.mutate({
        dayOfWeek,
        startTime: "09:00",
        endTime: "17:00",
        isAvailable: true,
      });
    } else {
      // Delete existing availability for this day
      const existingAvailability = availability.find((a: any) => a.dayOfWeek === dayOfWeek);
      if (existingAvailability) {
        deleteAvailabilityMutation.mutate(existingAvailability.id);
      }
    }
  };

  const handleTimeChange = (dayOfWeek: number, timeType: 'startTime' | 'endTime', value: string) => {
    const existingAvailability = availability.find((a: any) => a.dayOfWeek === dayOfWeek);
    if (existingAvailability) {
      updateAvailabilityMutation.mutate({
        id: existingAvailability.id,
        [timeType]: value,
      });
    }
  };

  const handleBlockTime = () => {
    if (!newBlockStart || !newBlockEnd) {
      toast({
        title: "Invalid Input",
        description: "Please select both start and end times",
        variant: "destructive",
      });
      return;
    }

    if (newBlockStart >= newBlockEnd) {
      toast({
        title: "Invalid Time Range",
        description: "End time must be after start time",
        variant: "destructive",
      });
      return;
    }

    // Check if date is in the past
    if (startOfDay(selectedDate) < startOfDay(new Date())) {
      toast({
        title: "Invalid Date",
        description: "Cannot block time slots in the past",
        variant: "destructive",
      });
      return;
    }

    // Check for overlapping blocked times
    const existingBlocks = getBlockedTimesForDate(selectedDate);
    const hasOverlap = existingBlocks.some((block: any) => {
      return (newBlockStart < block.endTime && newBlockEnd > block.startTime);
    });

    if (hasOverlap) {
      toast({
        title: "Time Conflict",
        description: "This time range overlaps with an existing blocked time",
        variant: "destructive",
      });
      return;
    }

    createBlockedTimeMutation.mutate({
      date: format(selectedDate, "yyyy-MM-dd"),
      startTime: newBlockStart,
      endTime: newBlockEnd,
      reason: blockReason.trim() || "Blocked by provider",
    });
  };

  const getBlockedTimesForDate = (date: Date) => {
    const dateStr = format(date, "yyyy-MM-dd");
    return (blockedTimes as any[]).filter((block: any) => 
      format(new Date(block.date), "yyyy-MM-dd") === dateStr
    );
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Clock className="h-5 w-5 mr-2" />
            Manage Availability
          </DialogTitle>
          <DialogDescription>
            Set your working hours and block specific time slots when you're unavailable.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="schedule" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="schedule">Weekly Schedule</TabsTrigger>
            <TabsTrigger value="blocked">Blocked Times</TabsTrigger>
          </TabsList>

          <TabsContent value="schedule" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Working Hours</CardTitle>
                <CardDescription>
                  Set your regular working hours for each day of the week
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {DAYS_OF_WEEK.map((day) => {
                  const dayAvailability = availability.find((a: any) => a.dayOfWeek === day.value);
                  const isEnabled = dayAvailability?.isAvailable || false;

                  return (
                    <div key={day.value} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Switch
                          checked={isEnabled}
                          onCheckedChange={(checked) => handleAvailabilityToggle(day.value, checked)}
                        />
                        <Label className="font-medium">{day.label}</Label>
                      </div>
                      
                      {isEnabled && (
                        <div className="flex items-center space-x-2">
                          <Select 
                            defaultValue={dayAvailability?.startTime || "09:00"}
                            onValueChange={(value) => handleTimeChange(day.value, 'startTime', value)}
                          >
                            <SelectTrigger className="w-24">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {TIME_SLOTS.map((time) => (
                                <SelectItem key={time} value={time}>
                                  {time}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <span className="text-sm text-gray-500">to</span>
                          <Select 
                            defaultValue={dayAvailability?.endTime || "17:00"}
                            onValueChange={(value) => handleTimeChange(day.value, 'endTime', value)}
                          >
                            <SelectTrigger className="w-24">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {TIME_SLOTS.map((time) => (
                                <SelectItem key={time} value={time}>
                                  {time}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="blocked" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    Block Time Slots
                  </CardTitle>
                  <CardDescription>
                    Block specific dates and times when you're unavailable
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Select Date</Label>
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={(date) => date && setSelectedDate(date)}
                      disabled={(date) => date < new Date()}
                      className="rounded-md border"
                    />
                  </div>

                  <div className="space-y-3">
                    {/* Quick preset buttons */}
                    <div>
                      <Label className="text-sm">Quick Presets</Label>
                      <div className="grid grid-cols-2 gap-2 mt-1">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setNewBlockStart("12:00");
                            setNewBlockEnd("13:00");
                            setBlockReason("Lunch break");
                          }}
                          className="text-xs"
                        >
                          Lunch (12-1pm)
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setNewBlockStart("09:00");
                            setNewBlockEnd("17:00");
                            setBlockReason("Full day unavailable");
                          }}
                          className="text-xs"
                        >
                          Full Day
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>Start Time</Label>
                        <Select value={newBlockStart} onValueChange={setNewBlockStart}>
                          <SelectTrigger>
                            <SelectValue placeholder="Start" />
                          </SelectTrigger>
                          <SelectContent className="max-h-40 overflow-y-auto">
                            {TIME_SLOTS.map((time) => (
                              <SelectItem key={time} value={time}>
                                {time}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>End Time</Label>
                        <Select value={newBlockEnd} onValueChange={setNewBlockEnd}>
                          <SelectTrigger>
                            <SelectValue placeholder="End" />
                          </SelectTrigger>
                          <SelectContent className="max-h-40 overflow-y-auto">
                            {TIME_SLOTS.map((time) => (
                              <SelectItem key={time} value={time}>
                                {time}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label>Reason (optional)</Label>
                      <Textarea
                        value={blockReason}
                        onChange={(e) => setBlockReason(e.target.value)}
                        placeholder="Enter reason for blocking this time..."
                        className="resize-none"
                        rows={2}
                      />
                    </div>

                    {/* Time validation indicator */}
                    {newBlockStart && newBlockEnd && (
                      <div className="flex items-center space-x-2">
                        {newBlockStart >= newBlockEnd ? (
                          <div className="flex items-center text-red-600 text-sm">
                            <AlertCircle className="h-4 w-4 mr-1" />
                            End time must be after start time
                          </div>
                        ) : (
                          <div className="flex items-center text-green-600 text-sm">
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Duration: {((TIME_SLOTS.indexOf(newBlockEnd) - TIME_SLOTS.indexOf(newBlockStart)) * 30 / 60).toFixed(1)} hours
                          </div>
                        )}
                      </div>
                    )}

                    <Button 
                      onClick={handleBlockTime}
                      disabled={createBlockedTimeMutation.isPending || !newBlockStart || !newBlockEnd || newBlockStart >= newBlockEnd}
                      className="w-full"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      {createBlockedTimeMutation.isPending ? "Blocking..." : "Block Time Slot"}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Blocked Times</CardTitle>
                  <CardDescription>
                    Currently blocked time slots for {format(selectedDate, "MMMM d, yyyy")}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {getBlockedTimesForDate(selectedDate).length === 0 ? (
                      <div className="text-center py-6">
                        <Clock className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                        <p className="text-sm text-gray-500">No blocked times for this date</p>
                        <p className="text-xs text-gray-400">Select a date and time range to block availability</p>
                      </div>
                    ) : (
                      getBlockedTimesForDate(selectedDate).map((block: any) => {
                        const duration = ((TIME_SLOTS.indexOf(block.endTime) - TIME_SLOTS.indexOf(block.startTime)) * 30 / 60).toFixed(1);
                        return (
                          <div key={block.id} className="flex items-start justify-between p-3 border rounded-lg bg-red-50 border-red-200">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <Badge variant="destructive" className="text-xs">
                                  {block.startTime} - {block.endTime}
                                </Badge>
                                <span className="text-xs text-gray-500">
                                  ({duration}h)
                                </span>
                              </div>
                              {block.reason && (
                                <p className="text-sm text-gray-600">{block.reason}</p>
                              )}
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteBlockedTimeMutation.mutate(block.id)}
                              disabled={deleteBlockedTimeMutation.isPending}
                              className="text-red-600 hover:text-red-800 hover:bg-red-100"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        );
                      })
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}