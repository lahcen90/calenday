import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import Clenday from "@assets/Clenday.png";

export default function PublicHeader() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <nav className="bg-white shadow-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/">
              <div className="flex items-center cursor-pointer">
                <img 
                  src={Clenday} 
                  alt="Clenday Logo" 
                  className="h-8 w-8 mr-2"
                />
                <h1 className="text-xl font-bold text-primary">Calenday</h1>
              </div>
            </Link>
          </div>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center space-x-6">
            <Link href="/pricing" className="text-slate-600 hover:text-[#9433EA] transition-colors">
              Pricing
            </Link>
            <Link href="/about-us" className="text-slate-600 hover:text-[#9433EA] transition-colors">
              About Us
            </Link>
            <Link href="/help-center" className="text-slate-600 hover:text-[#9433EA] transition-colors">
              Help
            </Link>
            <Link href="/contact-us" className="text-slate-600 hover:text-[#9433EA] transition-colors">
              Contact
            </Link>
          </div>

          {/* Auth Buttons */}
          <div className="flex items-center space-x-3">
            {!isLoading && (
              <>
                {isAuthenticated ? (
                  <Link href="/dashboard">
                    <Button className="bg-[#3C83F6] hover:bg-[#2563eb]">
                      Dashboard
                    </Button>
                  </Link>
                ) : (
                  <>
                    <Link href="/sign-in">
                      <Button variant="outline" className="border-[#3C83F6] text-[#3C83F6] hover:bg-[#3C83F6] hover:text-white">
                        Sign In
                      </Button>
                    </Link>
                    <Link href="/register">
                      <Button className="bg-[#3C83F6] hover:bg-[#2563eb]">Register</Button>
                    </Link>
                  </>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}