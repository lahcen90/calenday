import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Calendar as CalendarIcon, ChevronDown, ChevronRight, Clock, User, Mail, Phone, MapPin, DollarSign, FileText } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import React, { useState, useEffect } from "react";
import { format, startOfWeek, addDays, addWeeks, subWeeks } from "date-fns";
import { formatAppointmentTime } from "@/lib/timezone";
import type { Appointment, Service } from "@shared/schema";
import TimezoneSelector from "@/components/timezone-selector";

export default function ProviderCalendar() {
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [expandedAppointments, setExpandedAppointments] = useState<Set<number>>(new Set());
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  
  const queryClient = useQueryClient();

  const weekStart = startOfWeek(currentWeek, { weekStartsOn: 1 }); // Start on Monday
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  const { data: appointments } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments", format(weekStart, 'yyyy-MM-dd'), format(addDays(weekStart, 6), 'yyyy-MM-dd')],
    queryFn: async () => {
      const response = await fetch(
        `/api/appointments?startDate=${format(weekStart, 'yyyy-MM-dd')}&endDate=${format(addDays(weekStart, 6), 'yyyy-MM-dd')}`
      );
      return response.json();
    },
  });

  const { data: services } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const serviceMap = new Map(services?.map(s => [s.id, s]) || []);

  // Update selected appointment when appointments data changes
  useEffect(() => {
    if (selectedAppointment && appointments) {
      const updatedAppointment = appointments.find(apt => apt.id === selectedAppointment.id);
      if (updatedAppointment) {
        setSelectedAppointment(updatedAppointment);
      }
    }
  }, [appointments, selectedAppointment?.id]);

  // Mutation for confirming appointments
  const confirmAppointmentMutation = useMutation({
    mutationFn: async (appointmentId: number) => {
      return await apiRequest(`/api/appointments/${appointmentId}`, "PATCH", { status: "confirmed" });
    },
    onSuccess: () => {
      toast({
        title: "Booking Confirmed",
        description: "The appointment has been confirmed successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      setSelectedAppointment(null);
    },
    onError: (error: Error) => {
      // Check if this is a blocked time error
      const errorMessage = error.message;
      if (errorMessage.includes("blocked time") || errorMessage.includes("not available")) {
        toast({
          title: "Cannot Confirm Appointment",
          description: errorMessage,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Confirmation Failed",
          description: errorMessage || "Failed to confirm the appointment.",
          variant: "destructive",
        });
      }
    },
  });

  const handleConfirmBooking = () => {
    if (selectedAppointment) {
      confirmAppointmentMutation.mutate(selectedAppointment.id);
    }
  };

  const goToPreviousWeek = () => {
    setCurrentWeek(subWeeks(currentWeek, 1));
  };

  const goToNextWeek = () => {
    setCurrentWeek(addWeeks(currentWeek, 1));
  };

  const goToToday = () => {
    setCurrentWeek(new Date());
  };

  const toggleAppointmentExpansion = (appointmentId: number) => {
    const newExpanded = new Set(expandedAppointments);
    if (newExpanded.has(appointmentId)) {
      newExpanded.delete(appointmentId);
    } else {
      newExpanded.add(appointmentId);
    }
    setExpandedAppointments(newExpanded);
  };

  const getAppointmentForTimeSlot = (day: Date, hour: number) => {
    if (!appointments) return null;
    
    return appointments.find(apt => {
      const aptDate = new Date(apt.appointmentDate);
      return format(aptDate, 'yyyy-MM-dd') === format(day, 'yyyy-MM-dd') &&
             aptDate.getHours() === hour;
    });
  };

  const getAppointmentsForDay = (day: Date) => {
    if (!appointments) return [];
    
    return appointments
      .filter(apt => {
        const aptDate = new Date(apt.appointmentDate);
        return format(aptDate, 'yyyy-MM-dd') === format(day, 'yyyy-MM-dd');
      })
      .sort((a, b) => new Date(a.appointmentDate).getTime() - new Date(b.appointmentDate).getTime());
  };

  const getAppointmentColor = (appointment: Appointment) => {
    if (appointment.status === 'confirmed') {
      return 'border-green-500 bg-green-100 text-green-800';
    } else if (appointment.status === 'pending') {
      return 'border-amber-500 bg-amber-100 text-amber-800';
    } else if (appointment.status === 'cancelled') {
      return 'border-red-500 bg-red-100 text-red-800';
    }
    return 'border-slate-400 bg-slate-100 text-slate-800';
  };

  return (
    <>
      <Card className="bg-white shadow-sm">
        <CardHeader>
          <div className="flex flex-col space-y-4 sm:space-y-0 sm:flex-row sm:justify-between sm:items-center">
            <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-3">
              <CardTitle className="flex items-center text-lg sm:text-xl">
                <CalendarIcon className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
                Calendar Overview
              </CardTitle>
            </div>
            
            {/* Desktop Controls */}
            <div className="hidden lg:flex items-center space-x-4">
              {/* Status Legend */}
              <div className="flex items-center space-x-3 text-xs">
                <div className="flex items-center space-x-1">
                  <div className="w-3 h-3 rounded border-2 border-green-500 bg-green-100"></div>
                  <span>Confirmed</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="w-3 h-3 rounded border-2 border-amber-500 bg-amber-100"></div>
                  <span>Pending</span>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={goToPreviousWeek}>
                  Previous
                </Button>
                <Button variant="outline" size="sm" onClick={goToToday}>
                  Today
                </Button>
                <Button variant="outline" size="sm" onClick={goToNextWeek}>
                  Next
                </Button>
              </div>
            </div>
          </div>
          
          {/* Mobile/Tablet Controls */}
          <div className="lg:hidden space-y-3">
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-3 sm:space-y-0">
              <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-3">
                <p className="text-sm text-slate-600">
                  Week of {format(weekStart, 'MMM d')} - {format(addDays(weekStart, 6), 'MMM d, yyyy')}
                </p>
                <TimezoneSelector />
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={goToPreviousWeek} className="text-xs">
                  Previous
                </Button>
                <Button variant="outline" size="sm" onClick={goToToday} className="text-xs">
                  Today
                </Button>
                <Button variant="outline" size="sm" onClick={goToNextWeek} className="text-xs">
                  Next
                </Button>
              </div>
            </div>
            
            {/* Mobile Status Legend */}
            <div className="flex items-center space-x-4 text-xs p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 rounded border-2 border-green-500 bg-green-100"></div>
                <span>Confirmed</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 rounded border-2 border-amber-500 bg-amber-100"></div>
                <span>Pending</span>
              </div>
            </div>
          </div>
          
          {/* Desktop Week Display */}
          <div className="hidden lg:block">
            <div className="flex items-center space-x-3">
              <p className="text-sm text-slate-600">
                Week of {format(weekStart, 'MMM d')} - {format(addDays(weekStart, 6), 'MMM d, yyyy')}
              </p>
              <TimezoneSelector />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <div className="grid grid-cols-7 gap-2 sm:gap-4 min-w-[800px] lg:min-w-[1000px]">
              {/* Day columns */}
              {weekDays.map((day) => {
                const dayAppointments = getAppointmentsForDay(day);
                const isToday = format(day, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
                
                return (
                  <div key={day.toISOString()} className={`border rounded-lg ${isToday ? 'border-primary bg-primary/5' : 'border-slate-200'}`}>
                    {/* Day header */}
                    <div className={`p-3 text-center font-medium border-b ${isToday ? 'bg-primary text-primary-foreground' : 'bg-slate-50 text-slate-700'}`}>
                      <div className="text-sm">{format(day, 'EEE')}</div>
                      <div className="text-lg font-bold">{format(day, 'd')}</div>
                      <div className="text-xs opacity-75">{format(day, 'MMM')}</div>
                    </div>
                    {/* Appointments list */}
                    <div className="p-2 space-y-2 min-h-[300px]">
                      {dayAppointments.length === 0 ? (
                        <div className="text-center text-slate-400 text-sm py-8">
                          No appointments
                        </div>
                      ) : (
                        dayAppointments.map((appointment) => {
                          const service = serviceMap.get(appointment.serviceId);
                          const appointmentDate = new Date(appointment.appointmentDate);
                          const time = format(appointmentDate, 'HH:mm');
                          const endTime = format(new Date(appointmentDate.getTime() + (appointment.duration * 60 * 1000)), 'HH:mm');
                          
                          return (
                            <div
                              key={appointment.id}
                              className={`rounded-lg border-l-4 text-xs cursor-pointer transition-all hover:shadow-md ${getAppointmentColor(appointment)}`}
                              onClick={() => setSelectedAppointment(appointment)}
                            >
                              {/* Condensed view - always visible */}
                              <div className="p-3">
                                <div className="flex items-center justify-between">
                                  <div className="flex-1">
                                    <div className="font-bold mt-[2px] mb-[2px] pt-[0px] pb-[0px] text-[13px] ml-[-8px] mr-[-8px] text-center">
                                      {time} - {endTime}
                                    </div>
                                    <div className="font-semibold">
                                      {appointment.clientName}
                                    </div>
                                    <div className="text-slate-600 text-xs">
                                      {service?.name || 'Service'}
                                    </div>
                                  </div>
                                  <ChevronRight className="h-4 w-4 text-slate-400" />
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Booking Details Popup */}
      <Dialog open={!!selectedAppointment} onOpenChange={() => setSelectedAppointment(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5" />
              Booking Details
            </DialogTitle>
            <DialogDescription>
              Complete information for this appointment
            </DialogDescription>
          </DialogHeader>
          
          {selectedAppointment && (
            <div className="space-y-4">
              {/* Status Badge */}
              <div className="flex justify-between items-start">
                <Badge variant={selectedAppointment.status === 'confirmed' ? 'default' : 'secondary'}>
                  {selectedAppointment.status === 'confirmed' ? 'Confirmed' : 'Pending'}
                </Badge>
                <div className="text-right text-sm text-slate-600">
                  ID: #{selectedAppointment.id}
                </div>
              </div>

              {/* Client Information */}
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <User className="h-4 w-4 text-slate-500" />
                  <div>
                    <div className="font-medium">{selectedAppointment.clientName}</div>
                    <div className="text-sm text-slate-600">Client</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <Mail className="h-4 w-4 text-slate-500" />
                  <div>
                    <div className="font-medium">{selectedAppointment.clientEmail}</div>
                    <div className="text-sm text-slate-600">Email</div>
                  </div>
                </div>

                {selectedAppointment.clientPhone && (
                  <div className="flex items-center gap-3">
                    <Phone className="h-4 w-4 text-slate-500" />
                    <div>
                      <div className="font-medium">{selectedAppointment.clientPhone}</div>
                      <div className="text-sm text-slate-600">Phone</div>
                    </div>
                  </div>
                )}
              </div>

              <div className="border-t pt-4 space-y-3">
                {/* Service Information */}
                <div className="flex items-center gap-3">
                  <FileText className="h-4 w-4 text-slate-500" />
                  <div>
                    <div className="font-medium">
                      {serviceMap.get(selectedAppointment.serviceId)?.name || 'Service'}
                    </div>
                    <div className="text-sm text-slate-600">Service</div>
                  </div>
                </div>

                {/* Date & Time */}
                <div className="flex items-center gap-3">
                  <Clock className="h-4 w-4 text-slate-500" />
                  <div>
                    <div className="font-medium">
                      {format(new Date(selectedAppointment.appointmentDate), 'EEEE, MMMM d, yyyy')}
                    </div>
                    <div className="text-sm text-slate-600">
                      {formatAppointmentTime(selectedAppointment.appointmentDate, selectedAppointment.timezone || 'UTC')} - {formatAppointmentTime(new Date(new Date(selectedAppointment.appointmentDate).getTime() + (selectedAppointment.duration * 60 * 1000)), selectedAppointment.timezone || 'UTC')} ({selectedAppointment.duration} min) {selectedAppointment.timezone || 'UTC'}
                    </div>
                  </div>
                </div>

                {/* Notes */}
                {selectedAppointment.notes && (
                  <div className="flex items-start gap-3">
                    <FileText className="h-4 w-4 text-slate-500 mt-0.5" />
                    <div>
                      <div className="font-medium">Notes</div>
                      <div className="text-sm text-slate-600 mt-1">{selectedAppointment.notes}</div>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedAppointment(null)}
                  className="flex-1"
                >
                  Close
                </Button>
                {selectedAppointment.status === 'pending' && (
                  <Button 
                    size="sm" 
                    className="flex-1"
                    onClick={handleConfirmBooking}
                    disabled={confirmAppointmentMutation.isPending}
                  >
                    {confirmAppointmentMutation.isPending ? "Confirming..." : "Confirm Booking"}
                  </Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}