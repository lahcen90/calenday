import { Link } from "wouter";
import { scrollToTopInstant } from "@/lib/scroll-utils";
import { ReactNode } from "react";

interface ScrollLinkProps {
  href: string;
  children: ReactNode;
  className?: string;
}

export default function ScrollLink({ href, children, className }: ScrollLinkProps) {
  const handleClick = () => {
    // Small delay to ensure navigation happens first
    setTimeout(() => {
      scrollToTopInstant();
    }, 50);
  };

  return (
    <Link href={href}>
      <span onClick={handleClick} className={className}>
        {children}
      </span>
    </Link>
  );
}