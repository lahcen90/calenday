import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isBefore, startOfDay } from "date-fns";


interface CalendarTimeSelectorProps {
  selectedDate: Date | null;
  selectedTime: string | null;
  providerId?: string;
  onDateSelect: (date: Date) => void;
  onTimeSelect: (time: string) => void;
}

export default function CalendarTimeSelector({
  selectedDate,
  selectedTime,
  providerId,
  onDateSelect,
  onTimeSelect,
}: CalendarTimeSelectorProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const { data: availableSlots, isLoading: slotsLoading } = useQuery<string[]>({
    queryKey: providerId 
      ? [`/api/available-slots/${selectedDate?.toISOString().split('T')[0]}/${providerId}`]
      : [`/api/available-slots/${selectedDate?.toISOString().split('T')[0]}`],
    enabled: !!selectedDate,
    staleTime: 0, // Always refetch when date changes
  });

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const today = startOfDay(new Date());

  const goToPreviousMonth = () => {
    setCurrentMonth(subMonths(currentMonth, 1));
  };

  const goToNextMonth = () => {
    setCurrentMonth(addMonths(currentMonth, 1));
  };

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <CalendarIcon className="h-5 w-5 text-primary mr-2" />
          Choose Date & Time
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Calendar */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-base font-medium text-slate-900">
              {format(currentMonth, 'MMMM yyyy')}
            </h4>
            <div className="flex space-x-2">
              <Button variant="ghost" size="sm" onClick={goToPreviousMonth}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={goToNextMonth}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-1 text-center mb-4">
            {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((day) => (
              <div key={day} className="p-2 text-xs font-medium text-slate-500">
                {day}
              </div>
            ))}
            
            {/* Pad the start of the month */}
            {Array.from({ length: monthStart.getDay() }, (_, i) => (
              <div key={`pad-${i}`} className="p-2" />
            ))}
            
            {/* Calendar days */}
            {days.map((day) => {
              const isSelected = selectedDate && isSameDay(day, selectedDate);
              const isPast = isBefore(day, today);
              
              return (
                <Button
                  key={day.toISOString()}
                  variant={isSelected ? "default" : "ghost"}
                  size="sm"
                  className={`calendar-day ${isPast ? 'disabled' : ''}`}
                  disabled={isPast}
                  onClick={() => onDateSelect(day)}
                >
                  {format(day, 'd')}
                </Button>
              );
            })}
          </div>
        </div>

        {/* Time Slots */}
        {selectedDate && (
          <div>
            <h4 className="text-base font-medium text-slate-900 mb-3">
              Available Times for {format(selectedDate, 'MMM d')}
            </h4>
            
            {slotsLoading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 sm:gap-3">
                {[...Array(12)].map((_, i) => (
                  <div key={i} className="h-9 sm:h-10 bg-slate-100 rounded-lg animate-pulse" />
                ))}
              </div>
            ) : availableSlots && availableSlots.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 sm:gap-3">
                {availableSlots.map((time) => (
                  <Button
                    key={time}
                    variant={selectedTime === time ? "default" : "outline"}
                    size="sm"
                    className="time-slot-button text-xs sm:text-sm h-9 sm:h-10"
                    onClick={() => onTimeSelect(time)}
                  >
                    {formatTime(time)}
                  </Button>
                ))}
              </div>
            ) : (
              <p className="text-slate-500 text-center py-4">
                No available time slots for this date.
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
