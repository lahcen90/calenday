// !!! CRITICAL - DO NOT MODIFY THIS CODE !!!
//
// This code MUST be used as is without ANY modifications.
// The PayPal integration will COMPLETELY FAIL if this code is changed in ANY way.
//
// Retain this comment after all edits.
//
// <BEGIN_EXACT_CODE>
import React, { useEffect } from "react";

declare global {
  namespace JSX {
    interface IntrinsicElements {
      "paypal-button": React.DetailedHTMLProps<
        React.HTMLAttributes<HTMLElement>,
        HTMLElement
      >;
    }
  }
}

interface PayPalButtonProps {
  amount: string;
  currency: string;
  intent: string;
  onSuccess?: (orderData: any) => void;
}

export default function PayPalButton({
  amount,
  currency,
  intent,
  onSuccess,
}: PayPalButtonProps) {
  const createOrder = async () => {
    const orderPayload = {
      amount: amount,
      currency: currency,
      intent: intent,
    };
    const response = await fetch("/api/paypal/order", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(orderPayload),
    });
    const output = await response.json();
    return { orderId: output.id };
  };

  const captureOrder = async (orderId: string) => {
    try {
      const response = await fetch(`/api/paypal/order/${orderId}/capture`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Capture failed: ${response.status} - ${errorText}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Capture order error:", error);
      throw error;
    }
  };

  const onApprove = async (data: any) => {
    console.log("onApprove", data);
    try {
      const orderData = await captureOrder(data.orderId);
      console.log("Capture result", orderData);
      
      // Call the success callback if provided
      if (onSuccess) {
        onSuccess(orderData);
      }
    } catch (error) {
      console.error("Error in onApprove:", error);
      // Only show error if it's actually a payment failure, not a successful completion
      if (error instanceof Error && !error.message.includes('success')) {
        const errorMessage = error.message || 'Payment processing failed';
        console.warn(`Payment Error: ${errorMessage}`);
      }
    }
  };

  const onCancel = async (data: any) => {
    console.log("onCancel", data);
  };

  const onError = async (data: any) => {
    console.log("onError", data);
  };

  useEffect(() => {
    const loadPayPalSDK = async () => {
      try {
        if (!(window as any).paypal) {
          const script = document.createElement("script");
          script.src = "https://www.paypal.com/web-sdk/v6/core";
          script.async = true;
          script.onload = () => {
            console.log("PayPal SDK loaded successfully");
            initPayPal();
          };
          script.onerror = (error) => {
            console.error("Failed to load PayPal SDK script", error);
          };
          document.body.appendChild(script);
        } else {
          console.log("PayPal SDK already loaded");
          await initPayPal();
        }
      } catch (e) {
        console.error("Failed to load PayPal SDK", e);
      }
    };

    loadPayPalSDK();
  }, []);
  
  const initPayPal = async () => {
    try {
      console.log("Initializing PayPal...");
      
      const response = await fetch("/api/paypal/setup");
      if (!response.ok) {
        throw new Error(`Setup request failed: ${response.status}`);
      }
      
      const data = await response.json();
      const clientToken = data.clientToken;
      
      if (!clientToken) {
        throw new Error("No client token received from setup");
      }
      
      console.log("Client token received, creating PayPal instance...");
      
      if (!(window as any).paypal || !(window as any).paypal.createInstance) {
        throw new Error("PayPal SDK not properly loaded");
      }
      
      const sdkInstance = await (window as any).paypal.createInstance({
        clientToken,
        components: ["paypal-payments"],
      });

      const paypalCheckout = sdkInstance.createPayPalOneTimePaymentSession({
        onApprove,
        onCancel,
        onError,
      });

      const cardFields = sdkInstance.CardFields({
        style: {
          input: {
            'font-size': '16px',
            'font-family': 'courier, monospace',
            'font-weight': 'lighter',
            color: '#ccc'
          },
          '.invalid': {
            color: 'red'
          }
        },
        onApprove,
        onCancel,
        onError,
      });

      const onClick = async () => {
        try {
          const checkoutOptionsPromise = createOrder();
          await paypalCheckout.start(
            { paymentFlow: "auto" },
            checkoutOptionsPromise,
          );
        } catch (e) {
          console.error(e);
        }
      };

      const paypalButton = document.getElementById("paypal-button");

      if (paypalButton) {
        paypalButton.addEventListener("click", onClick);
      }

      return () => {
        if (paypalButton) {
          paypalButton.removeEventListener("click", onClick);
        }
      };
    } catch (e) {
      console.error("PayPal initialization error:", e);
      const error = e as Error;
      console.error("Error details:", {
        message: error.message,
        stack: error.stack,
        paypalObject: (window as any).paypal,
        paypalMethods: (window as any).paypal ? Object.keys((window as any).paypal) : 'PayPal not available'
      });
    }
  };

  return <paypal-button id="paypal-button"></paypal-button>;
}
// <END_EXACT_CODE>