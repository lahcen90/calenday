import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { ClipboardList, Clock } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import type { Service } from "@shared/schema";

interface ServiceSelectorProps {
  selectedService: Service | null;
  onServiceSelect: (service: Service) => void;
  queryKey?: string | string[];
}

interface ServiceWithCustomization extends Service {
  customDuration?: number;
}

export default function ServiceSelector({ selectedService, onServiceSelect, queryKey }: ServiceSelectorProps) {
  const { data: services, isLoading } = useQuery<Service[]>({
    queryKey: queryKey ? (Array.isArray(queryKey) ? queryKey : [queryKey]) : ["/api/services"],
  });

  const [selectedDuration, setSelectedDuration] = useState<string>("default");
  const [customDuration, setCustomDuration] = useState<number>(0);

  const durationOptions = [
    { value: "default", label: "Default", minutes: 0 },
    { value: "30", label: "30 minutes", minutes: 30 },
    { value: "60", label: "60 minutes", minutes: 60 },
    { value: "90", label: "90 minutes", minutes: 90 },
    { value: "120", label: "120 minutes", minutes: 120 },
    { value: "custom", label: "Custom", minutes: 0 },
  ];

  const handleServiceSelect = (service: Service, duration?: number) => {
    const customizedService: ServiceWithCustomization = {
      ...service,
      customDuration: duration,
    };
    onServiceSelect(customizedService as Service);
  };

  const handleDurationChange = (value: string) => {
    setSelectedDuration(value);
    
    if (!selectedService) return;
    
    const option = durationOptions.find(opt => opt.value === value);
    if (!option) return;
    
    if (value === "default") {
      handleServiceSelect(selectedService);
    } else if (value === "custom") {
      if (customDuration > 0) {
        handleServiceSelect(selectedService, customDuration);
      }
    } else {
      handleServiceSelect(selectedService, option.minutes);
    }
  };

  const handleCustomDurationChange = (value: string) => {
    const duration = parseInt(value);
    setCustomDuration(duration);
    
    if (selectedService && duration > 0) {
      handleServiceSelect(selectedService, duration);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <ClipboardList className="h-5 w-5 text-primary mr-2" />
            Select Service & Duration
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-16 bg-slate-100 rounded-lg animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <ClipboardList className="h-5 w-5 text-primary mr-2" />
          Select Service
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Service Selection */}
        <div>
          <Label className="text-sm font-medium text-slate-700 mb-3 block">Choose Service</Label>
          <RadioGroup
            value={selectedService?.id.toString() || ""}
            onValueChange={(value) => {
              const service = services?.find(s => s.id.toString() === value);
              if (service) {
                handleServiceSelect(service);
                setSelectedDuration("default");
                setCustomDuration(0);
              }
            }}
          >
            <div className="space-y-3">
              {services?.map((service) => (
                <div key={service.id} className="service-option flex items-start space-x-3 p-3 border rounded-lg hover:bg-slate-50">
                  <RadioGroupItem value={service.id.toString()} id={service.id.toString()} className="mt-1" />
                  <Label htmlFor={service.id.toString()} className="flex-1 cursor-pointer">
                    <div className="font-medium text-slate-900">{service.name}</div>
                    <div className="text-sm text-slate-500 mt-1">{service.description}</div>
                    <div className="text-sm text-slate-600 mt-1 flex items-center space-x-3">
                      <span className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        {service.duration} min
                      </span>
                      
                    </div>
                  </Label>
                </div>
              ))}
            </div>
          </RadioGroup>
        </div>

        {/* Duration & Pricing Options */}
        {selectedService && (
          <div className="space-y-4 pt-4 border-t">
            <Label className="text-sm font-medium text-slate-700">Choose Duration</Label>
            <p className="text-xs text-slate-500">Select from 30 min, 60 min, 90 min or set a custom duration</p>
            
            <Select value={selectedDuration} onValueChange={handleDurationChange}>
              <SelectTrigger>
                <SelectValue placeholder="Select duration" />
              </SelectTrigger>
              <SelectContent>
                {durationOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {selectedDuration === "custom" && (
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-slate-600">Custom Duration (minutes)</Label>
                  <Input
                    type="number"
                    min="15"
                    max="480"
                    step="15"
                    value={customDuration || ""}
                    onChange={(e) => handleCustomDurationChange(e.target.value)}
                    placeholder="Enter minutes"
                  />
                </div>
              </div>
            )}

            {/* Current Selection Summary */}
            <div className="bg-blue-50 p-3 rounded-lg">
              <div className="text-sm font-medium text-blue-900">Selected:</div>
              <div className="text-sm text-blue-700 mt-1">
                {selectedService.name} • {
                  selectedDuration === "default" ? selectedService.duration :
                  selectedDuration === "custom" ? customDuration :
                  durationOptions.find(opt => opt.value === selectedDuration)?.minutes
                } minutes
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
