import { Card, CardContent } from "@/components/ui/card";
import { Calendar, CalendarDays, Clock } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface DashboardStatsData {
  today: number;
  thisWeek: number;
  pending: number;
}

export default function DashboardStats() {
  const { data: stats, isLoading } = useQuery<DashboardStatsData>({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        {[...Array(3)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-center">
                <div className="p-2 bg-slate-100 rounded-lg animate-pulse">
                  <div className="h-5 w-5 sm:h-6 sm:w-6" />
                </div>
                <div className="ml-3 sm:ml-4 space-y-2">
                  <div className="h-3 sm:h-4 w-12 sm:w-16 bg-slate-100 rounded animate-pulse" />
                  <div className="h-6 sm:h-8 w-8 sm:w-12 bg-slate-100 rounded animate-pulse" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const statItems = [
    {
      label: "Today",
      value: stats?.today || 0,
      icon: Calendar,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      label: "This Week",
      value: stats?.thisWeek || 0,
      icon: CalendarDays,
      iconColor: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      label: "Pending",
      value: stats?.pending || 0,
      icon: Clock,
      iconColor: "text-amber-600",
      bgColor: "bg-amber-100",
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
      {statItems.map((item) => (
        <Card key={item.label}>
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center">
              <div className={`p-2 ${item.bgColor} rounded-lg`}>
                <item.icon className={`h-5 w-5 sm:h-6 sm:w-6 ${item.iconColor}`} />
              </div>
              <div className="ml-3 sm:ml-4">
                <p className="text-xs sm:text-sm font-medium text-slate-600">{item.label}</p>
                <p className="text-xl sm:text-2xl font-bold text-slate-900">{item.value}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
