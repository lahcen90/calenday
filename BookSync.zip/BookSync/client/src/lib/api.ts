import { apiRequest } from "./queryClient";
import type { Service, Appointment, InsertAppointment } from "@shared/schema";

export const api = {
  // Services
  services: {
    getAll: async (): Promise<Service[]> => {
      const response = await fetch("/api/services");
      if (!response.ok) throw new Error("Failed to fetch services");
      return response.json();
    },
    
    getById: async (id: number): Promise<Service> => {
      const response = await fetch(`/api/services/${id}`);
      if (!response.ok) throw new Error("Failed to fetch service");
      return response.json();
    },
  },

  // Appointments
  appointments: {
    getAll: async (): Promise<Appointment[]> => {
      const response = await fetch("/api/appointments");
      if (!response.ok) throw new Error("Failed to fetch appointments");
      return response.json();
    },
    
    getByDateRange: async (startDate: string, endDate: string): Promise<Appointment[]> => {
      const response = await fetch(`/api/appointments?startDate=${startDate}&endDate=${endDate}`);
      if (!response.ok) throw new Error("Failed to fetch appointments");
      return response.json();
    },
    
    create: async (appointment: InsertAppointment): Promise<Appointment> => {
      const response = await apiRequest("POST", "/api/appointments", appointment);
      return response.json();
    },
    
    update: async (id: number, data: Partial<InsertAppointment>): Promise<Appointment> => {
      const response = await apiRequest("PATCH", `/api/appointments/${id}`, data);
      return response.json();
    },
    
    delete: async (id: number): Promise<void> => {
      await apiRequest("DELETE", `/api/appointments/${id}`);
    },
  },

  // Availability
  availability: {
    getAvailableSlots: async (date: string): Promise<string[]> => {
      const response = await fetch(`/api/available-slots/${date}`);
      if (!response.ok) throw new Error("Failed to fetch available slots");
      return response.json();
    },
  },

  // Dashboard
  dashboard: {
    getStats: async () => {
      const response = await fetch("/api/dashboard/stats");
      if (!response.ok) throw new Error("Failed to fetch dashboard stats");
      return response.json();
    },
  },
};
