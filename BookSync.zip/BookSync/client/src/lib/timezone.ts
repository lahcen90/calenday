import { formatInTimeZone } from 'date-fns-tz';

// Get user's timezone
export function getUserTimezone(): string {
  try {
    // Check localStorage first for user preference
    const savedTimezone = localStorage.getItem('user-timezone');
    if (savedTimezone) {
      return savedTimezone;
    }
    // Fall back to browser timezone
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
  } catch (error) {
    return 'UTC';
  }
}

// Format appointment time in specific timezone
export function formatAppointmentTime(
  appointmentDate: Date | string,
  appointmentTimezone: string,
  format: string = 'h:mm a'
): string {
  const date = typeof appointmentDate === 'string' ? new Date(appointmentDate) : appointmentDate;
  // For stored appointments, treat the stored time as the local time in the booking timezone
  // Extract the time components and create a display string without timezone conversion
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const day = date.getDate().toString().padStart(2, '0');
  const hours = date.getHours();
  const minutes = date.getMinutes();
  
  // Create a simple time display
  const hour12 = hours === 0 ? 12 : hours > 12 ? hours - 12 : hours;
  const ampm = hours >= 12 ? 'PM' : 'AM';
  const minuteStr = minutes.toString().padStart(2, '0');
  
  if (format === 'h:mm a') {
    return `${hour12}:${minuteStr} ${ampm}`;
  }
  
  // For other formats, use the timezone formatting
  return formatInTimeZone(date, appointmentTimezone, format);
}

// Create timezone-aware appointment date for storage
export function createTimezoneAwareDate(
  dateStr: string,
  timeStr: string,
  timezone: string
): Date {
  // Parse the date and time components
  const [hours, minutes] = timeStr.split(':').map(Number);
  const baseDate = new Date(dateStr);
  
  // Create the date string in ISO format for the specific timezone
  const year = baseDate.getFullYear();
  const month = (baseDate.getMonth() + 1).toString().padStart(2, '0');
  const day = baseDate.getDate().toString().padStart(2, '0');
  const hour = hours.toString().padStart(2, '0');
  const minute = minutes.toString().padStart(2, '0');
  
  // Create a date that represents the time in the specified timezone
  const dateTimeString = `${year}-${month}-${day}T${hour}:${minute}:00`;
  return new Date(dateTimeString);
}

// Format date in user's timezone - for backward compatibility
export function formatInUserTimezone(
  date: Date | string, 
  formatString: string, 
  timezone?: string
): string {
  const tz = timezone || getUserTimezone();
  return formatAppointmentTime(date, tz, formatString);
}

// Get timezone display name
export function getTimezoneDisplay(timezone?: string): string {
  const tz = timezone || getUserTimezone();
  try {
    const formatter = new Intl.DateTimeFormat('en', {
      timeZone: tz,
      timeZoneName: 'short'
    });
    const parts = formatter.formatToParts(new Date());
    const timeZoneName = parts.find(part => part.type === 'timeZoneName');
    return timeZoneName ? `${tz} (${timeZoneName.value})` : tz;
  } catch {
    return tz;
  }
}

// Regional timezone options organized by continent with GMT offsets
export const commonTimezones = [
  // North America
  { value: 'America/New_York', label: 'Eastern Time (New York) GMT-5' },
  { value: 'America/Chicago', label: 'Central Time (Chicago) GMT-6' },
  { value: 'America/Denver', label: 'Mountain Time (Denver) GMT-7' },
  { value: 'America/Los_Angeles', label: 'Pacific Time (Los Angeles) GMT-8' },
  { value: 'America/Anchorage', label: 'Alaska Time (Anchorage) GMT-9' },
  { value: 'Pacific/Honolulu', label: 'Hawaii Standard Time GMT-10' },
  
  // South America
  { value: 'America/Sao_Paulo', label: 'Brasília Time (São Paulo) GMT-3' },
  { value: 'America/Argentina/Buenos_Aires', label: 'Argentina Time (Buenos Aires) GMT-3' },
  { value: 'America/Bogota', label: 'Colombia Time (Bogotá) GMT-5' },
  { value: 'America/Lima', label: 'Peru Time (Lima) GMT-5' },
  { value: 'America/Santiago', label: 'Chile Standard Time (Santiago) GMT-4' },
  
  // Europe
  { value: 'Europe/London', label: 'Greenwich Mean Time (London) GMT+0' },
  { value: 'Europe/Paris', label: 'Central European Time (Paris) GMT+1' },
  { value: 'Europe/Berlin', label: 'Central European Time (Berlin) GMT+1' },
  { value: 'Europe/Moscow', label: 'Moscow Standard Time GMT+3' },
  { value: 'Europe/Istanbul', label: 'Turkey Time (Istanbul) GMT+3' },
  
  // Asia
  { value: 'Asia/Dubai', label: 'Gulf Standard Time (Dubai) GMT+4' },
  { value: 'Asia/Kolkata', label: 'India Standard Time (Mumbai) GMT+5:30' },
  { value: 'Asia/Bangkok', label: 'Indochina Time (Bangkok) GMT+7' },
  { value: 'Asia/Singapore', label: 'Singapore Standard Time GMT+8' },
  { value: 'Asia/Tokyo', label: 'Japan Standard Time (Tokyo) GMT+9' },
  
  // Australia
  { value: 'Australia/Sydney', label: 'Australian Eastern Time (Sydney) GMT+10' },
  { value: 'Australia/Melbourne', label: 'Australian Eastern Time (Melbourne) GMT+10' },
  { value: 'Australia/Perth', label: 'Australian Western Time (Perth) GMT+8' },
  { value: 'Australia/Adelaide', label: 'Australian Central Time (Adelaide) GMT+9:30' },
  
  // Africa
  { value: 'Africa/Cairo', label: 'Eastern European Time (Cairo) GMT+2' },
  { value: 'Africa/Johannesburg', label: 'South Africa Standard Time GMT+2' },
  { value: 'Africa/Lagos', label: 'West Africa Time (Lagos) GMT+1' },
  { value: 'Africa/Nairobi', label: 'East Africa Time (Nairobi) GMT+3' },
  
  // Pacific
  { value: 'Pacific/Auckland', label: 'New Zealand Standard Time GMT+12' },
  { value: 'Pacific/Fiji', label: 'Fiji Standard Time GMT+12' },
  { value: 'Pacific/Guam', label: 'Chamorro Standard Time (Guam) GMT+10' },
  
  // GMT
  { value: 'UTC', label: 'Greenwich Mean Time GMT+0' }
];