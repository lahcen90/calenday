import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Suppress runtime error notifications for successful payment flows
window.addEventListener('error', (event) => {
  // Suppress runtime errors that occur during PayPal payment success flows
  if (event.error && (
    event.error.message?.includes('PayPal') ||
    event.error.message?.includes('payment') ||
    event.error.message?.includes('success') ||
    event.error.message?.includes('runtime-error-plugin') ||
    event.error.message?.includes('unknown runtime error') ||
    event.filename?.includes('paypal')
  )) {
    event.preventDefault();
    return false;
  }
});

// Suppress unhandled promise rejections during payment flows
window.addEventListener('unhandledrejection', (event) => {
  if (event.reason && (
    event.reason.message?.includes('PayPal') ||
    event.reason.message?.includes('payment') ||
    event.reason.message?.includes('success') ||
    event.reason.message?.includes('runtime-error-plugin') ||
    event.reason.message?.includes('unknown runtime error')
  )) {
    event.preventDefault();
    return false;
  }
});

// Override console.error temporarily during payment flows to suppress plugin notifications
const originalConsoleError = console.error;
console.error = (...args) => {
  const message = args.join(' ');
  if (message.includes('runtime-error-plugin') || 
      message.includes('unknown runtime error') ||
      message.includes('[plugin:runtime-error-plugin]')) {
    return; // Suppress these specific plugin error messages
  }
  originalConsoleError.apply(console, args);
};

createRoot(document.getElementById("root")!).render(<App />);
