import { pgTable, text, serial, integer, boolean, timestamp, decimal, varchar, jsonb, index, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(), // Links service to specific user
  name: text("name").notNull(),
  description: text("description"),
  duration: integer("duration").notNull(), // duration in minutes
  isActive: boolean("is_active").notNull().default(true),
});

export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(), // Links appointment to specific user/provider
  clientId: varchar("client_id"), // Links appointment to the booking client (for user isolation)
  serviceId: integer("service_id").notNull(),
  clientName: text("client_name").notNull(),
  clientEmail: text("client_email").notNull(),
  clientPhone: text("client_phone").notNull(),
  notes: text("notes"),
  appointmentDate: timestamp("appointment_date").notNull(),
  duration: integer("duration").notNull().default(60), // actual duration used for this appointment
  price: decimal("price", { precision: 10, scale: 2 }).notNull().default('100.00'), // actual price for this appointment
  timezone: varchar("timezone").notNull().default("UTC"), // timezone when booking was made
  status: text("status", { enum: ["pending", "confirmed", "cancelled", "completed"] }).notNull().default("pending"),
  googleEventId: text("google_event_id"), // for Google Calendar sync
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const availability = pgTable("availability", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(), // Links availability to specific user
  dayOfWeek: integer("day_of_week").notNull(), // 0-6 (Sunday-Saturday)
  startTime: text("start_time").notNull(), // HH:MM format
  endTime: text("end_time").notNull(), // HH:MM format
  isAvailable: boolean("is_available").notNull().default(true),
});

export const blockedTimes = pgTable("blocked_times", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(), // Links blocked time to specific user
  date: timestamp("date").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  reason: text("reason"),
});

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique().notNull(),
  password: varchar("password"),
  emailVerified: boolean("email_verified").default(false),
  emailVerificationToken: varchar("email_verification_token"),
  resetPasswordToken: varchar("reset_password_token"),
  resetPasswordExpires: timestamp("reset_password_expires"),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  companyName: varchar("company_name"),
  companyLogoUrl: varchar("company_logo_url"),
  companyWebsite: varchar("company_website"),
  companyWebsiteEnabled: boolean("company_website_enabled").default(false),
  whatsNextMessage: text("whats_next_message"),
  emailNotificationsEnabled: boolean("email_notifications_enabled").default(true),
  emailReminders: boolean("email_reminders").default(true),
  reminderTime: integer("reminder_time").default(60),
  reminderUnit: varchar("reminder_unit", { enum: ["minutes", "hours", "days"] }).default("minutes"),
  allowMultipleBookings: boolean("allow_multiple_bookings").default(false),
  allowTimezoneSelection: boolean("allow_timezone_selection").default(true),
  defaultTimezone: varchar("default_timezone").default("America/New_York"),
  subscriptionPlan: varchar("subscription_plan").default("free"), // "free" or "pro"
  subscriptionStatus: varchar("subscription_status").default("active"), // "active", "cancelled", "expired"
  subscriptionStartDate: timestamp("subscription_start_date"),
  subscriptionEndDate: timestamp("subscription_end_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Notification read status tracking
export const notificationReadStatus = pgTable("notification_read_status", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  appointmentId: integer("appointment_id").notNull().references(() => appointments.id, { onDelete: "cascade" }),
  isRead: boolean("is_read").default(false),
  isDeleted: boolean("is_deleted").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  uniqueUserAppointment: unique("unique_user_appointment").on(table.userId, table.appointmentId),
}));

export const insertServiceSchema = createInsertSchema(services).omit({
  id: true,
  userId: true, // Exclude userId - will be set server-side
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  userId: true, // Exclude userId from validation - will be set server-side
  createdAt: true,
}).extend({
  appointmentDate: z.string().transform((str) => new Date(str)),
  duration: z.number().min(15).max(480),
  price: z.number().min(0).optional().default(0),
  providerId: z.string().optional(), // Optional provider ID for guest bookings
  googleEventId: z.string().optional(), // Allow Google Event ID updates
});

export const insertAvailabilitySchema = createInsertSchema(availability).omit({
  id: true,
  userId: true, // Exclude userId - will be set server-side
});

export const insertBlockedTimeSchema = createInsertSchema(blockedTimes).omit({
  id: true,
  userId: true, // Exclude userId - will be set server-side
}).extend({
  date: z.string().transform((str) => new Date(str)),
});

// Authentication schemas
export const registerUserSchema = createInsertSchema(users).pick({
  email: true,
  firstName: true,
  lastName: true,
}).extend({
  password: z.string().min(8, "Password must be at least 8 characters"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export const loginUserSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});

export const resetPasswordSchema = z.object({
  email: z.string().email("Invalid email address"),
});

export const resetPasswordConfirmSchema = z.object({
  token: z.string(),
  password: z.string().min(8, "Password must be at least 8 characters"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export type Service = typeof services.$inferSelect;
export type InsertService = z.infer<typeof insertServiceSchema>;
export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Availability = typeof availability.$inferSelect;
export type InsertAvailability = z.infer<typeof insertAvailabilitySchema>;
export type BlockedTime = typeof blockedTimes.$inferSelect;
export type InsertBlockedTime = z.infer<typeof insertBlockedTimeSchema>;
export type User = typeof users.$inferSelect;
export type UpsertUser = typeof users.$inferInsert;
export type RegisterUser = z.infer<typeof registerUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;

export type NotificationReadStatus = typeof notificationReadStatus.$inferSelect;
export type InsertNotificationReadStatus = typeof notificationReadStatus.$inferInsert;
