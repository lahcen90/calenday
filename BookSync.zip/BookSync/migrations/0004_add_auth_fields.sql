-- Add authentication fields to users table
ALTER TABLE users 
ADD COLUMN password VARCHAR,
ADD COLUMN email_verified BOOLEAN DEFAULT FALSE,
ADD COLUMN email_verification_token VARCHAR,
ADD COLUMN reset_password_token VARCHAR,
ADD COLUMN reset_password_expires TIMESTAMP;

-- Make email NOT NULL
ALTER TABLE users ALTER COLUMN email SET NOT NULL;