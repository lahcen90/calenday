-- Add company website enabled field to users table
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "company_website_enabled" boolean DEFAULT false;