-- Create notification read status tracking table
CREATE TABLE IF NOT EXISTS "notification_read_status" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" varchar NOT NULL,
	"appointment_id" integer NOT NULL,
	"is_read" boolean DEFAULT false,
	"is_deleted" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);

-- Add foreign key constraints
DO $$ BEGIN
 ALTER TABLE "notification_read_status" ADD CONSTRAINT "notification_read_status_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
 ALTER TABLE "notification_read_status" ADD CONSTRAINT "notification_read_status_appointment_id_appointments_id_fk" FOREIGN KEY ("appointment_id") REFERENCES "appointments"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;

-- Add unique constraint to prevent duplicate entries
DO $$ BEGIN
 ALTER TABLE "notification_read_status" ADD CONSTRAINT "unique_user_appointment" UNIQUE("user_id","appointment_id");
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;