-- Add email notifications enabled field to users table
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "email_notifications_enabled" boolean DEFAULT true;