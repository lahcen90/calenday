-- Migration to add user isolation to all tables
-- This allows each user to have their own data

-- Add userId column to services table
ALTER TABLE services ADD COLUMN user_id VARCHAR NOT NULL DEFAULT 'default_user';

-- Add userId column to appointments table  
ALTER TABLE appointments ADD COLUMN user_id VARCHAR NOT NULL DEFAULT 'default_user';

-- Add userId column to availability table
ALTER TABLE availability ADD COLUMN user_id VARCHAR NOT NULL DEFAULT 'default_user';

-- Add userId column to blocked_times table
ALTER TABLE blocked_times ADD COLUMN user_id VARCHAR NOT NULL DEFAULT 'default_user';

-- Create indexes for better performance on user-specific queries
CREATE INDEX idx_services_user_id ON services(user_id);
CREATE INDEX idx_appointments_user_id ON appointments(user_id);
CREATE INDEX idx_availability_user_id ON availability(user_id);
CREATE INDEX idx_blocked_times_user_id ON blocked_times(user_id);