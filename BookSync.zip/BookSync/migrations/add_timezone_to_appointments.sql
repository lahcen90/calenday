-- Add timezone column to appointments table
ALTER TABLE appointments ADD COLUMN timezone VARCHAR DEFAULT 'UTC' NOT NULL;

-- Update existing appointments to use UTC timezone as default
UPDATE appointments SET timezone = 'UTC' WHERE timezone IS NULL;