-- Add clientId column to appointments table for user isolation
ALTER TABLE appointments ADD COLUMN client_id VARCHAR;

-- Update existing appointments to set clientId based on clientEmail for data consistency
UPDATE appointments SET client_id = client_email WHERE client_id IS NULL;