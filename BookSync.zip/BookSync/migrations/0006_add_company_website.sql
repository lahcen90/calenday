-- Add company website field to users table
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "company_website" varchar;