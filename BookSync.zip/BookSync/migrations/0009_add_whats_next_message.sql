-- Add whats next message field to users table
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "whats_next_message" text;