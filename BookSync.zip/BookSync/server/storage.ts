import { 
  services, 
  appointments, 
  availability, 
  blockedTimes,
  users,
  notificationReadStatus,
  type Service,
  type InsertService,
  type Appointment,
  type InsertAppointment,
  type Availability,
  type InsertAvailability,
  type BlockedTime,
  type InsertBlockedTime,
  type User,
  type UpsertUser,
  type NotificationReadStatus,
  type InsertNotificationReadStatus
} from "@shared/schema";
import { db } from "./db";
import { eq, and, asc } from "drizzle-orm";
import { sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for authentication)
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: UpsertUser): Promise<User>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserProfile(id: string, profileData: Partial<UpsertUser>): Promise<User | undefined>;
  
  // Authentication operations
  getUserByVerificationToken(token: string): Promise<User | undefined>;
  getUserByResetToken(token: string): Promise<User | undefined>;
  verifyUserEmail(id: string): Promise<void>;
  savePasswordResetToken(id: string, token: string, expires: Date): Promise<void>;
  updatePassword(id: string, hashedPassword: string): Promise<void>;
  
  // Services
  getServices(): Promise<Service[]>;
  getServicesByUser(userId: string): Promise<Service[]>;
  getService(id: number): Promise<Service | undefined>;
  createService(service: InsertService, userId: string): Promise<Service>;
  updateService(id: number, service: Partial<InsertService>, userId: string): Promise<Service | undefined>;
  
  // Appointments
  getAppointments(userId: string): Promise<Appointment[]>;
  getAppointment(id: number, userId: string): Promise<Appointment | undefined>;
  getAppointmentsByDateRange(startDate: Date, endDate: Date, userId: string): Promise<Appointment[]>;
  getAppointmentsByClient(clientId: string): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment, userId: string): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<InsertAppointment> & { googleEventId?: string }, userId: string): Promise<Appointment | undefined>;
  deleteAppointment(id: number, userId: string): Promise<boolean>;
  
  // Availability
  getAvailability(userId: string): Promise<Availability[]>;
  createAvailability(availability: InsertAvailability, userId: string): Promise<Availability>;
  updateAvailability(id: number, availability: Partial<InsertAvailability>, userId: string): Promise<Availability | undefined>;
  deleteAvailability(id: number, userId: string): Promise<boolean>;
  
  // Blocked Times
  getBlockedTimes(userId: string): Promise<BlockedTime[]>;
  getBlockedTimesByDate(date: Date, userId: string): Promise<BlockedTime[]>;
  createBlockedTime(blockedTime: InsertBlockedTime, userId: string): Promise<BlockedTime>;
  deleteBlockedTime(id: number, userId: string): Promise<boolean>;
  
  // Notification Read Status
  getNotificationStatus(userId: string, appointmentId: number): Promise<NotificationReadStatus | undefined>;
  markNotificationAsRead(userId: string, appointmentId: number): Promise<NotificationReadStatus>;
  markNotificationAsDeleted(userId: string, appointmentId: number): Promise<NotificationReadStatus>;
  getNotificationStatuses(userId: string): Promise<NotificationReadStatus[]>;
  
  // Admin operations
  getAllUsers(): Promise<User[]>;
  deleteUser(id: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations (required for authentication)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserProfile(id: string, profileData: Partial<UpsertUser>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({
        ...profileData,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Authentication operations
  async getUserByVerificationToken(token: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.emailVerificationToken, token));
    return user;
  }

  async getUserByResetToken(token: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.resetPasswordToken, token));
    return user;
  }

  async verifyUserEmail(id: string): Promise<void> {
    await db
      .update(users)
      .set({ 
        emailVerified: true, 
        emailVerificationToken: null,
        updatedAt: new Date() 
      })
      .where(eq(users.id, id));
  }

  async savePasswordResetToken(id: string, token: string, expires: Date): Promise<void> {
    await db
      .update(users)
      .set({ 
        resetPasswordToken: token,
        resetPasswordExpires: expires,
        updatedAt: new Date() 
      })
      .where(eq(users.id, id));
  }

  async updatePassword(id: string, hashedPassword: string): Promise<void> {
    await db
      .update(users)
      .set({ 
        password: hashedPassword,
        resetPasswordToken: null,
        resetPasswordExpires: null,
        updatedAt: new Date() 
      })
      .where(eq(users.id, id));
  }

  // Services
  async getServices(): Promise<Service[]> {
    // For now, return all services but we'll add user filtering later
    const result = await db.select().from(services).where(eq(services.isActive, true));
    return result;
  }

  async getServicesByUser(userId: string): Promise<Service[]> {
    const result = await db.select().from(services).where(
      and(eq(services.userId, userId), eq(services.isActive, true))
    );
    return result;
  }

  async getService(id: number): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(eq(services.id, id));
    return service;
  }

  async createService(insertService: InsertService, userId: string): Promise<Service> {
    const [service] = await db
      .insert(services)
      .values({
        userId: userId,
        name: insertService.name,
        description: insertService.description ?? null,
        duration: insertService.duration,
        isActive: insertService.isActive ?? true
      })
      .returning();
    return service;
  }

  async updateService(id: number, updateData: Partial<InsertService>, userId: string): Promise<Service | undefined> {
    const [service] = await db
      .update(services)
      .set(updateData)
      .where(and(eq(services.id, id), eq(services.userId, userId)))
      .returning();
    return service;
  }

  // Appointments
  async getAppointments(userId: string): Promise<Appointment[]> {
    const result = await db.select().from(appointments).where(eq(appointments.userId, userId));
    return result;
  }

  async getAppointment(id: number, userId: string): Promise<Appointment | undefined> {
    const [appointment] = await db.select().from(appointments).where(
      and(eq(appointments.id, id), eq(appointments.userId, userId))
    );
    return appointment;
  }

  async getAppointmentsByDateRange(startDate: Date, endDate: Date, userId: string): Promise<Appointment[]> {
    const result = await db.select().from(appointments).where(eq(appointments.userId, userId));
    return result.filter(appointment => {
      const appointmentDate = new Date(appointment.appointmentDate);
      return appointmentDate >= startDate && appointmentDate <= endDate;
    });
  }

  async getAppointmentsByClient(clientId: string): Promise<Appointment[]> {
    const result = await db.select().from(appointments).where(eq(appointments.clientId, clientId));
    return result;
  }

  async createAppointment(insertAppointment: any): Promise<Appointment> {
    const [appointment] = await db
      .insert(appointments)
      .values({
        userId: insertAppointment.userId,
        clientId: insertAppointment.clientId,
        serviceId: insertAppointment.serviceId,
        clientName: insertAppointment.clientName,
        clientEmail: insertAppointment.clientEmail,
        clientPhone: insertAppointment.clientPhone,
        notes: insertAppointment.notes ?? null,
        appointmentDate: insertAppointment.appointmentDate,
        duration: insertAppointment.duration,
        price: insertAppointment.price.toString(),
        timezone: insertAppointment.timezone ?? "UTC",
        status: insertAppointment.status ?? "pending",
        googleEventId: null,
        createdAt: new Date(),
      })
      .returning();
    return appointment;
  }

  async updateAppointment(id: number, updateData: Partial<InsertAppointment> & { googleEventId?: string }, userId: string): Promise<Appointment | undefined> {
    try {
      // Process and validate the update data
      const processedData: any = { ...updateData };
      
      // Convert price to string if it exists
      if (updateData.price !== undefined) {
        processedData.price = updateData.price.toString();
      }
      
      // Ensure appointmentDate is properly formatted
      if (updateData.appointmentDate) {
        processedData.appointmentDate = new Date(updateData.appointmentDate);
      }
      
      // Remove undefined fields to avoid issues
      Object.keys(processedData).forEach(key => {
        if (processedData[key] === undefined) {
          delete processedData[key];
        }
      });
      
      console.log("Processing appointment update:", { id, userId, processedData });
      
      const [appointment] = await db
        .update(appointments)
        .set(processedData)
        .where(and(eq(appointments.id, id), eq(appointments.userId, userId)))
        .returning();
      
      return appointment;
    } catch (error) {
      console.error("Storage updateAppointment error:", error);
      throw error;
    }
  }

  async deleteAppointment(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(appointments).where(
      and(eq(appointments.id, id), eq(appointments.userId, userId))
    );
    return (result.rowCount ?? 0) > 0;
  }

  // Availability
  async getAvailability(userId: string): Promise<Availability[]> {
    const result = await db.select().from(availability).where(eq(availability.userId, userId));
    return result;
  }

  async createAvailability(insertAvailability: InsertAvailability, userId: string): Promise<Availability> {
    const [avail] = await db
      .insert(availability)
      .values({
        userId: userId,
        dayOfWeek: insertAvailability.dayOfWeek,
        startTime: insertAvailability.startTime,
        endTime: insertAvailability.endTime,
        isAvailable: insertAvailability.isAvailable ?? true
      })
      .returning();
    return avail;
  }

  async updateAvailability(id: number, updateData: Partial<InsertAvailability>, userId: string): Promise<Availability | undefined> {
    const [avail] = await db
      .update(availability)
      .set(updateData)
      .where(and(eq(availability.id, id), eq(availability.userId, userId)))
      .returning();
    return avail;
  }

  async deleteAvailability(id: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(availability)
      .where(and(eq(availability.id, id), eq(availability.userId, userId)))
      .returning();
    return result.length > 0;
  }

  // Blocked Times
  async getBlockedTimes(userId: string): Promise<BlockedTime[]> {
    const result = await db.select().from(blockedTimes).where(eq(blockedTimes.userId, userId));
    return result;
  }

  async getBlockedTimesByDate(date: Date, userId: string): Promise<BlockedTime[]> {
    const result = await db.select().from(blockedTimes).where(eq(blockedTimes.userId, userId));
    const targetDate = date.toISOString().split('T')[0];
    return result.filter(blockedTime => {
      const blockedDate = new Date(blockedTime.date).toISOString().split('T')[0];
      return blockedDate === targetDate;
    });
  }

  async createBlockedTime(insertBlockedTime: InsertBlockedTime, userId: string): Promise<BlockedTime> {
    const [blocked] = await db
      .insert(blockedTimes)
      .values({
        userId: userId,
        date: insertBlockedTime.date,
        startTime: insertBlockedTime.startTime,
        endTime: insertBlockedTime.endTime,
        reason: insertBlockedTime.reason ?? null
      })
      .returning();
    return blocked;
  }

  async deleteBlockedTime(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(blockedTimes).where(
      and(eq(blockedTimes.id, id), eq(blockedTimes.userId, userId))
    );
    return (result.rowCount ?? 0) > 0;
  }

  // Notification Read Status operations
  async getNotificationStatus(userId: string, appointmentId: number): Promise<NotificationReadStatus | undefined> {
    const [status] = await db
      .select()
      .from(notificationReadStatus)
      .where(and(
        eq(notificationReadStatus.userId, userId),
        eq(notificationReadStatus.appointmentId, appointmentId)
      ));
    return status;
  }

  async markNotificationAsRead(userId: string, appointmentId: number): Promise<NotificationReadStatus> {
    const existing = await this.getNotificationStatus(userId, appointmentId);
    
    if (existing) {
      const [updated] = await db
        .update(notificationReadStatus)
        .set({ isRead: true, updatedAt: new Date() })
        .where(and(
          eq(notificationReadStatus.userId, userId),
          eq(notificationReadStatus.appointmentId, appointmentId)
        ))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(notificationReadStatus)
        .values({
          userId,
          appointmentId,
          isRead: true,
          isDeleted: false
        })
        .returning();
      return created;
    }
  }

  async markNotificationAsDeleted(userId: string, appointmentId: number): Promise<NotificationReadStatus> {
    const existing = await this.getNotificationStatus(userId, appointmentId);
    
    if (existing) {
      const [updated] = await db
        .update(notificationReadStatus)
        .set({ isDeleted: true, updatedAt: new Date() })
        .where(and(
          eq(notificationReadStatus.userId, userId),
          eq(notificationReadStatus.appointmentId, appointmentId)
        ))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(notificationReadStatus)
        .values({
          userId,
          appointmentId,
          isRead: false,
          isDeleted: true
        })
        .returning();
      return created;
    }
  }

  async getNotificationStatuses(userId: string): Promise<NotificationReadStatus[]> {
    return await db
      .select()
      .from(notificationReadStatus)
      .where(eq(notificationReadStatus.userId, userId));
  }

  // Admin operations
  async getAllUsers(): Promise<User[]> {
    const result = await db.select().from(users).orderBy(asc(users.createdAt));
    return result;
  }

  async deleteUser(id: string): Promise<boolean> {
    try {
      // Delete related data first
      await db.delete(appointments).where(eq(appointments.userId, id));
      await db.delete(services).where(eq(services.userId, id));
      await db.delete(availability).where(eq(availability.userId, id));
      await db.delete(blockedTimes).where(eq(blockedTimes.userId, id));
      await db.delete(notificationReadStatus).where(eq(notificationReadStatus.userId, id));
      
      // Delete the user
      const result = await db.delete(users).where(eq(users.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting user:", error);
      return false;
    }
  }
}

export const storage = new DatabaseStorage();