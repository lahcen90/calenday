import nodemailer from 'nodemailer';
import type { Appointment, Service, User } from '@shared/schema';

// Create transporter using Resend SMTP
const transporter = nodemailer.createTransport({
  host: 'smtp.resend.com',
  port: 2465,
  secure: true, // Use SSL
  auth: {
    user: 'resend',
    pass: 're_4KDqPDji_2EGovcbe9NSGZwwTyDhfJ5Ah'
  }
});

// Verify transporter configuration
transporter.verify((error: any, success: any) => {
  if (error) {
    console.error('Email transporter configuration error:', error);
  } else {
    console.log('Email server is ready to send messages');
  }
});

interface BookingEmailData {
  appointment: Appointment;
  service: Service;
  provider: User;
  customerEmail: string;
  customerName: string;
}

// Send booking confirmation email to customer
export async function sendBookingConfirmationToCustomer(data: BookingEmailData) {
  const { appointment, service, provider, customerEmail, customerName } = data;
  
  // Check if email notifications are enabled for the provider
  if (!provider.emailNotificationsEnabled) {
    console.log('Email notifications disabled for provider:', provider.id);
    return;
  }
  
  const appointmentDate = new Date(appointment.appointmentDate);
  
  // Format date and time in the appointment's timezone if specified
  const timeZone = appointment.timezone || 'UTC';
  const formattedDate = appointmentDate.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    timeZone: timeZone
  });
  const formattedTime = appointmentDate.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
    timeZone: timeZone
  });

  const companyName = provider.companyName || `${provider.firstName} ${provider.lastName}`;

  const mailOptions = {
    from: 'calenday@calenday.io',
    to: customerEmail,
    subject: `Appointment Confirmation - ${service.name}`,
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Appointment Confirmation</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .appointment-details { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #667eea; }
          .detail-row { display: flex; justify-content: space-between; margin: 10px 0; padding: 8px 0; border-bottom: 1px solid #eee; }
          .label { font-weight: bold; color: #555; }
          .value { color: #333; }
          .footer { text-align: center; margin-top: 30px; padding: 20px; color: #666; font-size: 14px; }
          .btn { display: inline-block; background: #667eea; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 10px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Appointment Confirmed!</h1>
            <p>Thank you for booking with ${companyName}</p>
          </div>
          
          <div class="content">
            <p>Dear ${customerName},</p>
            <p>Your appointment has been successfully confirmed. Here are the details:</p>
            
            <div class="appointment-details">
              <h3>Appointment Details</h3>
              <div class="detail-row">
                <span class="label">Service:</span>
                <span class="value">${service.name}</span>
              </div>
              <div class="detail-row">
                <span class="label">Date:</span>
                <span class="value">${formattedDate}</span>
              </div>
              <div class="detail-row">
                <span class="label">Time:</span>
                <span class="value">${formattedTime} ${appointment.timezone || ''}</span>
              </div>
              <div class="detail-row">
                <span class="label">Duration:</span>
                <span class="value">${service.duration} minutes</span>
              </div>
              <div class="detail-row">
                <span class="label">Provider:</span>
                <span class="value">${companyName}</span>
              </div>
              ${appointment.notes ? `
              <div class="detail-row">
                <span class="label">Notes:</span>
                <span class="value">${appointment.notes}</span>
              </div>
              ` : ''}
            </div>

            ${provider.whatsNextMessage ? `
            <h3>What's Next?</h3>
            <div style="white-space: pre-line; background: white; padding: 15px; border-radius: 6px; border-left: 4px solid #667eea;">
              ${provider.whatsNextMessage}
            </div>
            ` : `
            <h3>What's Next?</h3>
            <ul>
              <li>Please arrive 5-10 minutes before your appointment time</li>
              <li>If you need to reschedule or cancel, please contact us in advance</li>
            </ul>
            `}

            <p>If you have any questions, please don't hesitate to contact us.</p>
          </div>
          
          <div class="footer">
            <p>This is an automated confirmation email from Calenday</p>
            <p>© ${new Date().getFullYear()} Calenday. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`Booking confirmation email sent to customer: ${customerEmail}`);
  } catch (error) {
    console.error('Error sending booking confirmation email to customer:', error);
    throw error;
  }
}

// Send booking notification email to provider
export async function sendBookingNotificationToProvider(data: BookingEmailData) {
  const { appointment, service, provider, customerEmail, customerName } = data;
  
  // Check if email notifications are enabled for the provider
  if (!provider.emailNotificationsEnabled) {
    console.log('Email notifications disabled for provider:', provider.id);
    return;
  }
  
  // Skip if provider has no email
  if (!provider.email) {
    console.warn('Provider has no email address, skipping notification');
    return;
  }
  
  const appointmentDate = new Date(appointment.appointmentDate);
  
  // Format date and time in the appointment's timezone if specified
  const timeZone = appointment.timezone || 'UTC';
  const formattedDate = appointmentDate.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    timeZone: timeZone
  });
  const formattedTime = appointmentDate.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
    timeZone: timeZone
  });

  const mailOptions = {
    from: 'calenday@calenday.io',
    to: provider.email,
    subject: `New Booking: ${service.name} - ${formattedDate}`,
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>New Booking Notification</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #48bb78 0%, #38a169 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .appointment-details { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #48bb78; }
          .detail-row { display: flex; justify-content: space-between; margin: 10px 0; padding: 8px 0; border-bottom: 1px solid #eee; }
          .label { font-weight: bold; color: #555; }
          .value { color: #333; }
          .footer { text-align: center; margin-top: 30px; padding: 20px; color: #666; font-size: 14px; }
          .btn { display: inline-block; background: #48bb78; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 10px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>New Booking Received!</h1>
            <p>You have a new appointment booking</p>
          </div>
          
          <div class="content">
            <p>Hello ${provider.firstName || 'Provider'},</p>
            <p>You have received a new booking through your Calenday scheduling system.</p>
            
            <div class="appointment-details">
              <h3>Booking Details</h3>
              <div class="detail-row">
                <span class="label">Customer:</span>
                <span class="value">${customerName}</span>
              </div>
              <div class="detail-row">
                <span class="label">Email:</span>
                <span class="value">${customerEmail}</span>
              </div>
              ${appointment.clientPhone ? `
              <div class="detail-row">
                <span class="label">Phone:</span>
                <span class="value">${appointment.clientPhone}</span>
              </div>
              ` : ''}
              <div class="detail-row">
                <span class="label">Service:</span>
                <span class="value">${service.name}</span>
              </div>
              <div class="detail-row">
                <span class="label">Date:</span>
                <span class="value">${formattedDate}</span>
              </div>
              <div class="detail-row">
                <span class="label">Time:</span>
                <span class="value">${formattedTime} ${appointment.timezone || ''}</span>
              </div>
              <div class="detail-row">
                <span class="label">Duration:</span>
                <span class="value">${service.duration} minutes</span>
              </div>
              ${appointment.notes ? `
              <div class="detail-row">
                <span class="label">Customer Notes:</span>
                <span class="value">${appointment.notes}</span>
              </div>
              ` : ''}
            </div>

            <p>Please prepare for this appointment and contact the customer if you need any additional information.</p>
          </div>
          
          <div class="footer">
            <p>This is an automated notification from Calenday</p>
            <p>© ${new Date().getFullYear()} Calenday. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`Booking notification email sent to provider: ${provider.email}`);
  } catch (error) {
    console.error('Error sending booking notification email to provider:', error);
    throw error;
  }
}

// Send booking confirmation email when appointment is confirmed by provider
export async function sendBookingConfirmedEmail(data: BookingEmailData) {
  const { appointment, service, provider, customerEmail, customerName } = data;
  
  // Check if email notifications are enabled for the provider
  if (!provider.emailNotificationsEnabled) {
    console.log('Email notifications disabled for provider:', provider.id);
    return;
  }
  
  const appointmentDate = new Date(appointment.appointmentDate);
  
  // Format date and time in the appointment's timezone if specified
  const timeZone = appointment.timezone || 'UTC';
  const formattedDate = appointmentDate.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    timeZone: timeZone
  });
  const formattedTime = appointmentDate.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
    timeZone: timeZone
  });

  const companyName = provider.companyName || `${provider.firstName} ${provider.lastName}`;

  const mailOptions = {
    from: 'calenday@calenday.io',
    to: customerEmail,
    subject: `Appointment Confirmed - ${service.name}`,
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Appointment Confirmed</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #48bb78 0%, #38a169 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .appointment-details { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #48bb78; }
          .detail-row { display: flex; justify-content: space-between; margin: 10px 0; padding: 8px 0; border-bottom: 1px solid #eee; }
          .label { font-weight: bold; color: #555; }
          .value { color: #333; }
          .footer { text-align: center; margin-top: 30px; padding: 20px; color: #666; font-size: 14px; }
          .confirmed-badge { background: #48bb78; color: white; padding: 8px 16px; border-radius: 20px; font-weight: bold; display: inline-block; margin: 10px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>✅ Appointment Confirmed!</h1>
            <p>Your appointment with ${companyName} has been confirmed</p>
          </div>
          
          <div class="content">
            <p>Dear ${customerName},</p>
            <p>Great news! Your appointment has been <strong>confirmed</strong> by ${companyName}.</p>
            
            <div class="confirmed-badge">CONFIRMED</div>
            
            <div class="appointment-details">
              <h3>Confirmed Appointment Details</h3>
              <div class="detail-row">
                <span class="label">Service:</span>
                <span class="value">${service.name}</span>
              </div>
              <div class="detail-row">
                <span class="label">Date:</span>
                <span class="value">${formattedDate}</span>
              </div>
              <div class="detail-row">
                <span class="label">Time:</span>
                <span class="value">${formattedTime} ${appointment.timezone || ''}</span>
              </div>
              <div class="detail-row">
                <span class="label">Duration:</span>
                <span class="value">${service.duration} minutes</span>
              </div>
              <div class="detail-row">
                <span class="label">Provider:</span>
                <span class="value">${companyName}</span>
              </div>
              <div class="detail-row">
                <span class="label">Status:</span>
                <span class="value" style="color: #48bb78; font-weight: bold;">CONFIRMED</span>
              </div>
            </div>

            ${provider.whatsNextMessage ? `
            <h3>What's Next?</h3>
            <div style="white-space: pre-line; background: white; padding: 15px; border-radius: 6px; border-left: 4px solid #48bb78;">
              ${provider.whatsNextMessage}
            </div>
            ` : `
            <h3>Important Reminders:</h3>
            <ul>
              <li>Your appointment is now confirmed and reserved for you</li>
              <li>Please arrive 5-10 minutes before your appointment time</li>
              <li>If you need to reschedule or cancel, please contact us as soon as possible</li>
            </ul>
            `}

            <p>We look forward to seeing you at your confirmed appointment!</p>
          </div>
          
          <div class="footer">
            <p>This is an automated confirmation email from Calenday</p>
            <p>© ${new Date().getFullYear()} Calenday. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`Booking confirmed email sent to customer: ${customerEmail}`);
  } catch (error) {
    console.error('Error sending booking confirmed email to customer:', error);
    throw error;
  }
}

// Send appointment cancelled email to customer
export async function sendBookingCancelledEmail(data: BookingEmailData) {
  const { appointment, service, provider, customerEmail, customerName } = data;
  
  // Check if email notifications are enabled for the provider
  if (!provider.emailNotificationsEnabled) {
    console.log('Email notifications disabled for provider:', provider.id);
    return;
  }
  
  const appointmentDate = new Date(appointment.appointmentDate);
  
  // Format date and time in the appointment's timezone if specified
  const timeZone = appointment.timezone || 'UTC';
  const formattedDate = appointmentDate.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    timeZone: timeZone
  });
  const formattedTime = appointmentDate.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
    timeZone: timeZone
  });

  const companyName = provider.companyName || `${provider.firstName} ${provider.lastName}`;

  const mailOptions = {
    from: 'calenday@calenday.io',
    to: customerEmail,
    subject: `Appointment Cancelled - ${service.name}`,
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Appointment Cancelled</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #e53e3e 0%, #c53030 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .appointment-details { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #e53e3e; }
          .detail-row { display: flex; justify-content: space-between; margin: 10px 0; padding: 8px 0; border-bottom: 1px solid #eee; }
          .label { font-weight: bold; color: #555; }
          .value { color: #333; }
          .footer { text-align: center; margin-top: 30px; padding: 20px; color: #666; font-size: 14px; }
          .cancelled-badge { background: #e53e3e; color: white; padding: 8px 16px; border-radius: 20px; font-weight: bold; display: inline-block; margin: 10px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>❌ Appointment Cancelled</h1>
            <p>Your appointment with ${companyName} has been cancelled</p>
          </div>
          
          <div class="content">
            <p>Dear ${customerName},</p>
            <p>We regret to inform you that your appointment has been <strong>cancelled</strong> by ${companyName}.</p>
            
            <div class="cancelled-badge">CANCELLED</div>
            
            <div class="appointment-details">
              <h3>Cancelled Appointment Details</h3>
              <div class="detail-row">
                <span class="label">Service:</span>
                <span class="value">${service.name}</span>
              </div>
              <div class="detail-row">
                <span class="label">Date:</span>
                <span class="value">${formattedDate}</span>
              </div>
              <div class="detail-row">
                <span class="label">Time:</span>
                <span class="value">${formattedTime} ${appointment.timezone || ''}</span>
              </div>
              <div class="detail-row">
                <span class="label">Duration:</span>
                <span class="value">${service.duration} minutes</span>
              </div>
              <div class="detail-row">
                <span class="label">Provider:</span>
                <span class="value">${companyName}</span>
              </div>
              <div class="detail-row">
                <span class="label">Status:</span>
                <span class="value" style="color: #e53e3e; font-weight: bold;">CANCELLED</span>
              </div>
            </div>

            ${provider.whatsNextMessage ? `
            <h3>What's Next?</h3>
            <div style="white-space: pre-line; background: white; padding: 15px; border-radius: 6px; border-left: 4px solid #e53e3e;">
              ${provider.whatsNextMessage}
            </div>
            ` : `
            <h3>What's Next:</h3>
            <ul>
              <li>You can book a new appointment at your convenience</li>
              <li>Contact us if you have any questions about the cancellation</li>
              <li>We apologize for any inconvenience this may have caused</li>
            </ul>
            `}

            <p>We appreciate your understanding and look forward to serving you in the future.</p>
          </div>
          
          <div class="footer">
            <p>This is an automated notification email from Calenday</p>
            <p>© ${new Date().getFullYear()} Calenday. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`Booking cancelled email sent to customer: ${customerEmail}`);
  } catch (error) {
    console.error('Error sending booking cancelled email to customer:', error);
    throw error;
  }
}

// Send appointment completed email to customer
export async function sendBookingCompletedEmail(data: BookingEmailData) {
  const { appointment, service, provider, customerEmail, customerName } = data;
  
  // Check if email notifications are enabled for the provider
  if (!provider.emailNotificationsEnabled) {
    console.log('Email notifications disabled for provider:', provider.id);
    return;
  }
  
  const appointmentDate = new Date(appointment.appointmentDate);
  
  // Format date and time in the appointment's timezone if specified
  const timeZone = appointment.timezone || 'UTC';
  const formattedDate = appointmentDate.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    timeZone: timeZone
  });
  const formattedTime = appointmentDate.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
    timeZone: timeZone
  });

  const companyName = provider.companyName || `${provider.firstName} ${provider.lastName}`;

  const mailOptions = {
    from: 'calenday@calenday.io',
    to: customerEmail,
    subject: `Appointment Completed - ${service.name}`,
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Appointment Completed</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #38b2ac 0%, #319795 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .appointment-details { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #38b2ac; }
          .detail-row { display: flex; justify-content: space-between; margin: 10px 0; padding: 8px 0; border-bottom: 1px solid #eee; }
          .label { font-weight: bold; color: #555; }
          .value { color: #333; }
          .footer { text-align: center; margin-top: 30px; padding: 20px; color: #666; font-size: 14px; }
          .completed-badge { background: #38b2ac; color: white; padding: 8px 16px; border-radius: 20px; font-weight: bold; display: inline-block; margin: 10px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>✅ Appointment Completed</h1>
            <p>Your appointment with ${companyName} has been completed</p>
          </div>
          
          <div class="content">
            <p>Dear ${customerName},</p>
            <p>Thank you for choosing ${companyName}! Your appointment has been successfully <strong>completed</strong>.</p>
            
            <div class="completed-badge">COMPLETED</div>
            
            <div class="appointment-details">
              <h3>Completed Appointment Details</h3>
              <div class="detail-row">
                <span class="label">Service:</span>
                <span class="value">${service.name}</span>
              </div>
              <div class="detail-row">
                <span class="label">Date:</span>
                <span class="value">${formattedDate}</span>
              </div>
              <div class="detail-row">
                <span class="label">Time:</span>
                <span class="value">${formattedTime} ${appointment.timezone || ''}</span>
              </div>
              <div class="detail-row">
                <span class="label">Duration:</span>
                <span class="value">${service.duration} minutes</span>
              </div>
              <div class="detail-row">
                <span class="label">Provider:</span>
                <span class="value">${companyName}</span>
              </div>
              <div class="detail-row">
                <span class="label">Status:</span>
                <span class="value" style="color: #38b2ac; font-weight: bold;">COMPLETED</span>
              </div>
            </div>

            ${provider.whatsNextMessage ? `
            <h3>What's Next?</h3>
            <div style="white-space: pre-line; background: white; padding: 15px; border-radius: 6px; border-left: 4px solid #38b2ac;">
              ${provider.whatsNextMessage}
            </div>
            ` : `
            <h3>Thank You!</h3>
            <ul>
              <li>We hope you had a great experience with our service</li>
              <li>Feel free to book another appointment anytime</li>
              <li>Contact us if you have any questions or feedback</li>
              <li>We appreciate your business and look forward to serving you again</li>
            </ul>
            `}

            <p>Thank you for choosing ${companyName}!</p>
          </div>
          
          <div class="footer">
            <p>This is an automated completion notification from Calenday</p>
            <p>© ${new Date().getFullYear()} Calenday. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`Booking completed email sent to customer: ${customerEmail}`);
  } catch (error) {
    console.error('Error sending booking completed email to customer:', error);
    throw error;
  }
}

// Send appointment reminder email to customer
export async function sendReminderEmail(data: BookingEmailData) {
  const { appointment, service, provider, customerEmail, customerName } = data;
  
  // Check if email notifications are enabled for the provider
  if (!provider.emailNotificationsEnabled) {
    console.log('Email notifications disabled for provider:', provider.id);
    return;
  }
  
  const appointmentDate = new Date(appointment.appointmentDate);
  
  // Format date and time in the appointment's timezone if specified
  const timeZone = appointment.timezone || 'UTC';
  const formattedDate = appointmentDate.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    timeZone: timeZone
  });
  const formattedTime = appointmentDate.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
    timeZone: timeZone
  });

  const companyName = provider.companyName || `${provider.firstName} ${provider.lastName}`;

  const mailOptions = {
    from: 'calenday@calenday.io',
    to: customerEmail,
    subject: `Reminder: Upcoming Appointment - ${service.name}`,
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Appointment Reminder</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .appointment-details { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #4299e1; }
          .detail-row { display: flex; justify-content: space-between; margin: 10px 0; padding: 8px 0; border-bottom: 1px solid #eee; }
          .label { font-weight: bold; color: #555; }
          .value { color: #333; }
          .footer { text-align: center; margin-top: 30px; padding: 20px; color: #666; font-size: 14px; }
          .reminder-badge { background: #4299e1; color: white; padding: 8px 16px; border-radius: 20px; font-weight: bold; display: inline-block; margin: 10px 0; }
          .urgent { background: #f56565; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🔔 Appointment Reminder</h1>
            <p>Don't forget about your upcoming appointment with ${companyName}</p>
          </div>
          
          <div class="content">
            <p>Dear ${customerName},</p>
            <p>This is a friendly reminder about your upcoming appointment.</p>
            
            <div class="reminder-badge">REMINDER</div>
            
            <div class="appointment-details">
              <h3>Appointment Details</h3>
              <div class="detail-row">
                <span class="label">Service:</span>
                <span class="value">${service.name}</span>
              </div>
              <div class="detail-row">
                <span class="label">Date:</span>
                <span class="value">${formattedDate}</span>
              </div>
              <div class="detail-row">
                <span class="label">Time:</span>
                <span class="value">${formattedTime} ${appointment.timezone || ''}</span>
              </div>
              <div class="detail-row">
                <span class="label">Duration:</span>
                <span class="value">${service.duration} minutes</span>
              </div>
              <div class="detail-row">
                <span class="label">Provider:</span>
                <span class="value">${companyName}</span>
              </div>
              <div class="detail-row">
                <span class="label">Status:</span>
                <span class="value" style="color: #4299e1; font-weight: bold;">${appointment.status.toUpperCase()}</span>
              </div>
            </div>

            ${provider.whatsNextMessage ? `
            <h3>What's Next?</h3>
            <div style="white-space: pre-line; background: white; padding: 15px; border-radius: 6px; border-left: 4px solid #4299e1;">
              ${provider.whatsNextMessage}
            </div>
            ` : `
            <h3>Important Reminders:</h3>
            <ul>
              <li>Please arrive 5-10 minutes before your scheduled time</li>
              <li>Contact us if you need to reschedule or cancel</li>
              <li>We look forward to seeing you soon!</li>
            </ul>
            `}

            <p>Thank you for choosing ${companyName}!</p>
          </div>
          
          <div class="footer">
            <p>This is an automated reminder email from Calenday</p>
            <p>© ${new Date().getFullYear()} Calenday. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`Appointment reminder email sent to customer: ${customerEmail}`);
  } catch (error) {
    console.error('Error sending reminder email to customer:', error);
    throw error;
  }
}

// Send both customer confirmation and provider notification
export async function sendBookingEmails(data: BookingEmailData) {
  try {
    await Promise.all([
      sendBookingConfirmationToCustomer(data),
      sendBookingNotificationToProvider(data)
    ]);
    console.log('All booking emails sent successfully');
  } catch (error) {
    console.error('Error sending booking emails:', error);
    throw error;
  }
}

export async function sendVerificationEmail(email: string, token: string) {
  const verificationUrl = `${process.env.REPLIT_DEV_DOMAIN || 'http://localhost:5000'}/verify-email?token=${token}`;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #333;">Email Verification</h2>
      <p>Thank you for registering! Please verify your email address by clicking the link below:</p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="${verificationUrl}" 
           style="background-color: #3B82F6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
          Verify Email Address
        </a>
      </div>
      <p style="color: #666; font-size: 14px;">
        If you can't click the button, copy and paste this link into your browser:<br>
        <a href="${verificationUrl}">${verificationUrl}</a>
      </p>
      <p style="color: #666; font-size: 14px;">
        This verification link will expire in 24 hours.
      </p>
    </div>
  `;

  if (transporter) {
    await transporter.sendMail({
      from: '"Calenday" <calenday@calenday.io>',
      to: email,
      subject: "Verify your email address",
      html,
    });
  }
}

export async function sendPasswordResetEmail(email: string, token: string) {
  const resetUrl = `${process.env.REPLIT_DEV_DOMAIN || 'http://localhost:5000'}/reset-password?token=${token}`;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #333;">Password Reset</h2>
      <p>You requested a password reset. Click the link below to set a new password:</p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="${resetUrl}" 
           style="background-color: #EF4444; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
          Reset Password
        </a>
      </div>
      <p style="color: #666; font-size: 14px;">
        If you can't click the button, copy and paste this link into your browser:<br>
        <a href="${resetUrl}">${resetUrl}</a>
      </p>
      <p style="color: #666; font-size: 14px;">
        This reset link will expire in 1 hour. If you didn't request this, please ignore this email.
      </p>
    </div>
  `;

  if (transporter) {
    await transporter.sendMail({
      from: '"Calenday" <calenday@calenday.io>',
      to: email,
      subject: "Password Reset Request",
      html,
    });
  }
}