import { storage } from './storage';
import { sendReminderEmail } from './email';

interface ReminderJob {
  appointmentId: number;
  scheduledTime: Date;
}

class ReminderService {
  private reminderJobs: Map<number, NodeJS.Timeout> = new Map();

  // Schedule a reminder for an appointment
  async scheduleReminder(appointmentId: number, userId: string) {
    try {
      // Get user's reminder preferences
      const user = await storage.getUser(userId);
      if (!user || !user.emailReminders) {
        return; // User has disabled email reminders
      }

      // Get appointment details
      const appointment = await storage.getAppointment(appointmentId, userId);
      if (!appointment) {
        return;
      }

      // Calculate reminder time
      const reminderTime = user.reminderTime || 60;
      const reminderUnit = user.reminderUnit || 'minutes';
      
      let reminderOffset = reminderTime;
      switch (reminderUnit) {
        case 'hours':
          reminderOffset = reminderTime * 60;
          break;
        case 'days':
          reminderOffset = reminderTime * 60 * 24;
          break;
        case 'minutes':
        default:
          reminderOffset = reminderTime;
          break;
      }

      // Calculate when to send the reminder
      const appointmentDate = new Date(appointment.appointmentDate);
      const reminderDate = new Date(appointmentDate.getTime() - (reminderOffset * 60 * 1000));
      
      // Don't schedule if reminder time is in the past
      if (reminderDate <= new Date()) {
        console.log(`Reminder time for appointment ${appointmentId} is in the past, skipping`);
        return;
      }

      // Cancel existing reminder if any
      this.cancelReminder(appointmentId);

      // Schedule the reminder
      const delay = reminderDate.getTime() - Date.now();
      const timeoutId = setTimeout(async () => {
        await this.sendReminder(appointmentId, userId);
        this.reminderJobs.delete(appointmentId);
      }, delay);

      this.reminderJobs.set(appointmentId, timeoutId);
      
      console.log(`Reminder scheduled for appointment ${appointmentId} at ${reminderDate.toISOString()}`);
    } catch (error) {
      console.error(`Error scheduling reminder for appointment ${appointmentId}:`, error);
    }
  }

  // Cancel a scheduled reminder
  cancelReminder(appointmentId: number) {
    const existingTimeout = this.reminderJobs.get(appointmentId);
    if (existingTimeout) {
      clearTimeout(existingTimeout);
      this.reminderJobs.delete(appointmentId);
      console.log(`Cancelled reminder for appointment ${appointmentId}`);
    }
  }

  // Send the actual reminder email
  private async sendReminder(appointmentId: number, userId: string) {
    try {
      const appointment = await storage.getAppointment(appointmentId, userId);
      if (!appointment || appointment.status === 'cancelled') {
        return; // Don't send reminder for cancelled appointments
      }

      const service = await storage.getService(appointment.serviceId);
      const provider = await storage.getUser(userId);

      if (service && provider && appointment.clientEmail && appointment.clientName) {
        await sendReminderEmail({
          appointment,
          service,
          provider,
          customerEmail: appointment.clientEmail,
          customerName: appointment.clientName,
        });
      }
    } catch (error) {
      console.error(`Error sending reminder for appointment ${appointmentId}:`, error);
    }
  }

  // Reschedule all reminders for a user (useful when user updates preferences)
  async rescheduleUserReminders(userId: string) {
    try {
      const appointments = await storage.getAppointments(userId);
      const futureAppointments = appointments.filter(apt => 
        new Date(apt.appointmentDate) > new Date() && 
        apt.status !== 'cancelled'
      );

      for (const appointment of futureAppointments) {
        await this.scheduleReminder(appointment.id, userId);
      }
    } catch (error) {
      console.error(`Error rescheduling reminders for user ${userId}:`, error);
    }
  }

  // Initialize reminders for all future appointments on server start
  async initializeReminders() {
    try {
      console.log('Initializing reminder service...');
      // This would typically query all users and their future appointments
      // For now, we'll schedule reminders as appointments are created/updated
    } catch (error) {
      console.error('Error initializing reminder service:', error);
    }
  }
}

export const reminderService = new ReminderService();