import { storage } from "./storage";

async function seedDatabase() {
  console.log("Seeding database...");
  
  try {
    // Create default services
    await storage.createService({
      name: "Consultation",
      description: "Initial consultation session",
      duration: 60,
      price: "150.00",
      isActive: true,
    });
    
    await storage.createService({
      name: "Follow-up",
      description: "Follow-up appointment",
      duration: 30,
      price: "75.00",
      isActive: true,
    });
    
    await storage.createService({
      name: "Assessment",
      description: "Comprehensive assessment",
      duration: 90,
      price: "200.00",
      isActive: true,
    });

    // Create default availability (Monday-Friday, 9 AM - 5 PM)
    for (let day = 1; day <= 5; day++) {
      await storage.createAvailability({
        dayOfWeek: day,
        startTime: "09:00",
        endTime: "17:00",
        isAvailable: true,
      });
    }
    
    console.log("Database seeded successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

export { seedDatabase };

// Run seeding when this file is executed directly
seedDatabase().then(() => {
  console.log("Seeding complete");
  process.exit(0);
}).catch(error => {
  console.error("Seeding failed:", error);
  process.exit(1);
});