import { db } from "./db";
import { services, availability } from "@shared/schema";
import { eq } from "drizzle-orm";

export async function seedUserData(userId: string) {
  // Check if user already has services
  const existingServices = await db.select().from(services).where(eq(services.userId, userId));
  
  if (existingServices.length === 0) {
    // Create default service for new user
    await db.insert(services).values([
      {
        userId,
        name: "Consultation",
        description: "General consultation service",
        duration: 60,
        isActive: true,
      }
    ]);

    // Create default availability (Monday to Friday, 9 AM to 5 PM)
    const defaultAvailability = [];
    for (let day = 1; day <= 5; day++) {
      defaultAvailability.push({
        userId,
        dayOfWeek: day,
        startTime: "09:00",
        endTime: "17:00",
        isAvailable: true,
      });
    }
    
    await db.insert(availability).values(defaultAvailability);
  }
}