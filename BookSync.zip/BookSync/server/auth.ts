import bcrypt from "bcryptjs";
import crypto from "crypto";
import { storage } from "./storage";
import { sendVerificationEmail, sendPasswordResetEmail } from "./email";
import type { RegisterUser, LoginUser } from "@shared/schema";

export class AuthService {
  async register(userData: RegisterUser): Promise<{ message: string; userId: string }> {
    // Check if user already exists
    const existingUser = await storage.getUserByEmail(userData.email);
    if (existingUser) {
      throw new Error("User already exists");
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(userData.password, 12);
    
    // Generate verification token
    const verificationToken = crypto.randomBytes(32).toString("hex");
    
    // Create user
    const user = await storage.createUser({
      id: userData.email, // Use email as ID for now
      email: userData.email,
      password: hashedPassword,
      firstName: userData.firstName,
      lastName: userData.lastName,
      emailVerified: false,
      emailVerificationToken: verificationToken,
    });

    // Send verification email
    await sendVerificationEmail(userData.email, verificationToken);

    return {
      message: "Registration successful. Please check your email to verify your account.",
      userId: user.id,
    };
  }

  async login(credentials: LoginUser): Promise<{ user: any; message: string }> {
    // Find user by email
    const user = await storage.getUserByEmail(credentials.email);
    if (!user || !user.password) {
      throw new Error("Invalid email or password");
    }

    // Check password
    const isValidPassword = await bcrypt.compare(credentials.password, user.password);
    if (!isValidPassword) {
      throw new Error("Invalid email or password");
    }

    // Check if email is verified
    if (!user.emailVerified) {
      throw new Error("Please verify your email before signing in");
    }

    // Return user without password
    const { password, emailVerificationToken, resetPasswordToken, ...userWithoutPassword } = user;
    
    return {
      user: userWithoutPassword,
      message: "Login successful",
    };
  }

  async verifyEmail(token: string): Promise<{ message: string }> {
    const user = await storage.getUserByVerificationToken(token);
    if (!user) {
      throw new Error("Invalid or expired verification token");
    }

    // Update user as verified
    await storage.verifyUserEmail(user.id);

    return { message: "Email verified successfully. You can now sign in." };
  }

  async requestPasswordReset(email: string): Promise<{ message: string }> {
    const user = await storage.getUserByEmail(email);
    if (!user) {
      // Don't reveal if email exists or not
      return { message: "If an account with that email exists, you will receive a password reset link." };
    }

    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString("hex");
    const resetExpires = new Date(Date.now() + 3600000); // 1 hour

    // Save reset token
    await storage.savePasswordResetToken(user.id, resetToken, resetExpires);

    // Send reset email
    await sendPasswordResetEmail(email, resetToken);

    return { message: "If an account with that email exists, you will receive a password reset link." };
  }

  async resetPassword(token: string, newPassword: string): Promise<{ message: string }> {
    const user = await storage.getUserByResetToken(token);
    if (!user || !user.resetPasswordExpires || user.resetPasswordExpires < new Date()) {
      throw new Error("Invalid or expired reset token");
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 12);

    // Update password and clear reset token
    await storage.updatePassword(user.id, hashedPassword);

    return { message: "Password reset successful. You can now sign in with your new password." };
  }
}

export const authService = new AuthService();