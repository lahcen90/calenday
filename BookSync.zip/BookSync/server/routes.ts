import type { Express, RequestHandler } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertAppointmentSchema, insertServiceSchema, insertAvailabilitySchema, insertBlockedTimeSchema, registerUserSchema, loginUserSchema, resetPasswordSchema, resetPasswordConfirmSchema } from "@shared/schema";
import { reminderService } from "./reminder-service";
import { authService } from "./auth";
import { createPaypalOrder, capturePaypalOrder, loadPaypalDefault } from "./paypal";
import { z } from "zod";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { format } from "date-fns";

// Simple session-based authentication
const isAuthenticated: RequestHandler = (req, res, next) => {
  if ((req.session as any)?.user) {
    // Set user information on request object for route handlers
    (req as any).user = {
      claims: {
        sub: (req.session as any).user.id
      }
    };
    return next();
  }
  return res.status(401).json({ message: "Unauthorized" });
};

// Optional authentication middleware - allows both authenticated users and guests
const optionalAuth: RequestHandler = (req, res, next) => {
  if ((req.session as any)?.user) {
    (req as any).user = {
      claims: {
        sub: (req.session as any).user.id
      }
    };
  }
  return next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session middleware
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: true,
    ttl: sessionTtl,
    tableName: "sessions",
  });

  app.use(session({
    secret: process.env.SESSION_SECRET || 'your-secret-key-change-in-production',
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false, // Set to true in production with HTTPS
      maxAge: sessionTtl,
    },
  }));

  // Authentication routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const validatedData = registerUserSchema.parse(req.body);
      const result = await authService.register(validatedData);
      res.status(201).json(result);
    } catch (error: any) {
      console.error("Registration error:", error);
      res.status(400).json({ message: error.message || "Registration failed" });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const validatedData = loginUserSchema.parse(req.body);
      const result = await authService.login(validatedData);
      
      // Set session
      (req.session as any).user = { id: result.user.id };
      
      res.json(result);
    } catch (error: any) {
      console.error("Login error:", error);
      res.status(400).json({ message: error.message || "Login failed" });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ message: "Logout failed" });
      }
      res.clearCookie('connect.sid');
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get('/api/auth/verify-email', async (req, res) => {
    try {
      const { token } = req.query;
      if (!token || typeof token !== 'string') {
        return res.status(400).json({ message: "Invalid verification token" });
      }
      
      const result = await authService.verifyEmail(token);
      res.json(result);
    } catch (error: any) {
      console.error("Email verification error:", error);
      res.status(400).json({ message: error.message || "Email verification failed" });
    }
  });

  app.post('/api/auth/forgot-password', async (req, res) => {
    try {
      const validatedData = resetPasswordSchema.parse(req.body);
      const result = await authService.requestPasswordReset(validatedData.email);
      res.json(result);
    } catch (error: any) {
      console.error("Password reset request error:", error);
      res.status(400).json({ message: error.message || "Password reset request failed" });
    }
  });

  app.post('/api/auth/reset-password', async (req, res) => {
    try {
      const validatedData = resetPasswordConfirmSchema.parse(req.body);
      const result = await authService.resetPassword(validatedData.token, validatedData.password);
      res.json(result);
    } catch (error: any) {
      console.error("Password reset error:", error);
      res.status(400).json({ message: error.message || "Password reset failed" });
    }
  });

  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if email is verified
      if (!user.emailVerified) {
        return res.status(401).json({ message: "Email not verified" });
      }
      
      // Seed default data for new users
      const { seedUserData } = await import('./user-seed');
      await seedUserData(user.id);
      
      // Remove sensitive fields
      const { password, emailVerificationToken, resetPasswordToken, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Admin routes
  app.get('/api/admin/users', async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      // Remove sensitive fields from response
      const sanitizedUsers = users.map(user => {
        const { password, emailVerificationToken, resetPasswordToken, resetPasswordExpires, ...safeUser } = user;
        return safeUser;
      });
      res.json(sanitizedUsers);
    } catch (error: any) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.delete('/api/admin/users/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      const success = await storage.deleteUser(userId);
      if (success) {
        res.json({ message: "User deleted successfully" });
      } else {
        res.status(500).json({ message: "Failed to delete user" });
      }
    } catch (error: any) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  app.post('/api/admin/login-as/:userId', async (req: any, res) => {
    try {
      const { userId } = req.params;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Create session for the target user
      req.session.user = {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
      };

      res.json({ 
        message: "Logged in as user successfully",
        user: {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
        }
      });
    } catch (error: any) {
      console.error("Error logging in as user:", error);
      res.status(500).json({ message: "Failed to login as user" });
    }
  });

  app.patch('/api/admin/users/:userId/email', async (req, res) => {
    try {
      const { userId } = req.params;
      const { email } = req.body;

      if (!email || !email.trim()) {
        return res.status(400).json({ message: "Email is required" });
      }

      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email.trim())) {
        return res.status(400).json({ message: "Invalid email format" });
      }

      // Check if email already exists for another user
      const existingUser = await storage.getUserByEmail(email.trim());
      if (existingUser && existingUser.id !== userId) {
        return res.status(400).json({ message: "Email already exists for another user" });
      }

      const updatedUser = await storage.updateUserProfile(userId, { email: email.trim() });
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({ message: "Email updated successfully", user: updatedUser });
    } catch (error: any) {
      console.error("Error updating user email:", error);
      res.status(500).json({ message: "Failed to update email" });
    }
  });

  // Profile routes
  app.patch('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { firstName, lastName, companyName, companyLogoUrl, companyWebsite, companyWebsiteEnabled, whatsNextMessage, emailNotificationsEnabled, emailReminders, reminderTime, reminderUnit, allowMultipleBookings, allowTimezoneSelection, defaultTimezone } = req.body;
      
      const updatedUser = await storage.updateUserProfile(userId, {
        firstName,
        lastName,
        companyName,
        companyLogoUrl,
        companyWebsite,
        companyWebsiteEnabled,
        whatsNextMessage,
        emailNotificationsEnabled,
        emailReminders,
        reminderTime,
        reminderUnit,
        allowMultipleBookings,
        allowTimezoneSelection,
        defaultTimezone,
      });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Reschedule reminders if notification preferences changed
      if (updatedUser.emailReminders !== undefined || updatedUser.reminderTime !== undefined || updatedUser.reminderUnit !== undefined) {
        try {
          await reminderService.rescheduleUserReminders(userId);
        } catch (reminderError) {
          console.error('Error rescheduling user reminders:', reminderError);
        }
      }
      
      // Update session with new data
      req.session.user = updatedUser;
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Get provider profile (public endpoint for guest booking)
  app.get('/api/provider/:providerId/profile', async (req, res) => {
    try {
      const { providerId } = req.params;
      const provider = await storage.getUser(providerId);
      
      if (!provider) {
        return res.status(404).json({ message: "Provider not found" });
      }
      
      // Return only public profile information
      const publicProfile = {
        id: provider.id,
        firstName: provider.firstName,
        lastName: provider.lastName,
        companyName: provider.companyName,
        companyLogoUrl: provider.companyLogoUrl,
        companyWebsite: provider.companyWebsite,
        companyWebsiteEnabled: provider.companyWebsiteEnabled,
        whatsNextMessage: provider.whatsNextMessage,
        subscriptionPlan: provider.subscriptionPlan,
        allowTimezoneSelection: provider.allowTimezoneSelection,
        defaultTimezone: provider.defaultTimezone,
      };
      
      res.json(publicProfile);
    } catch (error) {
      console.error("Error fetching provider profile:", error);
      res.status(500).json({ message: "Failed to fetch provider profile" });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });
  // Services
  app.get("/api/services", optionalAuth, async (req: any, res) => {
    try {
      // For guest access, return all active services
      // For authenticated users, return their own services
      if (req.user && req.user.claims) {
        const userId = req.user.claims.sub;
        let services = await storage.getServicesByUser(userId);
        
        // If user has no services, create default Consultation service
        if (services.length === 0) {
          const defaultService = await storage.createService({
            name: "Consultation",
            description: "General consultation service",
            duration: 60,
            isActive: true
          }, userId);
          services = [defaultService];
        }
        
        res.json(services);
      } else {
        // Guest access - return all active services from all users
        const services = await storage.getServices();
        res.json(services.filter(service => service.isActive));
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch services" });
    }
  });

  app.get("/api/services/provider/:userId", optionalAuth, async (req, res) => {
    try {
      const userId = decodeURIComponent(req.params.userId);
      const services = await storage.getServicesByUser(userId);
      const activeServices = services.filter(service => service.isActive);
      res.json(activeServices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch provider services" });
    }
  });

  app.get("/api/services/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const service = await storage.getService(id);
      if (!service) {
        return res.status(404).json({ message: "Service not found" });
      }
      res.json(service);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch service" });
    }
  });

  app.post("/api/services", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const serviceData = insertServiceSchema.parse(req.body);
      const service = await storage.createService(serviceData, userId);
      res.status(201).json(service);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid service data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create service" });
    }
  });

  app.patch("/api/services/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const updateData = insertServiceSchema.partial().parse(req.body);
      const service = await storage.updateService(id, updateData, userId);
      if (!service) {
        return res.status(404).json({ message: "Service not found" });
      }
      res.json(service);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid service data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update service" });
    }
  });

  app.delete("/api/services/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      
      // Check if service exists and belongs to user
      const service = await storage.getService(id);
      if (!service || service.userId !== userId) {
        return res.status(404).json({ message: "Service not found" });
      }
      
      // Instead of actual deletion, mark as inactive to preserve data integrity
      const updatedService = await storage.updateService(id, { isActive: false }, userId);
      if (!updatedService) {
        return res.status(404).json({ message: "Service not found" });
      }
      
      res.json({ message: "Service deactivated successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete service" });
    }
  });

  // Appointments
  app.get("/api/appointments", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { startDate, endDate } = req.query;
      
      if (startDate && endDate) {
        const start = new Date(startDate as string);
        const end = new Date(endDate as string);
        const appointments = await storage.getAppointmentsByDateRange(start, end, userId);
        res.json(appointments);
      } else {
        const appointments = await storage.getAppointments(userId);
        res.json(appointments);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  // Get appointments for a specific client
  app.get("/api/my-appointments", isAuthenticated, async (req: any, res) => {
    try {
      const clientId = req.user.claims.sub; // Use authenticated user's ID as clientId
      const appointments = await storage.getAppointmentsByClient(clientId);
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch client appointments" });
    }
  });

  app.get("/api/appointments/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const appointment = await storage.getAppointment(id, userId);
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      res.json(appointment);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch appointment" });
    }
  });

  app.post("/api/appointments", async (req: any, res) => {
    try {
      const appointmentData = insertAppointmentSchema.parse(req.body);
      
      // Support both authenticated users and guests with provider-specific bookings
      let bookingUserId;
      let targetProviderId;
      
      if (req.user && req.user.claims) {
        bookingUserId = req.user.claims.sub; // Authenticated user
        targetProviderId = appointmentData.providerId || bookingUserId; // Use specified provider or self
      } else {
        bookingUserId = appointmentData.clientEmail; // Guest booking using email as ID
        targetProviderId = appointmentData.providerId; // Must specify provider for guest bookings
      }
      
      // Decode URL-encoded provider ID to ensure proper matching
      if (targetProviderId) {
        targetProviderId = decodeURIComponent(targetProviderId);
      }
      
      if (!targetProviderId) {
        return res.status(400).json({ message: "Provider ID is required for guest bookings" });
      }
      
      // Check for conflicts
      const appointmentDate = new Date(appointmentData.appointmentDate);
      const service = await storage.getService(appointmentData.serviceId);
      if (!service) {
        return res.status(400).json({ message: "Invalid service ID" });
      }

      // Check if the appointment time is blocked
      const appointmentDateOnly = new Date(appointmentDate);
      appointmentDateOnly.setHours(0, 0, 0, 0);
      const blockedTimes = await storage.getBlockedTimesByDate(appointmentDateOnly, targetProviderId);
      
      const appointmentTime = appointmentDate.toTimeString().slice(0, 5);
      console.log(`Checking blocked times for ${appointmentTime} on ${appointmentDateOnly.toISOString().split('T')[0]}:`, {
        blockedTimesCount: blockedTimes.length,
        blockedTimes: blockedTimes.map(bt => ({ startTime: bt.startTime, endTime: bt.endTime, reason: bt.reason }))
      });
      
      const blockedSlot = blockedTimes.find((blocked: any) => {
        const isBlocked = appointmentTime >= blocked.startTime && appointmentTime < blocked.endTime;
        console.log(`Checking ${appointmentTime} against ${blocked.startTime}-${blocked.endTime}: ${isBlocked}`);
        return isBlocked;
      });

      if (blockedSlot) {
        return res.status(400).json({ 
          message: `This time slot is not available. Reason: ${blockedSlot.reason || 'Blocked by provider'}`,
          isBlocked: true,
          blockReason: blockedSlot.reason || 'Blocked by provider'
        });
      }

      // Check provider's multiple bookings setting
      const providerUser = await storage.getUser(targetProviderId);
      const allowMultipleBookings = providerUser?.allowMultipleBookings ?? false;
      
      // If multiple bookings are disabled, check for conflicts with existing appointments
      if (!allowMultipleBookings) {
        const startOfDay = new Date(appointmentDate);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(appointmentDate);
        endOfDay.setHours(23, 59, 59, 999);
        
        const existingAppointments = await storage.getAppointmentsByDateRange(startOfDay, endOfDay, targetProviderId);
        const activeAppointments = existingAppointments.filter(a => a.status !== "cancelled");
        
        const appointmentTime = appointmentDate.toTimeString().slice(0, 5);
        const hasConflict = activeAppointments.some(appointment => {
          const existingAppointmentStart = new Date(appointment.appointmentDate);
          const existingAppointmentDate = existingAppointmentStart.toISOString().split('T')[0];
          const requestedAppointmentDate = appointmentDate.toISOString().split('T')[0];
          
          if (existingAppointmentDate === requestedAppointmentDate) {
            const existingTime = existingAppointmentStart.toTimeString().slice(0, 5);
            return existingTime === appointmentTime;
          }
          return false;
        });
        
        if (hasConflict) {
          return res.status(400).json({ 
            message: "This time slot is already booked. Please select a different time.",
            isConflict: true
          });
        }
      }

      // Create appointment with proper user isolation - appointments belong to the target provider
      const appointmentWithUser = {
        ...appointmentData,
        userId: targetProviderId, // Appointment belongs to the provider
        clientId: bookingUserId, // Track who made the booking
      };
      
      // Remove providerId from the data as it's not part of the database schema
      delete (appointmentWithUser as any).providerId;
      
      const appointment = await storage.createAppointment(appointmentWithUser);
      
      // Send email notifications
      try {
        const { sendBookingEmails } = await import('./email');
        const provider = await storage.getUser(targetProviderId);
        
        if (provider) {
          await sendBookingEmails({
            appointment,
            service,
            provider,
            customerEmail: appointmentData.clientEmail,
            customerName: appointmentData.clientName
          });
        }
      } catch (emailError) {
        console.error('Failed to send booking emails:', emailError);
        // Don't fail the appointment creation if email fails
      }

      // Schedule reminder email if appointment is confirmed
      if (appointment.status === 'confirmed') {
        try {
          await reminderService.scheduleReminder(appointment.id, targetProviderId);
        } catch (reminderError) {
          console.error('Error scheduling reminder:', reminderError);
        }
      }
      
      res.status(201).json(appointment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid appointment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create appointment" });
    }
  });

  app.patch("/api/appointments/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const updateData = req.body;
      
      console.log("Updating appointment:", { id, userId, updateData });
      
      // If confirming appointment (status change to confirmed), check for blocked times
      if (updateData.status === 'confirmed') {
        const existingAppointment = await storage.getAppointment(id, userId);
        if (!existingAppointment) {
          return res.status(404).json({ message: "Appointment not found" });
        }

        // Check if the appointment time is blocked
        const appointmentDate = new Date(existingAppointment.appointmentDate);
        const appointmentDateOnly = new Date(appointmentDate);
        appointmentDateOnly.setHours(0, 0, 0, 0);
        const blockedTimes = await storage.getBlockedTimesByDate(appointmentDateOnly, userId);
        
        const appointmentTime = appointmentDate.toTimeString().slice(0, 5);
        const blockedSlot = blockedTimes.find((blocked: any) => {
          return appointmentTime >= blocked.startTime && appointmentTime < blocked.endTime;
        });

        if (blockedSlot) {
          return res.status(400).json({ 
            message: `Cannot confirm appointment during blocked time. Reason: ${blockedSlot.reason || 'Blocked by provider'}`,
            isBlocked: true,
            blockReason: blockedSlot.reason || 'Blocked by provider'
          });
        }
      }
      
      const appointment = await storage.updateAppointment(id, updateData, userId);
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      // Send status change email to customer
      if (updateData.status && ['confirmed', 'cancelled', 'completed'].includes(updateData.status)) {
        try {
          const service = await storage.getService(appointment.serviceId);
          const provider = await storage.getUser(userId);
          
          if (service && provider && appointment.clientEmail && appointment.clientName) {
            const emailData = {
              appointment,
              service,
              provider,
              customerEmail: appointment.clientEmail,
              customerName: appointment.clientName
            };

            if (updateData.status === 'confirmed') {
              const { sendBookingConfirmedEmail } = await import('./email');
              await sendBookingConfirmedEmail(emailData);
              
              // Schedule reminder email when appointment is confirmed
              try {
                await reminderService.scheduleReminder(appointment.id, userId);
              } catch (reminderError) {
                console.error('Error scheduling reminder:', reminderError);
              }
            } else if (updateData.status === 'cancelled') {
              const { sendBookingCancelledEmail } = await import('./email');
              await sendBookingCancelledEmail(emailData);
              
              // Cancel reminder when appointment is cancelled
              reminderService.cancelReminder(appointment.id);
            } else if (updateData.status === 'completed') {
              const { sendBookingCompletedEmail } = await import('./email');
              await sendBookingCompletedEmail(emailData);
              
              // Cancel reminder when appointment is completed
              reminderService.cancelReminder(appointment.id);
            }
          }
        } catch (emailError) {
          console.error('Error sending status change email:', emailError);
          // Don't fail the appointment update if email fails
        }
      }
      
      res.json(appointment);
    } catch (error) {
      console.error("Update appointment error:", error);
      res.status(500).json({ message: "Failed to update appointment", error: error instanceof Error ? error.message : String(error) });
    }
  });

  app.delete("/api/appointments/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteAppointment(id, userId);
      if (!deleted) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete appointment" });
    }
  });

  // Availability
  app.get("/api/availability", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const availability = await storage.getAvailability(userId);
      res.json(availability);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch availability" });
    }
  });

  app.post("/api/availability", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const availabilityData = insertAvailabilitySchema.parse(req.body);
      const availability = await storage.createAvailability(availabilityData, userId);
      res.status(201).json(availability);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid availability data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create availability" });
    }
  });

  // Available time slots for a specific date and provider
  app.get("/api/available-slots/:date/:providerId?", optionalAuth, async (req: any, res) => {
    try {
      const date = new Date(req.params.date);
      const dayOfWeek = date.getDay();
      const providerId = req.params.providerId;
      
      let targetUserId;
      
      if (providerId) {
        // Provider-specific booking link - decode URL-encoded provider ID
        targetUserId = decodeURIComponent(providerId);
      } else if (req.user && req.user.claims) {
        // Authenticated user - show their own availability
        targetUserId = req.user.claims.sub;
      } else {
        // General guest access - use first active provider
        const allServices = await storage.getServices();
        const firstActiveProvider = allServices.find(s => s.isActive);
        if (!firstActiveProvider) {
          return res.json([]);
        }
        targetUserId = firstActiveProvider.userId;
      }
      
      // Check if provider has services
      const userServices = await storage.getServicesByUser(targetUserId);
      if (userServices.length === 0) {
        return res.json([]);
      }
      
      // Get provider user data to check multiple bookings setting
      const providerUser = await storage.getUser(targetUserId);
      const allowMultipleBookings = providerUser?.allowMultipleBookings ?? false;
      
      // Get availability data for the target provider
      const availabilityData = await storage.getAvailability(targetUserId);
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      const appointmentsData = await storage.getAppointmentsByDateRange(startOfDay, endOfDay, targetUserId);
      const blockedTimesData = await storage.getBlockedTimesByDate(date, targetUserId);
      

      
      const dayAvailability = availabilityData.filter(a => a.dayOfWeek === dayOfWeek && a.isAvailable);
      
      if (dayAvailability.length === 0) {
        return res.json([]);
      }
      
      const activeAppointments = appointmentsData.filter(a => a.status !== "cancelled");
      
      // Generate available slots
      const slotsSet = new Set<string>();
      
      for (const availability of dayAvailability) {
        const [startHour, startMin] = availability.startTime.split(':').map(Number);
        const [endHour, endMin] = availability.endTime.split(':').map(Number);
        
        const startMinutes = startHour * 60 + startMin;
        const endMinutes = endHour * 60 + endMin;
        
        // Generate 30-minute slots
        for (let minutes = startMinutes; minutes < endMinutes; minutes += 30) {
          const slotHour = Math.floor(minutes / 60);
          const slotMin = minutes % 60;
          const slotTime = `${slotHour.toString().padStart(2, '0')}:${slotMin.toString().padStart(2, '0')}`;
          
          // Check if this slot conflicts with existing appointments or blocked times
          const slotStart = new Date(date);
          slotStart.setHours(slotHour, slotMin, 0, 0);
          
          // Check for appointment conflicts - if multiple bookings are disabled, hide booked slots
          let hasConflict = false;
          if (!allowMultipleBookings) {
            hasConflict = activeAppointments.some(appointment => {
              const appointmentStart = new Date(appointment.appointmentDate);
              // Check if appointment is on the same date
              const appointmentDate = appointmentStart.toISOString().split('T')[0];
              const slotDate = date.toISOString().split('T')[0];
              
              if (appointmentDate === slotDate) {
                // Format appointment time as HH:MM for exact comparison
                const appointmentTime = appointmentStart.toTimeString().slice(0, 5);
                if (appointmentTime === slotTime) {
                  return true;
                }
              }
              return false;
            });
          }
          
          const isBlocked = blockedTimesData.some((blocked: any) => {
            const [blockedStartHour, blockedStartMin] = blocked.startTime.split(':').map(Number);
            const [blockedEndHour, blockedEndMin] = blocked.endTime.split(':').map(Number);
            const blockedStartMinutes = blockedStartHour * 60 + blockedStartMin;
            const blockedEndMinutes = blockedEndHour * 60 + blockedEndMin;
            
            return minutes >= blockedStartMinutes && minutes < blockedEndMinutes;
          });
          
          if (!hasConflict && !isBlocked) {
            slotsSet.add(slotTime);
          }
        }
      }
      
      const slots = Array.from(slotsSet).sort();
      
      res.json(slots);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch available slots" });
    }
  });

  // Get upcoming appointment reminders for notifications
  app.get("/api/notifications/reminders", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      const user = await storage.getUser(userId);
      if (!user || !user.emailReminders) {
        return res.json([]);
      }

      // Get upcoming confirmed appointments for the next 7 days
      const now = new Date();
      const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
      
      const appointments = await storage.getAppointmentsByDateRange(now, nextWeek, userId);
      const confirmedAppointments = appointments.filter(apt => apt.status === 'confirmed');

      // Get notification statuses to filter out deleted notifications
      const notificationStatuses = await storage.getNotificationStatuses(userId);
      const deletedNotificationIds = new Set(
        notificationStatuses
          .filter(status => status.isDeleted)
          .map(status => status.appointmentId)
      );
      const readNotificationIds = new Set(
        notificationStatuses
          .filter(status => status.isRead)
          .map(status => status.appointmentId)
      );

      // Calculate reminder times and filter for upcoming reminders
      const upcomingReminders = [];
      const reminderMinutes = user.reminderUnit === 'hours' 
        ? (user.reminderTime || 30) * 60 
        : user.reminderUnit === 'days' 
          ? (user.reminderTime || 1) * 24 * 60 
          : (user.reminderTime || 30);

      for (const appointment of confirmedAppointments) {
        // Skip deleted notifications
        if (deletedNotificationIds.has(appointment.id)) {
          continue;
        }

        const appointmentTime = new Date(appointment.appointmentDate);
        const reminderTime = new Date(appointmentTime.getTime() - reminderMinutes * 60 * 1000);
        
        // Show reminders that are due within the next 2 hours
        const twoHoursFromNow = new Date(now.getTime() + 2 * 60 * 60 * 1000);
        
        if (reminderTime <= twoHoursFromNow && appointmentTime > now) {
          upcomingReminders.push({
            appointmentId: appointment.id,
            customerName: appointment.clientName,
            customerEmail: appointment.clientEmail,
            appointmentDate: appointment.appointmentDate,
            reminderTime: reminderTime,
            isOverdue: reminderTime <= now,
            isRead: readNotificationIds.has(appointment.id)
          });
        }
      }

      // Sort by reminder time (most urgent first)
      upcomingReminders.sort((a, b) => new Date(a.reminderTime).getTime() - new Date(b.reminderTime).getTime());

      res.json(upcomingReminders);
    } catch (error) {
      console.error("Error fetching notification reminders:", error);
      res.status(500).json({ message: "Failed to fetch reminders" });
    }
  });

  // Mark notification as read
  app.patch("/api/notifications/:appointmentId/read", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const appointmentId = parseInt(req.params.appointmentId);

      if (isNaN(appointmentId)) {
        return res.status(400).json({ message: "Invalid appointment ID" });
      }

      const status = await storage.markNotificationAsRead(userId, appointmentId);
      res.json(status);
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  // Delete notification
  app.delete("/api/notifications/:appointmentId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const appointmentId = parseInt(req.params.appointmentId);

      if (isNaN(appointmentId)) {
        return res.status(400).json({ message: "Invalid appointment ID" });
      }

      const status = await storage.markNotificationAsDeleted(userId, appointmentId);
      res.json(status);
    } catch (error) {
      console.error("Error deleting notification:", error);
      res.status(500).json({ message: "Failed to delete notification" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      
      const startOfWeek = new Date(today);
      startOfWeek.setDate(today.getDate() - today.getDay());
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(startOfWeek.getDate() + 7);
      
      const allAppointments = await storage.getAppointments(userId);
      
      const todayAppointments = allAppointments.filter(a => {
        const appointmentDate = new Date(a.appointmentDate);
        return appointmentDate >= today && appointmentDate < tomorrow && a.status !== "cancelled";
      });
      
      const weekAppointments = allAppointments.filter(a => {
        const appointmentDate = new Date(a.appointmentDate);
        return appointmentDate >= startOfWeek && appointmentDate < endOfWeek && a.status !== "cancelled";
      });
      
      const pendingAppointments = allAppointments.filter(a => a.status === "pending");
      
      res.json({
        today: todayAppointments.length,
        thisWeek: weekAppointments.length,
        pending: pendingAppointments.length,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Blocked times routes
  app.get("/api/blocked-times", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const blockedTimes = await storage.getBlockedTimes(userId);
      res.json(blockedTimes);
    } catch (error) {
      console.error("Error fetching blocked times:", error);
      res.status(500).json({ message: "Failed to fetch blocked times" });
    }
  });

  app.post("/api/blocked-times", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertBlockedTimeSchema.parse(req.body);
      const blockedTime = await storage.createBlockedTime(validatedData, userId);
      res.status(201).json(blockedTime);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid blocked time data", errors: error.errors });
      }
      console.error("Error creating blocked time:", error);
      res.status(500).json({ message: "Failed to create blocked time" });
    }
  });

  app.delete("/api/blocked-times/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const success = await storage.deleteBlockedTime(id, userId);
      if (success) {
        res.json({ message: "Blocked time deleted successfully" });
      } else {
        res.status(404).json({ message: "Blocked time not found" });
      }
    } catch (error) {
      console.error("Error deleting blocked time:", error);
      res.status(500).json({ message: "Failed to delete blocked time" });
    }
  });

  app.patch("/api/availability/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const validatedData = insertAvailabilitySchema.partial().parse(req.body);
      const availability = await storage.updateAvailability(id, validatedData, userId);
      if (!availability) {
        return res.status(404).json({ message: "Availability record not found" });
      }
      res.json(availability);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid availability data", errors: error.errors });
      }
      console.error("Error updating availability:", error);
      res.status(500).json({ message: "Failed to update availability" });
    }
  });

  app.delete("/api/availability/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const success = await storage.deleteAvailability(id, userId);
      if (!success) {
        return res.status(404).json({ message: "Availability record not found" });
      }
      res.json({ message: "Availability deleted successfully" });
    } catch (error) {
      console.error("Error deleting availability:", error);
      res.status(500).json({ message: "Failed to delete availability" });
    }
  });

  // Google Calendar sync
  app.post("/api/google-calendar/sync", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Get user's appointments that need to be synced
      const appointments = await storage.getAppointments(userId);
      let syncedCount = 0;
      let errorCount = 0;

      for (const appointment of appointments) {
        try {
          // Skip if already has Google Event ID
          if (appointment.googleEventId) {
            continue;
          }

          // Create a simple event representation
          const eventData = {
            summary: `Appointment: ${appointment.clientName}`,
            description: `Service appointment with ${appointment.clientName}\nEmail: ${appointment.clientEmail}\nPhone: ${appointment.clientPhone}${appointment.notes ? `\nNotes: ${appointment.notes}` : ''}`,
            start: {
              dateTime: appointment.appointmentDate.toISOString(),
              timeZone: appointment.timezone || 'UTC'
            },
            end: {
              dateTime: new Date(appointment.appointmentDate.getTime() + (appointment.duration * 60000)).toISOString(),
              timeZone: appointment.timezone || 'UTC'
            }
          };

          // For now, we'll simulate the sync by generating a fake Google Event ID
          // In a real implementation, this would call the Google Calendar API
          const fakeGoogleEventId = `fake_event_${appointment.id}_${Date.now()}`;
          
          // Update the appointment with the Google Event ID
          await storage.updateAppointment(appointment.id, { 
            googleEventId: fakeGoogleEventId 
          }, userId);
          
          syncedCount++;
        } catch (appointmentError) {
          console.error(`Failed to sync appointment ${appointment.id}:`, appointmentError);
          errorCount++;
        }
      }

      res.json({
        success: true,
        message: `Sync completed: ${syncedCount} appointments synced${errorCount > 0 ? `, ${errorCount} errors` : ''}`,
        syncedCount,
        errorCount
      });
    } catch (error) {
      console.error("Google Calendar sync error:", error);
      res.status(500).json({ 
        success: false,
        message: "Failed to sync with Google Calendar",
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // PayPal access token function for payment verification
  async function getPayPalAccessToken() {
    try {
      const auth = Buffer.from(`${process.env.PAYPAL_CLIENT_ID_LIVE}:${process.env.PAYPAL_CLIENT_SECRET_LIVE}`).toString('base64');
      
      const response = await fetch(`https://api-m.paypal.com/v1/oauth2/token`, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'grant_type=client_credentials'
      });

      if (!response.ok) {
        throw new Error('Failed to get PayPal access token');
      }

      const data = await response.json();
      return data.access_token;
    } catch (error) {
      console.error('PayPal access token error:', error);
      throw error;
    }
  }

  // PayPal client ID endpoint (before other routes)
  app.get('/api/paypal/client-id', (req, res) => {
    res.json({ clientId: process.env.PAYPAL_CLIENT_ID_LIVE });
  });

  // PayPal routes for Pro plan upgrade
  app.get('/api/paypal/setup', loadPaypalDefault);
  app.get('/setup', loadPaypalDefault);
  app.post('/api/paypal/order', createPaypalOrder);
  app.post('/order', createPaypalOrder);
  app.post('/api/paypal/order/:orderID/capture', capturePaypalOrder);
  app.post('/order/:orderID/capture', capturePaypalOrder);

  // Upgrade to Pro plan route
  app.get('/api/upgrade', (req, res) => {
    res.redirect('/upgrade');
  });

  // Process Pro plan upgrade after successful PayPal payment
  app.post('/api/upgrade/complete', isAuthenticated, async (req: any, res) => {
    try {
      console.log('Upgrade complete request received:', req.body);
      const userId = req.user.claims.sub;
      const { paypalOrderId } = req.body;

      console.log('User ID:', userId, 'PayPal Order ID:', paypalOrderId);

      if (!paypalOrderId) {
        console.log('Error: No PayPal order ID provided');
        return res.status(400).json({ 
          success: false, 
          message: 'PayPal order ID is required for upgrade' 
        });
      }

      // Verify PayPal payment before upgrading
      try {
        // Call PayPal API to verify the order was actually paid
        const response = await fetch(`https://api-m.paypal.com/v2/checkout/orders/${paypalOrderId}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${await getPayPalAccessToken()}`
          }
        });

        if (!response.ok) {
          throw new Error('Failed to verify PayPal payment');
        }

        const orderData = await response.json();
        
        // Check if payment was completed and matches our expected amount
        if (orderData.status !== 'COMPLETED') {
          return res.status(400).json({ 
            success: false, 
            message: 'Payment not completed. Please complete payment before upgrading.' 
          });
        }

        // Verify the payment amount is correct ($4.00)
        const paidAmount = parseFloat(orderData.purchase_units[0].payments.captures[0].amount.value);
        const expectedAmount = 4.00;
        
        if (paidAmount < expectedAmount) {
          return res.status(400).json({ 
            success: false, 
            message: `Insufficient payment amount. Expected $${expectedAmount}, received $${paidAmount}` 
          });
        }

        // Payment verified - upgrade user to Pro plan
        await storage.updateUserProfile(userId, {
          subscriptionPlan: 'pro'
        });

        res.json({ 
          success: true, 
          message: 'Successfully upgraded to Pro plan!',
          plan: 'pro',
          paymentVerified: true
        });

      } catch (verificationError) {
        console.error('PayPal verification error:', verificationError);
        return res.status(400).json({ 
          success: false, 
          message: 'Failed to verify payment. Please contact support if payment was deducted.' 
        });
      }

    } catch (error) {
      console.error('Error upgrading user to Pro:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Failed to upgrade to Pro plan' 
      });
    }
  });

  // Admin routes
  app.get('/api/admin/users', async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error('Error fetching users:', error);
      res.status(500).json({ message: 'Failed to fetch users' });
    }
  });

  app.patch('/api/admin/users/:userId/subscription', async (req, res) => {
    try {
      const { userId } = req.params;
      const { subscriptionPlan } = req.body;

      if (!subscriptionPlan || !['free', 'pro'].includes(subscriptionPlan)) {
        return res.status(400).json({ message: 'Invalid subscription plan' });
      }

      const updatedUser = await storage.updateUserProfile(userId, { 
        subscriptionPlan 
      });

      if (!updatedUser) {
        return res.status(404).json({ message: 'User not found' });
      }

      res.json(updatedUser);
    } catch (error) {
      console.error('Error updating user subscription:', error);
      res.status(500).json({ message: 'Failed to update subscription plan' });
    }
  });

  app.patch('/api/admin/users/:userId/email', async (req, res) => {
    try {
      const { userId } = req.params;
      const { email } = req.body;

      if (!email || !/\S+@\S+\.\S+/.test(email)) {
        return res.status(400).json({ message: 'Invalid email address' });
      }

      const updatedUser = await storage.updateUserProfile(userId, { 
        email 
      });

      if (!updatedUser) {
        return res.status(404).json({ message: 'User not found' });
      }

      res.json(updatedUser);
    } catch (error) {
      console.error('Error updating user email:', error);
      res.status(500).json({ message: 'Failed to update email' });
    }
  });

  app.delete('/api/admin/users/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      
      const deleted = await storage.deleteUser(userId);
      
      if (!deleted) {
        return res.status(404).json({ message: 'User not found' });
      }

      res.json({ success: true, message: 'User deleted successfully' });
    } catch (error) {
      console.error('Error deleting user:', error);
      res.status(500).json({ message: 'Failed to delete user' });
    }
  });

  app.post('/api/admin/login-as/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      // In a real implementation, this would create a proper session for the user
      // For now, we'll just return success
      res.json({ success: true, message: 'Login simulation successful' });
    } catch (error) {
      console.error('Error simulating user login:', error);
      res.status(500).json({ message: 'Failed to simulate login' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
